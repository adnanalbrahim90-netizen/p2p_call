package com.bohashim.p2p_call

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build

/** الإشعارات: الخدمة، الرسائل، المكالمات الواردة، التنبيهات */
object Notifier {
    const val CH_SERVICE = "ittisal_bg"
    const val CH_MESSAGES = "ittisal_msg"
    const val CH_CALLS = "ittisal_calls"
    const val CH_INFO = "ittisal_info"

    const val ID_SERVICE = 1
    const val ID_CALL = 7
    private var infoId = 3000
    private val brand = Color.parseColor("#4C46E0")
    private val lines = mutableMapOf<String, MutableList<String>>()

    private fun nm(ctx: Context) = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private val immutable = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val m = nm(ctx)
        if (m.getNotificationChannel(CH_MESSAGES) != null) return
        m.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "التشغيل في الخلفية", NotificationManager.IMPORTANCE_MIN).apply {
                description = "إشعار دائم يبقي التطبيق متصلاً لاستقبال الرسائل والمكالمات"
                setShowBadge(false)
            },
        )
        m.createNotificationChannel(
            NotificationChannel(CH_MESSAGES, "الرسائل", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "الرسائل الجديدة"
                enableVibration(true)
            },
        )
        m.createNotificationChannel(
            NotificationChannel(CH_CALLS, "المكالمات الواردة", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "المكالمات الواردة (النغمة يشغلها التطبيق)"
                setSound(null, null)
                enableVibration(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            },
        )
        m.createNotificationChannel(
            NotificationChannel(CH_INFO, "تنبيهات", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "طلبات الإضافة والقروبات"
            },
        )
    }

    private fun builder(ctx: Context, channel: String): Notification.Builder {
        ensureChannels(ctx)
        val b = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(ctx, channel)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(ctx)
        }
        return b.setSmallIcon(R.drawable.ic_stat_ittisal).setColor(brand)
    }

    private fun openApp(ctx: Context, requestCode: Int, extras: Intent.() -> Unit = {}): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        i.extras()
        return PendingIntent.getActivity(ctx, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT or immutable)
    }

    // ------------------------------------------------------------------ الخدمة
    fun service(ctx: Context, inCall: Boolean): Notification {
        val b = builder(ctx, CH_SERVICE)
            .setContentTitle(if (inCall) "مكالمة جارية" else "اتصال مباشر يعمل")
            .setContentText(if (inCall) "اضغط للعودة إلى المكالمة" else "جاهز لاستقبال الرسائل والمكالمات")
            .setContentIntent(openApp(ctx, 1))
            .setOngoing(true)
            .setShowWhen(false)
        if (Build.VERSION.SDK_INT < 26) {
            @Suppress("DEPRECATION")
            b.setPriority(Notification.PRIORITY_MIN)
        }
        return b.build()
    }

    // ------------------------------------------------------------------ الرسائل
    private fun chatNotifId(chatId: String) = 10000 + ((chatId.hashCode() and 0x7fffffff) % 50000)

    fun message(ctx: Context, chatId: String, title: String, body: String) {
        val list = lines.getOrPut(chatId) { mutableListOf() }
        list.add(body)
        while (list.size > 6) list.removeAt(0)
        val style = Notification.InboxStyle().setBigContentTitle(title)
        for (l in list) style.addLine(l)
        if (list.size > 1) style.setSummaryText("${list.size} رسائل جديدة")
        val id = chatNotifId(chatId)
        val b = builder(ctx, CH_MESSAGES)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(style)
            .setNumber(list.size)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_MESSAGE)
            .setContentIntent(openApp(ctx, id) { putExtra(MainActivity.EXTRA_OPEN_CHAT, chatId) })
        if (Build.VERSION.SDK_INT < 26) {
            @Suppress("DEPRECATION")
            b.setPriority(Notification.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL)
        }
        try {
            nm(ctx).notify(id, b.build())
        } catch (e: SecurityException) {
            // إذن الإشعارات غير ممنوح
        }
    }

    fun cancelChat(ctx: Context, chatId: String) {
        lines.remove(chatId)
        nm(ctx).cancel(chatNotifId(chatId))
    }

    // ------------------------------------------------------------------ المكالمات
    fun incomingCall(ctx: Context, title: String, body: String, video: Boolean) {
        val open = openApp(ctx, 701) { putExtra(MainActivity.EXTRA_CALL_ACTION, "open") }
        val accept = openApp(ctx, 702) { putExtra(MainActivity.EXTRA_CALL_ACTION, "accept") }
        val declineIntent = Intent(ctx, CallActionReceiver::class.java).setAction(CallActionReceiver.ACTION_DECLINE)
        val decline = PendingIntent.getBroadcast(ctx, 703, declineIntent, PendingIntent.FLAG_UPDATE_CURRENT or immutable)

        val b = builder(ctx, CH_CALLS)
            .setContentTitle(title)
            .setContentText(body)
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
        if (Build.VERSION.SDK_INT >= 26) b.setTimeoutAfter(50_000)
        if (Build.VERSION.SDK_INT < 26) {
            @Suppress("DEPRECATION")
            b.setPriority(Notification.PRIORITY_MAX)
        }
        @Suppress("DEPRECATION")
        b.addAction(Notification.Action.Builder(0, "رفض", decline).build())
        @Suppress("DEPRECATION")
        b.addAction(Notification.Action.Builder(0, if (video) "رد بالفيديو" else "رد", accept).build())
        try {
            nm(ctx).notify(ID_CALL, b.build())
        } catch (e: SecurityException) {
        }
    }

    fun cancelCall(ctx: Context) {
        nm(ctx).cancel(ID_CALL)
    }

    // ------------------------------------------------------------------ تنبيهات
    fun info(ctx: Context, title: String, body: String) {
        val b = builder(ctx, CH_INFO)
            .setContentTitle(title)
            .setContentText(body)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx, 2))
        try {
            nm(ctx).notify(infoId++, b.build())
        } catch (e: SecurityException) {
        }
    }
}
