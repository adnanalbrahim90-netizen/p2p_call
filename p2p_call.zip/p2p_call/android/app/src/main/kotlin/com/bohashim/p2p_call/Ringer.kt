package com.bohashim.p2p_call

import android.content.Context
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** نغمة الرنين والاهتزاز (تعمل حتى بدون شاشة ظاهرة) */
object Ringer {
    private var ringtone: Ringtone? = null

    private fun vibrator(ctx: Context): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    fun start(ctx: Context) {
        stop(ctx)
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                val uri = RingtoneManager.getActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                val r = RingtoneManager.getRingtone(ctx, uri)
                if (r != null) {
                    if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                    r.play()
                    ringtone = r
                }
            }
            if (am.ringerMode != AudioManager.RINGER_MODE_SILENT) {
                val pattern = longArrayOf(0, 900, 700)
                val v = vibrator(ctx)
                if (Build.VERSION.SDK_INT >= 26) {
                    v?.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(pattern, 0)
                }
            }
        } catch (e: Exception) {
            // الرنين ليس ضرورياً لعمل المكالمة
        }
    }

    fun stop(ctx: Context) {
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
        try {
            vibrator(ctx)?.cancel()
        } catch (e: Exception) {
        }
    }

    fun tap(ctx: Context) {
        try {
            val v = vibrator(ctx)
            if (Build.VERSION.SDK_INT >= 26) {
                v?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v?.vibrate(45)
            }
        } catch (e: Exception) {
        }
    }
}
