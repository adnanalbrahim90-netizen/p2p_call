package com.bohashim.p2p_call

import com.journeyapps.barcodescanner.CaptureActivity

/**
 * ماسح QR أصلي (ZXing): المعاينة يرسمها أندرويد مباشرة وليس Flutter،
 * فيعمل بثبات على كل الأجهزة (ومنها هواوي) بدون مشاكل ظهور الكاميرا.
 */
class PortraitCaptureActivity : CaptureActivity()
