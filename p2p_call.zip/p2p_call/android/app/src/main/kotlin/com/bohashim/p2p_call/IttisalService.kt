package com.bohashim.p2p_call

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * خدمة أمامية تُبقي محرك Flutter (وبالتالي الاتصال بنقاط الالتقاء والقنوات المباشرة) حياً
 * بعد إغلاق التطبيق، فتصل الرسائل والمكالمات فوراً.
 * أثناء المكالمة تضيف نوع الميكروفون/الكاميرا ليستمر الصوت والصورة عند الخروج من التطبيق.
 */
class IttisalService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            running = false
            stopForegroundCompat()
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        running = true
        try {
            EngineHolder.ensure(this)
        } catch (e: Exception) {
            // سيُعاد المحاولة عند فتح التطبيق
        }
        return START_STICKY
    }

    private fun goForeground() {
        val notification = Notifier.service(this, inCall)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING
                if (inCall) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    if (inVideo) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
                }
                try {
                    startForeground(Notifier.ID_SERVICE, notification, type)
                } catch (e: Exception) {
                    // نوع الميكروفون/الكاميرا غير مسموح الآن: نكتفي بالمراسلة
                    startForeground(Notifier.ID_SERVICE, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_REMOTE_MESSAGING)
                }
            } else {
                startForeground(Notifier.ID_SERVICE, notification)
            }
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    companion object {
        private const val ACTION_STOP = "ittisal.stop"

        @Volatile
        var running = false

        @Volatile
        private var inCall = false

        @Volatile
        private var inVideo = false

        fun start(ctx: Context) {
            val i = Intent(ctx, IttisalService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
                // غير مسموح بالبدء من الخلفية الآن؛ يبدأ عند فتح التطبيق
            }
        }

        fun stopIfIdle(ctx: Context) {
            if (inCall) return
            try {
                ctx.startService(Intent(ctx, IttisalService::class.java).setAction(ACTION_STOP))
            } catch (e: Exception) {
                ctx.stopService(Intent(ctx, IttisalService::class.java))
            }
        }

        fun setInCall(ctx: Context, on: Boolean, video: Boolean) {
            inCall = on
            inVideo = on && video
            if (on) {
                start(ctx)
            } else if (Prefs.background(ctx)) {
                if (running) start(ctx)
            } else {
                stopIfIdle(ctx)
            }
        }
    }
}
