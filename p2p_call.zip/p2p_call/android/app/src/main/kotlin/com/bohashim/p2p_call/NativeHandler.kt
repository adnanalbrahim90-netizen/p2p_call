package com.bohashim.p2p_call

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/** يستقبل أوامر Dart على القناة "ittisal/native" */
class NativeHandler(private val app: Context) : MethodChannel.MethodCallHandler {

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "takeActions" -> result.success(EngineHolder.takeActions())
                "keepScreenOn" -> {
                    val on = call.arguments as? Boolean ?: false
                    EngineHolder.activity?.let { a ->
                        a.runOnUiThread {
                            if (on) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                            else a.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                    }
                    result.success(null)
                }
                "startRinging" -> { Ringer.start(app); result.success(null) }
                "stopRinging" -> { Ringer.stop(app); result.success(null) }
                "vibrate" -> { Ringer.tap(app); result.success(null) }
                "setBackground" -> {
                    val on = call.arguments as? Boolean ?: false
                    Prefs.setBackground(app, on)
                    if (on) IttisalService.start(app) else IttisalService.stopIfIdle(app)
                    result.success(null)
                }
                "setInCall" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    val video = call.argument<Boolean>("video") ?: false
                    IttisalService.setInCall(app, on, video)
                    if (!on) {
                        (EngineHolder.activity as? MainActivity)?.let { a ->
                            a.runOnUiThread { a.showOverLockScreen(false) }
                        }
                    }
                    result.success(null)
                }
                "notifyMessage" -> {
                    Notifier.message(
                        app,
                        call.argument<String>("chatId") ?: "",
                        call.argument<String>("title") ?: "",
                        call.argument<String>("body") ?: "",
                    )
                    result.success(null)
                }
                "cancelChat" -> {
                    Notifier.cancelChat(app, call.arguments as? String ?: "")
                    result.success(null)
                }
                "notifyCall" -> {
                    Notifier.incomingCall(
                        app,
                        call.argument<String>("title") ?: "",
                        call.argument<String>("body") ?: "",
                        call.argument<Boolean>("video") ?: false,
                    )
                    result.success(null)
                }
                "cancelCall" -> { Notifier.cancelCall(app); result.success(null) }
                "notifyInfo" -> {
                    Notifier.info(app, call.argument<String>("title") ?: "", call.argument<String>("body") ?: "")
                    result.success(null)
                }
                "canFullScreen" -> {
                    val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    result.success(if (Build.VERSION.SDK_INT >= 34) nm.canUseFullScreenIntent() else true)
                }
                "openFullScreenSettings" -> {
                    val intent = if (Build.VERSION.SDK_INT >= 34) {
                        Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${app.packageName}"))
                    } else {
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, app.packageName)
                    }
                    launch(intent)
                    result.success(null)
                }
                "isIgnoringBattery" -> {
                    val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
                    result.success(pm.isIgnoringBatteryOptimizations(app.packageName))
                }
                "requestIgnoreBattery" -> {
                    launch(
                        Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:${app.packageName}"),
                        ),
                    )
                    result.success(null)
                }
                "openAppSettings" -> {
                    launch(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}")))
                    result.success(null)
                }
                "manufacturer" -> result.success(Build.MANUFACTURER ?: "")
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("native_error", e.message, null)
        }
    }

    private fun launch(intent: Intent) {
        val a = EngineHolder.activity
        try {
            if (a != null) {
                a.startActivity(intent)
            } else {
                app.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
            // بعض الأجهزة لا تدعم هذه الشاشة: نفتح إعدادات التطبيق بدلاً منها
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                app.startActivity(fallback)
            } catch (ignored: Exception) {
            }
        }
    }
}

object Prefs {
    private const val FILE = "ittisal_native"

    fun setBackground(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean("bg", on).apply()
    }

    fun background(ctx: Context): Boolean =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean("bg", false)
}
