package com.bohashim.p2p_call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** إعادة التشغيل بعد إقلاع الهاتف أو تحديث التطبيق */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            if (Prefs.background(context)) IttisalService.start(context)
        }
    }
}

/** زر "رفض" في إشعار المكالمة الواردة */
class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_DECLINE) {
            Ringer.stop(context)
            Notifier.cancelCall(context)
            EngineHolder.pushAction(mapOf("type" to "call", "action" to "decline"))
        }
    }

    companion object {
        const val ACTION_DECLINE = "ittisal.call.decline"
    }
}
