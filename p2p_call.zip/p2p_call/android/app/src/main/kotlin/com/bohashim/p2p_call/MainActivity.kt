package com.bohashim.p2p_call

import android.content.Context
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * FlutterFragmentActivity مطلوب لقفل البصمة (local_auth).
 * القناة "ittisal/native" توفر: إبقاء الشاشة مضاءة، نغمة الرنين، والاهتزاز.
 */
class MainActivity : FlutterFragmentActivity() {
    private var ringtone: Ringtone? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "ittisal/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "keepScreenOn" -> {
                        val on = call.arguments as? Boolean ?: false
                        if (on) {
                            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        } else {
                            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        }
                        result.success(null)
                    }
                    "startRinging" -> {
                        startRinging()
                        result.success(null)
                    }
                    "stopRinging" -> {
                        stopRinging()
                        result.success(null)
                    }
                    "vibrate" -> {
                        vibrateOnce()
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun vibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun startRinging() {
        stopRinging()
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.ringerMode == AudioManager.RINGER_MODE_NORMAL) {
                val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                val r = RingtoneManager.getRingtone(applicationContext, uri)
                if (r != null) {
                    if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
                    r.play()
                    ringtone = r
                }
            }
            if (am.ringerMode != AudioManager.RINGER_MODE_SILENT) {
                val pattern = longArrayOf(0, 900, 700)
                val v = vibrator()
                if (Build.VERSION.SDK_INT >= 26) {
                    v?.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(pattern, 0)
                }
            }
        } catch (e: Exception) {
            // تجاهل: الرنين ليس ضرورياً لعمل المكالمة
        }
    }

    private fun stopRinging() {
        try {
            ringtone?.stop()
        } catch (e: Exception) {
        }
        ringtone = null
        try {
            vibrator()?.cancel()
        } catch (e: Exception) {
        }
    }

    private fun vibrateOnce() {
        try {
            val v = vibrator()
            if (Build.VERSION.SDK_INT >= 26) {
                v?.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v?.vibrate(45)
            }
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        stopRinging()
        super.onDestroy()
    }
}
