package com.bohashim.p2p_call

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
