package com.bohashim.p2p_call

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
import java.lang.ref.WeakReference

/**
 * الشاشة تستخدم محرك Flutter واحداً محفوظاً (EngineHolder) يبقى حياً بعد إغلاقها،
 * فتستمر الاتصالات واستقبال الرسائل والمكالمات في الخلفية.
 * FlutterFragmentActivity مطلوب لقفل البصمة (local_auth).
 */
class MainActivity : FlutterFragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // يجب أن يكون المحرك جاهزاً في الذاكرة قبل super.onCreate
        EngineHolder.ensure(this)
        handleIntent(intent)
        super.onCreate(savedInstanceState)
    }

    override fun getCachedEngineId(): String? = EngineHolder.ENGINE_ID

    override fun shouldDestroyEngineWithHost(): Boolean = false

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        EngineHolder.activityRef = WeakReference(this)
    }

    override fun onDestroy() {
        if (EngineHolder.activityRef?.get() === this) EngineHolder.activityRef = null
        super.onDestroy()
    }

    /** إجراءات قادمة من الإشعارات: فتح محادثة، الرد على مكالمة */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val chat = i.getStringExtra(EXTRA_OPEN_CHAT)
        if (chat != null) {
            i.removeExtra(EXTRA_OPEN_CHAT)
            EngineHolder.pushAction(mapOf("type" to "chat", "chatId" to chat))
        }
        val callAction = i.getStringExtra(EXTRA_CALL_ACTION)
        if (callAction != null) {
            i.removeExtra(EXTRA_CALL_ACTION)
            showOverLockScreen(true)
            if (callAction != "open") {
                EngineHolder.pushAction(mapOf("type" to "call", "action" to callAction))
            }
        }
    }

    /** إظهار شاشة المكالمة فوق قفل الهاتف */
    fun showOverLockScreen(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(on)
            setTurnScreenOn(on)
        } else {
            @Suppress("DEPRECATION")
            val flags = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            if (on) window.addFlags(flags) else window.clearFlags(flags)
        }
    }

    companion object {
        const val EXTRA_OPEN_CHAT = "ittisal.open_chat"
        const val EXTRA_CALL_ACTION = "ittisal.call_action"
    }
}
