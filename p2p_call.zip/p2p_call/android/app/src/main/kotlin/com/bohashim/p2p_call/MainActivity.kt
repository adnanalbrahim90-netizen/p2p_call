package com.bohashim.p2p_call

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import com.journeyapps.barcodescanner.ScanIntentResult
import com.journeyapps.barcodescanner.ScanOptions
import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.plugin.common.MethodChannel
import java.lang.ref.WeakReference

/**
 * الشاشة تستخدم محرك Flutter واحداً محفوظاً (EngineHolder) يبقى حياً بعد إغلاقها،
 * فتستمر الاتصالات واستقبال الرسائل والمكالمات في الخلفية.
 * FlutterFragmentActivity مطلوب لقفل البصمة (local_auth).
 */
class MainActivity : FlutterFragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // يجب أن يكون المحرك جاهزاً في الذاكرة قبل super.onCreate
        EngineHolder.ensure(this)
        handleIntent(intent)
        super.onCreate(savedInstanceState)
    }

    override fun getCachedEngineId(): String? = EngineHolder.ENGINE_ID

    override fun shouldDestroyEngineWithHost(): Boolean = false

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        EngineHolder.activityRef = WeakReference(this)
    }

    override fun onDestroy() {
        if (EngineHolder.activityRef?.get() === this) EngineHolder.activityRef = null
        super.onDestroy()
    }

    /** إجراءات قادمة من الإشعارات: فتح محادثة، الرد على مكالمة */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val chat = i.getStringExtra(EXTRA_OPEN_CHAT)
        if (chat != null) {
            i.removeExtra(EXTRA_OPEN_CHAT)
            EngineHolder.pushAction(mapOf("type" to "chat", "chatId" to chat))
        }
        val callAction = i.getStringExtra(EXTRA_CALL_ACTION)
        if (callAction != null) {
            i.removeExtra(EXTRA_CALL_ACTION)
            showOverLockScreen(true)
            if (callAction != "open") {
                EngineHolder.pushAction(mapOf("type" to "call", "action" to callAction))
            }
        }
    }

    /** إظهار شاشة المكالمة فوق قفل الهاتف */
    fun showOverLockScreen(on: Boolean) {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(on)
            setTurnScreenOn(on)
        } else {
            @Suppress("DEPRECATION")
            val flags = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            if (on) window.addFlags(flags) else window.clearFlags(flags)
        }
    }

    // ------------------------------------------------------------------ مسح QR
    private var scanResult: MethodChannel.Result? = null

    fun startScan(result: MethodChannel.Result) {
        if (scanResult != null) {
            result.success(null)
            return
        }
        scanResult = result
        val options = ScanOptions()
            .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            .setPrompt("وجّه الكاميرا نحو رمز صديقك")
            .setBeepEnabled(false)
            .setOrientationLocked(true)
            .setBarcodeImageEnabled(false)
            .setCaptureActivity(PortraitCaptureActivity::class.java)
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(options.createScanIntent(this), REQ_SCAN)
        } catch (e: Exception) {
            scanResult = null
            result.error("scan_failed", e.message, null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == REQ_SCAN) {
            val contents = try {
                ScanIntentResult.parseActivityResult(resultCode, data).contents
            } catch (e: Exception) {
                null
            }
            scanResult?.success(contents)
            scanResult = null
            return
        }
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
    }

    companion object {
        const val EXTRA_OPEN_CHAT = "ittisal.open_chat"
        const val EXTRA_CALL_ACTION = "ittisal.call_action"
        private const val REQ_SCAN = 4711
    }
}
