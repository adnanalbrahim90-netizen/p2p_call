package com.bohashim.p2p_call

import android.app.Activity
import android.content.Context
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.embedding.engine.dart.DartExecutor
import io.flutter.plugin.common.MethodChannel
import java.lang.ref.WeakReference

/**
 * يحتفظ بمحرك Flutter واحد طوال عمر العملية.
 * تنشئه الشاشة أو خدمة الخلفية (أيهما أولاً)، فيعمل كود Dart حتى بدون واجهة.
 */
object EngineHolder {
    const val ENGINE_ID = "ittisal_main"
    const val CHANNEL = "ittisal/native"

    private var channel: MethodChannel? = null
    private val actions = mutableListOf<Map<String, Any?>>()

    @Volatile
    var activityRef: WeakReference<Activity>? = null

    val activity: Activity?
        get() = activityRef?.get()

    @Synchronized
    fun ensure(context: Context): FlutterEngine {
        val cache = FlutterEngineCache.getInstance()
        val existing = cache.get(ENGINE_ID)
        if (existing != null) return existing
        val app = context.applicationContext
        val engine = FlutterEngine(app)
        val ch = MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
        ch.setMethodCallHandler(NativeHandler(app))
        channel = ch
        engine.dartExecutor.executeDartEntrypoint(DartExecutor.DartEntrypoint.createDefault())
        cache.put(ENGINE_ID, engine)
        return engine
    }

    /** يضع إجراءً في الطابور وينبّه Dart ليسحبه */
    fun pushAction(action: Map<String, Any?>) {
        synchronized(actions) { actions.add(action) }
        try {
            channel?.invokeMethod("action", null)
        } catch (e: Exception) {
            // Dart لم يجهز بعد؛ سيسحب الإجراءات عند التشغيل
        }
    }

    fun takeActions(): List<Map<String, Any?>> = synchronized(actions) {
        val copy = actions.toList()
        actions.clear()
        copy
    }
}
