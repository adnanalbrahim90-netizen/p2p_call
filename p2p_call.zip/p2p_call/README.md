# اتصال مباشر — P2P Call

تطبيق Flutter لمكالمات الصوت والفيديو والدردشة النصية من هاتف إلى هاتف مباشرة عبر WebRTC،
بدون أي سيرفر. التعارف بين الهاتفين يتم يدوياً عبر رمزي QR (Manual Signaling).

## هيكل المشروع

```
lib/
├── main.dart                      نقطة البداية + الثيم + اتجاه RTL
├── theme.dart                     الألوان والثيم الداكن
├── services/
│   ├── webrtc_service.dart        PeerConnection + الوسائط + DataChannel + التحكم
│   ├── signaling_codec.dart       تنحيف SDP + GZip + Base64 ⇄ نص QR
│   └── permissions.dart           أذونات الكاميرا والميكروفون
├── screens/
│   ├── home_screen.dart           الشاشة الرئيسية (Host / Join)
│   ├── host_screen.dart           مسار المُنشئ: Offer ← QR 1 ← مسح QR 2
│   ├── guest_screen.dart          مسار المنضم: مسح QR 1 ← Answer ← QR 2
│   ├── scanner_screen.dart        ماسح QR بإطار وخط مسح متحرك
│   └── call_screen.dart           المكالمة: فيديو كامل + PiP + أزرار التحكم
└── widgets/
    ├── common.dart                مكونات الواجهة المشتركة
    └── chat_sheet.dart            نافذة الدردشة عبر RTCDataChannel
```

## بناء الـ APK

### الطريقة 1: GitHub Actions (بدون تثبيت أي شيء)
1. أنشئ مستودعاً جديداً على GitHub (يمكن أن يكون خاصاً).
2. ارفع محتويات هذا المجلد كما هي (بما فيها مجلد `.github`).
3. افتح تبويب **Actions** — سيبدأ البناء تلقائياً (≈ 8–12 دقيقة).
4. بعد انتهائه افتح الـ run ونزّل **p2p_call-apk** من قسم Artifacts.
   - `p2p_call-arm64.apk` لمعظم الهواتف الحديثة.
   - `p2p_call-universal.apk` يعمل على كل الأجهزة (أكبر حجماً).

### الطريقة 2: على جهازك
يتطلب Flutter 3.27 أو أحدث و Android SDK و Java 17:

```bash
cd p2p_call
flutter create --platforms=android --org com.bohashim --project-name p2p_call .
# إن ظهرت ملفات *.gradle.kts بجانب ملفات .gradle احذف ملفات kts:
rm -f android/*.gradle.kts android/app/build.gradle.kts
flutter pub get
flutter build apk --release
```
الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk`

## طريقة الاستخدام
1. الهاتف (أ): **إنشاء غرفة اتصال** ← يظهر رمز الدعوة.
2. الهاتف (ب): **الانضمام لمكالمة** ← يمسح رمز الدعوة ← يظهر رمز الرد.
3. الهاتف (أ): **مسح رد الطرف الآخر** ← تبدأ المكالمة فوراً.

إن كان الطرفان بعيدين: استخدم «نسخ الرمز» وأرسله بالواتساب، والطرف الآخر يستخدم «لصق».

## ملاحظات تقنية
- STUN: `stun:stun.l.google.com:19302` فقط، بدون TURN.
- لا يُستخدم Trickle ICE؛ يُنتظر `RTCIceGatheringStateComplete` (مع مهلة 8 ثوانٍ احتياطية).
- قبل الضغط يُنحّف الـ SDP: إبقاء Opus للصوت و VP8 (+RTX) للفيديو وحذف مسارات TCP،
  ثم GZip + Base64، فيصبح الرمز ≈ 1.5 ألف حرف بدلاً من ≈ 8.5 ألف.
- يحرّر المضيف كاميرته مؤقتاً أثناء مسح رمز الرد ثم يستعيدها عبر `replaceTrack`
  لتجنب تعارض الكاميرا بين WebRTC والماسح.
- بدون سيرفر TURN قد يفشل الاتصال إذا كان أحد الطرفين خلف NAT صارم
  (شائع في بيانات الجوال). أفضل نتيجة: الطرفان على Wi-Fi.
