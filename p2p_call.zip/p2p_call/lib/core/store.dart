import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'models.dart';

/// تخزين محلي بسيط بملفات JSON داخل مجلد التطبيق الخاص.
class Store extends ChangeNotifier {
  Store._(this.root);

  final Directory root;

  final Map<String, Contact> _contacts = {};
  final Map<String, Group> _groups = {};
  final Map<String, List<ChatMessage>> _chats = {};
  final List<ContactRequest> requests = [];
  final List<CallLog> calls = [];
  final List<OutboxItem> outbox = [];
  final Set<String> ignored = {};
  AppSettings settings = AppSettings();
  Map<String, dynamic>? identityJson;

  /// معرّف هذا الجهاز (يُضبط بعد تحميل الهوية)
  String selfId = '';

  final Map<String, Timer> _pending = {};

  static Future<Store> open() async {
    final base = await getApplicationSupportDirectory();
    final root = Directory('${base.path}/ittisal');
    await root.create(recursive: true);
    await Directory('${root.path}/chats').create(recursive: true);
    await Directory('${root.path}/media').create(recursive: true);
    final s = Store._(root);
    await s._load();
    return s;
  }

  String get mediaDir => '${root.path}/media';

  // ---------------------------------------------------------------- تحميل
  Future<void> _load() async {
    identityJson = await _readMap('identity.json');
    final st = await _readMap('settings.json');
    if (st != null) settings = AppSettings.fromJson(st);

    for (final j in await _readList('contacts.json')) {
      try {
        final c = Contact.fromJson(j);
        _contacts[c.id] = c;
      } catch (_) {}
    }
    for (final j in await _readList('groups.json')) {
      try {
        final g = Group.fromJson(j);
        _groups[g.id] = g;
      } catch (_) {}
    }
    for (final j in await _readList('requests.json')) {
      try {
        requests.add(ContactRequest.fromJson(j));
      } catch (_) {}
    }
    final ign = await _readMap('ignored.json');
    if (ign != null && ign['ids'] is List) {
      ignored.addAll((ign['ids'] as List).whereType<String>());
    }
    for (final j in await _readList('calls.json')) {
      try {
        calls.add(CallLog.fromJson(j));
      } catch (_) {}
    }
    for (final j in await _readList('outbox.json')) {
      try {
        outbox.add(OutboxItem.fromJson(j));
      } catch (_) {}
    }
  }

  Future<Map<String, dynamic>?> _readMap(String name) async {
    final f = File('${root.path}/$name');
    if (!await f.exists()) return null;
    try {
      final v = jsonDecode(await f.readAsString());
      return v is Map<String, dynamic> ? v : null;
    } catch (_) {
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> _readList(String name) async {
    final f = File('${root.path}/$name');
    if (!await f.exists()) return [];
    try {
      final v = jsonDecode(await f.readAsString());
      if (v is! List) return [];
      return v.whereType<Map<String, dynamic>>().toList();
    } catch (_) {
      return [];
    }
  }

  // ---------------------------------------------------------------- حفظ مؤجل
  final Map<String, Object Function()> _writers = {};

  void _schedule(String name, Object Function() data) {
    _writers[name] = data;
    _pending[name]?.cancel();
    _pending[name] = Timer(const Duration(milliseconds: 250), () {
      _pending.remove(name);
      final w = _writers.remove(name);
      if (w != null) _write(name, w());
    });
  }

  Future<void> _write(String name, Object data) async {
    final f = File('${root.path}/$name');
    final tmp = File('${f.path}.tmp');
    try {
      await tmp.parent.create(recursive: true);
      await tmp.writeAsString(jsonEncode(data), flush: true);
      await tmp.rename(f.path);
    } catch (e) {
      debugPrint('store write $name failed: $e');
    }
  }

  Future<void> saveIdentity(Map<String, dynamic> json) async {
    identityJson = json;
    await _write('identity.json', json);
  }

  void saveSettings() {
    _schedule('settings.json', () => settings.toJson());
    notifyListeners();
  }

  void _saveContacts() =>
      _schedule('contacts.json', () => _contacts.values.map((c) => c.toJson()).toList());

  void _saveGroups() =>
      _schedule('groups.json', () => _groups.values.map((g) => g.toJson()).toList());

  void _saveRequests() =>
      _schedule('requests.json', () => requests.map((r) => r.toJson()).toList());

  void _saveCalls() => _schedule('calls.json', () => calls.map((c) => c.toJson()).toList());

  void _saveOutbox() => _schedule('outbox.json', () => outbox.map((o) => o.toJson()).toList());

  void _saveChat(String chatId) => _schedule(
        'chats/$chatId.json',
        () => (_chats[chatId] ?? const <ChatMessage>[]).map((m) => m.toJson()).toList(),
      );

  /// حفظ فوري لكل ما هو مؤجل (عند الخروج للخلفية)
  Future<void> flush() async {
    final items = Map<String, Object Function()>.from(_writers);
    for (final t in _pending.values) {
      t.cancel();
    }
    _pending.clear();
    _writers.clear();
    for (final e in items.entries) {
      await _write(e.key, e.value());
    }
  }

  // ---------------------------------------------------------------- جهات الاتصال
  List<Contact> get contacts {
    final list = _contacts.values.toList();
    list.sort((a, b) => a.displayName.compareTo(b.displayName));
    return list;
  }

  Contact? contact(String id) => _contacts[id];

  bool hasContact(String id) => _contacts.containsKey(id);

  void upsertContact(Contact c) {
    final existing = _contacts[c.id];
    if (existing != null) {
      if (c.name.isNotEmpty) existing.name = c.name;
    } else {
      _contacts[c.id] = c;
    }
    requests.removeWhere((r) => r.id == c.id);
    _saveContacts();
    _saveRequests();
    notifyListeners();
  }

  void updateContact(Contact c) {
    _saveContacts();
    notifyListeners();
  }

  Future<void> deleteContact(String id) async {
    _contacts.remove(id);
    _chats.remove(id);
    calls.removeWhere((c) => c.chatId == id);
    _saveContacts();
    _saveCalls();
    try {
      await File('${root.path}/chats/$id.json').delete();
    } catch (_) {}
    try {
      await Directory('$mediaDir/$id').delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  // ---------------------------------------------------------------- القروبات
  List<Group> get groups => _groups.values.toList();

  Group? group(String id) => _groups[id];

  void putGroup(Group g) {
    _groups[g.id] = g;
    _saveGroups();
    notifyListeners();
  }

  void groupChanged(Group g) {
    _saveGroups();
    notifyListeners();
  }

  Future<void> deleteGroup(String id) async {
    final g = _groups.remove(id);
    if (g == null) return;
    _chats.remove(g.chatId);
    calls.removeWhere((c) => c.chatId == g.chatId);
    outbox.removeWhere((o) => o.payload['gid'] == id);
    _saveGroups();
    _saveCalls();
    _saveOutbox();
    try {
      await File('${root.path}/chats/${g.chatId}.json').delete();
    } catch (_) {}
    try {
      await Directory('$mediaDir/${g.chatId}').delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  /// القروبات النشطة التي يشترك فيها هذا الشخص معي
  Iterable<Group> sharedGroups(String peerId) =>
      _groups.values.where((g) => !g.left && g.has(peerId) && g.has(selfId));

  bool sharesGroup(String peerId) => sharedGroups(peerId).isNotEmpty;

  /// كل من يجب متابعة حالة اتصاله (جهات الاتصال + أعضاء القروبات)
  Set<String> get allPeerIds {
    final ids = <String>{..._contacts.keys};
    for (final g in _groups.values) {
      if (g.left) continue;
      for (final m in g.members) {
        if (m.id != selfId) ids.add(m.id);
      }
    }
    for (final o in outbox) {
      ids.add(o.peerId);
    }
    return ids;
  }

  /// بيانات طرف (جهة اتصال أو عضو قروب)
  PeerInfo? peer(String id) {
    final c = _contacts[id];
    if (c != null) return PeerInfo(c.id, c.publicKey, c.displayName);
    for (final g in _groups.values) {
      final m = g.member(id);
      if (m != null) return PeerInfo(m.id, m.publicKey, m.name);
    }
    for (final o in outbox) {
      if (o.peerId == id && o.peerKey != null) return PeerInfo(id, o.peerKey!, '');
    }
    return null;
  }

  bool hasOutboxFor(String peerId) => outbox.any((o) => o.peerId == peerId);

  /// اسم للعرض: الاسم المحفوظ في جهات الاتصال أولاً
  String nameOf(String id, {String fallback = 'عضو'}) {
    if (id == selfId) return 'أنت';
    final c = _contacts[id];
    if (c != null) return c.displayName;
    for (final g in _groups.values) {
      final m = g.member(id);
      if (m != null && m.name.isNotEmpty) return m.name;
    }
    return fallback;
  }

  // ---------------------------------------------------------------- قائمة الدردشات
  List<ChatEntry> get chats {
    final list = <ChatEntry>[
      ..._contacts.values.map(ChatEntry.contact),
      ..._groups.values.map(ChatEntry.group),
    ];
    list.sort((a, b) => b.sortTime.compareTo(a.sortTime));
    return list;
  }

  String titleOf(String chatId) {
    if (isGroupChat(chatId)) return _groups[groupIdOf(chatId)]?.name ?? 'قروب';
    return _contacts[chatId]?.displayName ?? 'جهة اتصال';
  }

  int get totalUnread =>
      _contacts.values.fold(0, (s, c) => s + c.unread) + _groups.values.fold(0, (s, g) => s + g.unread);

  void markRead(String chatId) {
    if (isGroupChat(chatId)) {
      final g = _groups[groupIdOf(chatId)];
      if (g == null || g.unread == 0) return;
      g.unread = 0;
      _saveGroups();
    } else {
      final c = _contacts[chatId];
      if (c == null || c.unread == 0) return;
      c.unread = 0;
      _saveContacts();
    }
    notifyListeners();
  }

  // ---------------------------------------------------------------- الطلبات
  void addRequest(ContactRequest r) {
    if (_contacts.containsKey(r.id)) return;
    requests.removeWhere((x) => x.id == r.id);
    requests.insert(0, r);
    _saveRequests();
    notifyListeners();
  }

  void ignore(String id) {
    ignored.add(id);
    _schedule('ignored.json', () => {'ids': ignored.toList()});
  }

  void unignore(String id) {
    if (ignored.remove(id)) {
      _schedule('ignored.json', () => {'ids': ignored.toList()});
    }
  }

  void removeRequest(String id) {
    requests.removeWhere((r) => r.id == id);
    _saveRequests();
    notifyListeners();
  }

  // ---------------------------------------------------------------- الرسائل
  Future<List<ChatMessage>> loadChat(String chatId) async {
    final cached = _chats[chatId];
    if (cached != null) return cached;
    final list = <ChatMessage>[];
    for (final j in await _readList('chats/$chatId.json')) {
      try {
        list.add(ChatMessage.fromJson(j));
      } catch (_) {}
    }
    final again = _chats[chatId];
    if (again != null) return again;
    _chats[chatId] = list;
    return list;
  }

  List<ChatMessage>? cachedChat(String chatId) => _chats[chatId];

  Future<ChatMessage?> findMessage(String chatId, String id) async {
    final list = await loadChat(chatId);
    for (var i = list.length - 1; i >= 0; i--) {
      if (list[i].id == id) return list[i];
    }
    return null;
  }

  void _touch(ChatMessage m, {bool countUnread = false}) {
    String text;
    if (m.isNotice) {
      text = m.preview;
    } else if (m.mine) {
      text = 'أنت: ${m.preview}';
    } else if (m.isGroup) {
      text = '${m.senderName ?? nameOf(m.senderId ?? '')}: ${m.preview}';
    } else {
      text = m.preview;
    }
    if (m.isGroup) {
      final g = _groups[groupIdOf(m.chatId)];
      if (g == null) return;
      g.lastText = text;
      g.lastTime = m.time;
      if (countUnread) g.unread++;
      _saveGroups();
    } else {
      final c = _contacts[m.chatId];
      if (c == null) return;
      c.lastText = text;
      c.lastTime = m.time;
      if (countUnread) c.unread++;
      _saveContacts();
    }
  }

  Future<void> addMessage(ChatMessage m, {bool countUnread = false}) async {
    final list = await loadChat(m.chatId);
    if (list.any((x) => x.id == m.id)) return;
    list.add(m);
    _touch(m, countUnread: countUnread);
    _saveChat(m.chatId);
    notifyListeners();
  }

  /// يُستدعى بعد تعديل حالة رسالة موجودة
  void messageChanged(ChatMessage m, {bool persist = true}) {
    if (persist) _saveChat(m.chatId);
    notifyListeners();
  }

  /// حذف للجميع: تبقى الرسالة كعلامة "تم الحذف"
  Future<void> markDeleted(ChatMessage m) async {
    m.deleted = true;
    m.text = null;
    m.pendingTo = null;
    final path = m.filePath;
    m.filePath = null;
    if (path != null) {
      try {
        await File(path).delete();
      } catch (_) {}
    }
    final list = await loadChat(m.chatId);
    if (list.isNotEmpty && list.last.id == m.id) _touch(m);
    _saveChat(m.chatId);
    notifyListeners();
  }

  Future<void> deleteMessage(ChatMessage m) async {
    final list = await loadChat(m.chatId);
    list.removeWhere((x) => x.id == m.id);
    if (m.filePath != null) {
      try {
        await File(m.filePath!).delete();
      } catch (_) {}
    }
    _saveChat(m.chatId);
    notifyListeners();
  }

  Future<void> clearChat(String chatId) async {
    final list = await loadChat(chatId);
    list.clear();
    if (isGroupChat(chatId)) {
      final g = _groups[groupIdOf(chatId)];
      if (g != null) {
        g.lastText = null;
        g.unread = 0;
        _saveGroups();
      }
    } else {
      final c = _contacts[chatId];
      if (c != null) {
        c.lastText = null;
        c.unread = 0;
        _saveContacts();
      }
    }
    _saveChat(chatId);
    try {
      await Directory('$mediaDir/$chatId').delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  /// الرسائل التي يجب تسليمها لهذا الطرف: محادثته الفردية + رسائلي في القروبات المشتركة
  Future<List<ChatMessage>> outgoingFor(String peerId) async {
    final out = <ChatMessage>[];
    if (_contacts.containsKey(peerId)) {
      out.addAll((await loadChat(peerId)).where((m) => m.needsSending));
    }
    for (final g in sharedGroups(peerId)) {
      out.addAll((await loadChat(g.chatId)).where((m) => m.pendingFor(peerId)));
    }
    out.sort((a, b) => a.time.compareTo(b.time));
    return out;
  }

  Future<bool> hasOutgoing(String peerId) async {
    if (outbox.any((o) => o.peerId == peerId)) return true;
    return (await outgoingFor(peerId)).isNotEmpty;
  }

  // ---------------------------------------------------------------- صندوق التحكم
  void enqueue(OutboxItem item) {
    outbox.add(item);
    _saveOutbox();
  }

  List<OutboxItem> outboxFor(String peerId) => outbox.where((o) => o.peerId == peerId).toList();

  void dequeue(String id) {
    final before = outbox.length;
    outbox.removeWhere((o) => o.id == id);
    if (outbox.length != before) _saveOutbox();
  }

  // ---------------------------------------------------------------- المكالمات
  void addCall(CallLog log) {
    calls.insert(0, log);
    if (calls.length > 300) calls.removeRange(300, calls.length);
    _saveCalls();
    notifyListeners();
  }

  void clearCalls() {
    calls.clear();
    _saveCalls();
    notifyListeners();
  }

  // ---------------------------------------------------------------- إعادة الضبط
  Future<void> wipeAll() async {
    for (final t in _pending.values) {
      t.cancel();
    }
    _pending.clear();
    _writers.clear();
    _contacts.clear();
    _groups.clear();
    _chats.clear();
    requests.clear();
    calls.clear();
    outbox.clear();
    ignored.clear();
    identityJson = null;
    selfId = '';
    settings = AppSettings();
    try {
      await root.delete(recursive: true);
    } catch (_) {}
    await root.create(recursive: true);
    await Directory('${root.path}/chats').create(recursive: true);
    await Directory('${root.path}/media').create(recursive: true);
    notifyListeners();
  }
}
