import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import 'models.dart';

/// تخزين محلي بسيط بملفات JSON داخل مجلد التطبيق الخاص.
class Store extends ChangeNotifier {
  Store._(this.root);

  final Directory root;

  final Map<String, Contact> _contacts = {};
  final Map<String, List<ChatMessage>> _chats = {};
  final List<ContactRequest> requests = [];
  final List<CallLog> calls = [];
  final Set<String> ignored = {};
  AppSettings settings = AppSettings();
  Map<String, dynamic>? identityJson;

  final Map<String, Timer> _pending = {};

  static Future<Store> open() async {
    final base = await getApplicationSupportDirectory();
    final root = Directory('${base.path}/ittisal');
    await root.create(recursive: true);
    await Directory('${root.path}/chats').create(recursive: true);
    await Directory('${root.path}/media').create(recursive: true);
    final s = Store._(root);
    await s._load();
    return s;
  }

  String get mediaDir => '${root.path}/media';

  // ---------------------------------------------------------------- تحميل
  Future<void> _load() async {
    identityJson = await _readMap('identity.json');
    final st = await _readMap('settings.json');
    if (st != null) settings = AppSettings.fromJson(st);

    for (final j in await _readList('contacts.json')) {
      try {
        final c = Contact.fromJson(j);
        _contacts[c.id] = c;
      } catch (_) {}
    }
    for (final j in await _readList('requests.json')) {
      try {
        requests.add(ContactRequest.fromJson(j));
      } catch (_) {}
    }
    final ign = await _readMap('ignored.json');
    if (ign != null && ign['ids'] is List) {
      ignored.addAll((ign['ids'] as List).whereType<String>());
    }
    for (final j in await _readList('calls.json')) {
      try {
        calls.add(CallLog.fromJson(j));
      } catch (_) {}
    }
  }

  Future<Map<String, dynamic>?> _readMap(String name) async {
    final f = File('${root.path}/$name');
    if (!await f.exists()) return null;
    try {
      final v = jsonDecode(await f.readAsString());
      return v is Map<String, dynamic> ? v : null;
    } catch (_) {
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> _readList(String name) async {
    final f = File('${root.path}/$name');
    if (!await f.exists()) return [];
    try {
      final v = jsonDecode(await f.readAsString());
      if (v is! List) return [];
      return v.whereType<Map<String, dynamic>>().toList();
    } catch (_) {
      return [];
    }
  }

  // ---------------------------------------------------------------- حفظ مؤجل
  void _schedule(String name, Object Function() data) {
    _pending[name]?.cancel();
    _pending[name] = Timer(const Duration(milliseconds: 250), () {
      _pending.remove(name);
      _write(name, data());
    });
  }

  Future<void> _write(String name, Object data) async {
    final f = File('${root.path}/$name');
    final tmp = File('${f.path}.tmp');
    try {
      await tmp.parent.create(recursive: true);
      await tmp.writeAsString(jsonEncode(data), flush: true);
      await tmp.rename(f.path);
    } catch (e) {
      debugPrint('store write $name failed: $e');
    }
  }

  Future<void> saveIdentity(Map<String, dynamic> json) async {
    identityJson = json;
    await _write('identity.json', json);
  }

  void saveSettings() {
    _schedule('settings.json', () => settings.toJson());
    notifyListeners();
  }

  void _saveContacts() =>
      _schedule('contacts.json', () => _contacts.values.map((c) => c.toJson()).toList());

  void _saveRequests() =>
      _schedule('requests.json', () => requests.map((r) => r.toJson()).toList());

  void _saveCalls() =>
      _schedule('calls.json', () => calls.map((c) => c.toJson()).toList());

  void _saveChat(String contactId) => _schedule(
        'chats/$contactId.json',
        () => (_chats[contactId] ?? const <ChatMessage>[]).map((m) => m.toJson()).toList(),
      );

  /// حفظ فوري لكل ما هو مؤجل (عند الخروج للخلفية)
  Future<void> flush() async {
    final names = _pending.keys.toList();
    for (final n in names) {
      _pending[n]?.cancel();
    }
    _pending.clear();
    _write('contacts.json', _contacts.values.map((c) => c.toJson()).toList());
    _write('requests.json', requests.map((r) => r.toJson()).toList());
    _write('calls.json', calls.map((c) => c.toJson()).toList());
    _write('settings.json', settings.toJson());
    for (final id in _chats.keys) {
      if (names.contains('chats/$id.json')) {
        await _write('chats/$id.json', _chats[id]!.map((m) => m.toJson()).toList());
      }
    }
  }

  // ---------------------------------------------------------------- جهات الاتصال
  List<Contact> get contacts {
    final list = _contacts.values.toList();
    list.sort((a, b) {
      final ta = a.lastTime ?? a.addedAt;
      final tb = b.lastTime ?? b.addedAt;
      return tb.compareTo(ta);
    });
    return list;
  }

  Contact? contact(String id) => _contacts[id];

  bool hasContact(String id) => _contacts.containsKey(id);

  void upsertContact(Contact c) {
    final existing = _contacts[c.id];
    if (existing != null) {
      if (c.name.isNotEmpty) existing.name = c.name;
    } else {
      _contacts[c.id] = c;
    }
    requests.removeWhere((r) => r.id == c.id);
    _saveContacts();
    _saveRequests();
    notifyListeners();
  }

  void updateContact(Contact c) {
    _saveContacts();
    notifyListeners();
  }

  Future<void> deleteContact(String id) async {
    _contacts.remove(id);
    _chats.remove(id);
    calls.removeWhere((c) => c.contactId == id);
    _saveContacts();
    _saveCalls();
    try {
      await File('${root.path}/chats/$id.json').delete();
    } catch (_) {}
    try {
      await Directory('$mediaDir/$id').delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  int get totalUnread => _contacts.values.fold(0, (s, c) => s + c.unread);

  void markRead(String contactId) {
    final c = _contacts[contactId];
    if (c == null || c.unread == 0) return;
    c.unread = 0;
    _saveContacts();
    notifyListeners();
  }

  // ---------------------------------------------------------------- الطلبات
  void addRequest(ContactRequest r) {
    if (_contacts.containsKey(r.id)) return;
    requests.removeWhere((x) => x.id == r.id);
    requests.insert(0, r);
    _saveRequests();
    notifyListeners();
  }

  void ignore(String id) {
    ignored.add(id);
    _schedule('ignored.json', () => {'ids': ignored.toList()});
  }

  void unignore(String id) {
    if (ignored.remove(id)) {
      _schedule('ignored.json', () => {'ids': ignored.toList()});
    }
  }

  void removeRequest(String id) {
    requests.removeWhere((r) => r.id == id);
    _saveRequests();
    notifyListeners();
  }

  // ---------------------------------------------------------------- الرسائل
  Future<List<ChatMessage>> loadChat(String contactId) async {
    final cached = _chats[contactId];
    if (cached != null) return cached;
    final list = <ChatMessage>[];
    for (final j in await _readList('chats/$contactId.json')) {
      try {
        list.add(ChatMessage.fromJson(j));
      } catch (_) {}
    }
    // قد يكون تم تحميلها أثناء الانتظار
    final again = _chats[contactId];
    if (again != null) return again;
    _chats[contactId] = list;
    return list;
  }

  List<ChatMessage>? cachedChat(String contactId) => _chats[contactId];

  Future<ChatMessage?> findMessage(String contactId, String id) async {
    final list = await loadChat(contactId);
    for (var i = list.length - 1; i >= 0; i--) {
      if (list[i].id == id) return list[i];
    }
    return null;
  }

  Future<void> addMessage(ChatMessage m, {bool countUnread = false}) async {
    final list = await loadChat(m.contactId);
    if (list.any((x) => x.id == m.id)) return;
    list.add(m);
    final c = _contacts[m.contactId];
    if (c != null) {
      c.lastText = m.mine && m.kind != MessageKind.call ? 'أنت: ${m.preview}' : m.preview;
      c.lastTime = m.time;
      if (countUnread) c.unread++;
      _saveContacts();
    }
    _saveChat(m.contactId);
    notifyListeners();
  }

  /// يُستدعى بعد تعديل حالة رسالة موجودة
  void messageChanged(ChatMessage m, {bool persist = true}) {
    if (persist) _saveChat(m.contactId);
    notifyListeners();
  }

  Future<void> deleteMessage(ChatMessage m) async {
    final list = await loadChat(m.contactId);
    list.removeWhere((x) => x.id == m.id);
    if (m.filePath != null) {
      try {
        await File(m.filePath!).delete();
      } catch (_) {}
    }
    _saveChat(m.contactId);
    notifyListeners();
  }

  Future<void> clearChat(String contactId) async {
    final list = await loadChat(contactId);
    list.clear();
    final c = _contacts[contactId];
    if (c != null) {
      c.lastText = null;
      c.unread = 0;
      _saveContacts();
    }
    _saveChat(contactId);
    try {
      await Directory('$mediaDir/$contactId').delete(recursive: true);
    } catch (_) {}
    notifyListeners();
  }

  Future<List<ChatMessage>> outgoingToSend(String contactId) async {
    final list = await loadChat(contactId);
    return list.where((m) => m.needsSending).toList();
  }

  Future<bool> hasOutgoing(String contactId) async =>
      (await outgoingToSend(contactId)).isNotEmpty;

  // ---------------------------------------------------------------- المكالمات
  void addCall(CallLog log) {
    calls.insert(0, log);
    if (calls.length > 300) calls.removeRange(300, calls.length);
    _saveCalls();
    notifyListeners();
  }

  void clearCalls() {
    calls.clear();
    _saveCalls();
    notifyListeners();
  }

  // ---------------------------------------------------------------- إعادة الضبط
  Future<void> wipeAll() async {
    for (final t in _pending.values) {
      t.cancel();
    }
    _pending.clear();
    _contacts.clear();
    _chats.clear();
    requests.clear();
    calls.clear();
    ignored.clear();
    identityJson = null;
    settings = AppSettings();
    try {
      await root.delete(recursive: true);
    } catch (_) {}
    await root.create(recursive: true);
    await Directory('${root.path}/chats').create(recursive: true);
    await Directory('${root.path}/media').create(recursive: true);
    notifyListeners();
  }
}
