import 'dart:convert';
import 'dart:typed_data';

/// جهة اتصال محفوظة (أضيفت عبر QR أو بطلب إضافة مقبول)
class Contact {
  Contact({
    required this.id,
    required this.publicKey,
    required this.name,
    DateTime? addedAt,
    this.nickname,
    this.lastText,
    this.lastTime,
    this.unread = 0,
    this.confirmed = false,
  }) : addedAt = addedAt ?? DateTime.now();

  final String id;
  final Uint8List publicKey;

  /// أصبح الطرف الآخر يعرفنا (استلمنا منه تأكيداً أو رسالة)
  bool confirmed;

  /// الاسم الذي اختاره صاحب الجهاز
  String name;

  /// اسم مخصص يضعه المستخدم لجهة الاتصال
  String? nickname;

  final DateTime addedAt;
  String? lastText;
  DateTime? lastTime;
  int unread;

  String get displayName =>
      (nickname != null && nickname!.trim().isNotEmpty) ? nickname! : name;

  String get publicKeyB64 => base64Url.encode(publicKey);

  Map<String, dynamic> toJson() => {
        'id': id,
        'pk': publicKeyB64,
        'name': name,
        'nick': nickname,
        'added': addedAt.millisecondsSinceEpoch,
        'lastText': lastText,
        'lastTime': lastTime?.millisecondsSinceEpoch,
        'unread': unread,
        'ok': confirmed,
      };

  factory Contact.fromJson(Map<String, dynamic> j) => Contact(
        id: j['id'] as String,
        publicKey: Uint8List.fromList(base64Url.decode(j['pk'] as String)),
        name: (j['name'] as String?) ?? '',
        nickname: j['nick'] as String?,
        addedAt: DateTime.fromMillisecondsSinceEpoch((j['added'] as int?) ?? 0),
        lastText: j['lastText'] as String?,
        lastTime: j['lastTime'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(j['lastTime'] as int),
        unread: (j['unread'] as int?) ?? 0,
        confirmed: j['ok'] == true,
      );
}

/// طلب إضافة وارد من شخص مسح رمزك
class ContactRequest {
  ContactRequest({
    required this.id,
    required this.publicKey,
    required this.name,
    DateTime? time,
  }) : time = time ?? DateTime.now();

  final String id;
  final Uint8List publicKey;
  final String name;
  final DateTime time;

  Map<String, dynamic> toJson() => {
        'id': id,
        'pk': base64Url.encode(publicKey),
        'name': name,
        'time': time.millisecondsSinceEpoch,
      };

  factory ContactRequest.fromJson(Map<String, dynamic> j) => ContactRequest(
        id: j['id'] as String,
        publicKey: Uint8List.fromList(base64Url.decode(j['pk'] as String)),
        name: (j['name'] as String?) ?? '',
        time: DateTime.fromMillisecondsSinceEpoch((j['time'] as int?) ?? 0),
      );
}

enum MessageKind { text, image, video, call }

enum MessageStatus {
  /// بانتظار اتصال الطرف الآخر
  pending,

  /// جارٍ الإرسال (ملف)
  sending,

  /// خرج من الجهاز
  sent,

  /// وصل للطرف الآخر
  delivered,

  /// جارٍ الاستلام (ملف)
  receiving,

  /// تم الاستلام
  received,

  failed,
}

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.contactId,
    required this.mine,
    required this.kind,
    required this.status,
    DateTime? time,
    this.text,
    this.filePath,
    this.fileName,
    this.fileSize,
    this.mime,
    this.progress = 0,
  }) : time = time ?? DateTime.now();

  final String id;
  final String contactId;
  final bool mine;
  final MessageKind kind;
  MessageStatus status;
  final DateTime time;
  String? text;
  String? filePath;
  String? fileName;
  int? fileSize;
  String? mime;

  /// تقدم نقل الملف 0..1 (غير محفوظ)
  double progress;

  bool get isFile => kind == MessageKind.image || kind == MessageKind.video;

  /// هل يجب على المرسل إعادة المحاولة عند فتح القناة
  bool get needsSending =>
      mine &&
      kind != MessageKind.call &&
      (status == MessageStatus.pending ||
          status == MessageStatus.sending ||
          status == MessageStatus.sent ||
          status == MessageStatus.failed);

  String get preview {
    switch (kind) {
      case MessageKind.text:
        return text ?? '';
      case MessageKind.image:
        return '📷 صورة';
      case MessageKind.video:
        return '🎬 فيديو';
      case MessageKind.call:
        return text ?? 'مكالمة';
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'c': contactId,
        'm': mine,
        'k': kind.name,
        's': status.name,
        't': time.millisecondsSinceEpoch,
        if (text != null) 'x': text,
        if (filePath != null) 'fp': filePath,
        if (fileName != null) 'fn': fileName,
        if (fileSize != null) 'fs': fileSize,
        if (mime != null) 'mi': mime,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> j) {
    var status = MessageStatus.values.firstWhere(
      (s) => s.name == j['s'],
      orElse: () => MessageStatus.failed,
    );
    // أي نقل لم يكتمل عند إغلاق التطبيق
    if (status == MessageStatus.sending) status = MessageStatus.pending;
    if (status == MessageStatus.receiving) status = MessageStatus.failed;
    return ChatMessage(
      id: j['id'] as String,
      contactId: j['c'] as String,
      mine: j['m'] == true,
      kind: MessageKind.values.firstWhere(
        (k) => k.name == j['k'],
        orElse: () => MessageKind.text,
      ),
      status: status,
      time: DateTime.fromMillisecondsSinceEpoch((j['t'] as int?) ?? 0),
      text: j['x'] as String?,
      filePath: j['fp'] as String?,
      fileName: j['fn'] as String?,
      fileSize: j['fs'] as int?,
      mime: j['mi'] as String?,
    );
  }
}

enum CallResult { answered, missed, declined, failed, cancelled }

class CallLog {
  CallLog({
    required this.contactId,
    required this.video,
    required this.incoming,
    required this.result,
    this.duration = Duration.zero,
    DateTime? time,
  }) : time = time ?? DateTime.now();

  final String contactId;
  final bool video;
  final bool incoming;
  final CallResult result;
  final Duration duration;
  final DateTime time;

  Map<String, dynamic> toJson() => {
        'c': contactId,
        'v': video,
        'in': incoming,
        'r': result.name,
        'd': duration.inSeconds,
        't': time.millisecondsSinceEpoch,
      };

  factory CallLog.fromJson(Map<String, dynamic> j) => CallLog(
        contactId: j['c'] as String,
        video: j['v'] == true,
        incoming: j['in'] == true,
        result: CallResult.values.firstWhere(
          (r) => r.name == j['r'],
          orElse: () => CallResult.failed,
        ),
        duration: Duration(seconds: (j['d'] as int?) ?? 0),
        time: DateTime.fromMillisecondsSinceEpoch((j['t'] as int?) ?? 0),
      );
}

class AppSettings {
  AppSettings({this.lockEnabled = true, this.lockAfterSeconds = 30});

  bool lockEnabled;
  int lockAfterSeconds;

  Map<String, dynamic> toJson() =>
      {'lock': lockEnabled, 'lockAfter': lockAfterSeconds};

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        lockEnabled: j['lock'] != false,
        lockAfterSeconds: (j['lockAfter'] as int?) ?? 30,
      );
}
