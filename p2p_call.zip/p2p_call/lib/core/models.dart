import 'dart:convert';
import 'dart:typed_data';

/// معرّف المحادثة: معرّف جهة الاتصال، أو 'g_' + معرّف القروب
bool isGroupChat(String chatId) => chatId.startsWith('g_');
String groupChatId(String groupId) => 'g_$groupId';
String groupIdOf(String chatId) => chatId.substring(2);

/// جهة اتصال محفوظة (أضيفت عبر QR أو بطلب إضافة مقبول)
class Contact {
  Contact({
    required this.id,
    required this.publicKey,
    required this.name,
    DateTime? addedAt,
    this.nickname,
    this.lastText,
    this.lastTime,
    this.unread = 0,
    this.confirmed = false,
  }) : addedAt = addedAt ?? DateTime.now();

  final String id;
  final Uint8List publicKey;

  /// أصبح الطرف الآخر يعرفنا (استلمنا منه تأكيداً أو رسالة)
  bool confirmed;

  /// الاسم الذي اختاره صاحب الجهاز
  String name;

  /// اسم مخصص يضعه المستخدم لجهة الاتصال
  String? nickname;

  final DateTime addedAt;
  String? lastText;
  DateTime? lastTime;
  int unread;

  String get displayName =>
      (nickname != null && nickname!.trim().isNotEmpty) ? nickname! : name;

  String get publicKeyB64 => base64Url.encode(publicKey);

  Map<String, dynamic> toJson() => {
        'id': id,
        'pk': publicKeyB64,
        'name': name,
        'nick': nickname,
        'added': addedAt.millisecondsSinceEpoch,
        'lastText': lastText,
        'lastTime': lastTime?.millisecondsSinceEpoch,
        'unread': unread,
        'ok': confirmed,
      };

  factory Contact.fromJson(Map<String, dynamic> j) => Contact(
        id: j['id'] as String,
        publicKey: Uint8List.fromList(base64Url.decode(j['pk'] as String)),
        name: (j['name'] as String?) ?? '',
        nickname: j['nick'] as String?,
        addedAt: DateTime.fromMillisecondsSinceEpoch((j['added'] as int?) ?? 0),
        lastText: j['lastText'] as String?,
        lastTime: j['lastTime'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(j['lastTime'] as int),
        unread: (j['unread'] as int?) ?? 0,
        confirmed: j['ok'] == true,
      );
}

/// طرف يمكن التواصل معه مباشرة (جهة اتصال أو عضو في قروب مشترك)
class PeerInfo {
  const PeerInfo(this.id, this.publicKey, this.name);
  final String id;
  final Uint8List publicKey;
  final String name;
}

/// طلب إضافة وارد من شخص مسح رمزك
class ContactRequest {
  ContactRequest({
    required this.id,
    required this.publicKey,
    required this.name,
    DateTime? time,
  }) : time = time ?? DateTime.now();

  final String id;
  final Uint8List publicKey;
  final String name;
  final DateTime time;

  Map<String, dynamic> toJson() => {
        'id': id,
        'pk': base64Url.encode(publicKey),
        'name': name,
        'time': time.millisecondsSinceEpoch,
      };

  factory ContactRequest.fromJson(Map<String, dynamic> j) => ContactRequest(
        id: j['id'] as String,
        publicKey: Uint8List.fromList(base64Url.decode(j['pk'] as String)),
        name: (j['name'] as String?) ?? '',
        time: DateTime.fromMillisecondsSinceEpoch((j['time'] as int?) ?? 0),
      );
}

// ============================================================================ القروبات
enum GroupRole { owner, admin, member }

class GroupMember {
  GroupMember({
    required this.id,
    required this.publicKey,
    required this.name,
    this.role = GroupRole.member,
  });

  final String id;
  final Uint8List publicKey;
  String name;
  GroupRole role;

  bool get isAdmin => role != GroupRole.member;

  Map<String, dynamic> toJson() => {
        'id': id,
        'pk': base64Url.encode(publicKey),
        'name': name,
        'role': role.name,
      };

  factory GroupMember.fromJson(Map<String, dynamic> j) => GroupMember(
        id: j['id'] as String,
        publicKey: Uint8List.fromList(base64Url.decode(j['pk'] as String)),
        name: (j['name'] as String?) ?? '',
        role: GroupRole.values.firstWhere(
          (r) => r.name == j['role'],
          orElse: () => GroupRole.member,
        ),
      );

  GroupMember copy() => GroupMember(id: id, publicKey: publicKey, name: name, role: role);
}

/// قروب: نسخة متطابقة محفوظة على جهاز كل عضو.
/// التعديلات (أعضاء، صلاحيات، اسم) يصدرها المشرفون برقم إصدار متزايد.
class Group {
  Group({
    required this.id,
    required this.name,
    required this.members,
    this.version = 1,
    this.editor = '',
    this.adminsOnly = false,
    DateTime? createdAt,
    this.left = false,
    this.lastText,
    this.lastTime,
    this.unread = 0,
  }) : createdAt = createdAt ?? DateTime.now();

  final String id;
  String name;
  List<GroupMember> members;
  int version;

  /// معرّف آخر مشرف عدّل القروب (لحسم التعارض بين تعديلين متزامنين)
  String editor;

  /// المشرفون فقط يرسلون الرسائل
  bool adminsOnly;
  final DateTime createdAt;

  /// غادرت القروب أو أُزلت منه
  bool left;

  String? lastText;
  DateTime? lastTime;
  int unread;

  String get chatId => groupChatId(id);

  GroupMember? member(String memberId) {
    for (final m in members) {
      if (m.id == memberId) return m;
    }
    return null;
  }

  bool has(String memberId) => member(memberId) != null;
  bool isAdmin(String memberId) => member(memberId)?.isAdmin ?? false;
  bool isOwner(String memberId) => member(memberId)?.role == GroupRole.owner;

  GroupMember? get owner {
    for (final m in members) {
      if (m.role == GroupRole.owner) return m;
    }
    return null;
  }

  /// النسخة التي تُرسل للأعضاء (بدون الحقول المحلية)
  Map<String, dynamic> toWire() => {
        'id': id,
        'name': name,
        'v': version,
        'ed': editor,
        'ao': adminsOnly,
        'at': createdAt.millisecondsSinceEpoch,
        'm': members.map((m) => m.toJson()).toList(),
      };

  factory Group.fromWire(Map<String, dynamic> j) => Group(
        id: j['id'] as String,
        name: (j['name'] as String?) ?? 'قروب',
        version: (j['v'] as int?) ?? 1,
        editor: (j['ed'] as String?) ?? '',
        adminsOnly: j['ao'] == true,
        createdAt: DateTime.fromMillisecondsSinceEpoch((j['at'] as int?) ?? 0),
        members: ((j['m'] as List?) ?? const [])
            .whereType<Map<String, dynamic>>()
            .map(GroupMember.fromJson)
            .toList(),
      );

  Map<String, dynamic> toJson() => {
        ...toWire(),
        'left': left,
        'lastText': lastText,
        'lastTime': lastTime?.millisecondsSinceEpoch,
        'unread': unread,
      };

  factory Group.fromJson(Map<String, dynamic> j) {
    final g = Group.fromWire(j);
    g.left = j['left'] == true;
    g.lastText = j['lastText'] as String?;
    g.lastTime = j['lastTime'] == null ? null : DateTime.fromMillisecondsSinceEpoch(j['lastTime'] as int);
    g.unread = (j['unread'] as int?) ?? 0;
    return g;
  }

  /// هل التعديل الوارد أحدث من النسخة المحلية
  bool isOlderThan(int v, String byEditor) =>
      v > version || (v == version && byEditor.compareTo(editor) > 0);
}

// ============================================================================ الرسائل
enum MessageKind { text, image, video, call, system }

enum MessageStatus {
  /// بانتظار اتصال الطرف الآخر
  pending,

  /// جارٍ الإرسال (ملف)
  sending,

  /// خرج من الجهاز (في القروب: وصل لبعض الأعضاء)
  sent,

  /// وصل للطرف الآخر (في القروب: لكل الأعضاء)
  delivered,

  /// جارٍ الاستلام (ملف)
  receiving,

  /// تم الاستلام
  received,

  failed,
}

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.chatId,
    required this.mine,
    required this.kind,
    required this.status,
    DateTime? time,
    this.text,
    this.senderId,
    this.senderName,
    this.filePath,
    this.fileName,
    this.fileSize,
    this.mime,
    this.pendingTo,
    this.deleted = false,
    this.progress = 0,
  }) : time = time ?? DateTime.now();

  final String id;

  /// معرّف جهة الاتصال أو 'g_' + معرّف القروب
  final String chatId;
  final bool mine;
  final MessageKind kind;
  MessageStatus status;
  final DateTime time;
  String? text;

  /// المرسل (في القروبات)
  final String? senderId;
  String? senderName;
  String? filePath;
  String? fileName;
  int? fileSize;
  String? mime;

  /// أعضاء القروب الذين لم تصلهم الرسالة بعد
  List<String>? pendingTo;

  /// حُذفت للجميع
  bool deleted;

  /// تقدم نقل الملف 0..1 (غير محفوظ)
  double progress;

  bool get isGroup => isGroupChat(chatId);
  bool get isFile => kind == MessageKind.image || kind == MessageKind.video;
  bool get isNotice => kind == MessageKind.call || kind == MessageKind.system;

  /// هل يجب على المرسل إعادة المحاولة عند فتح القناة (محادثة فردية)
  bool get needsSending =>
      mine &&
      !isNotice &&
      !deleted &&
      (status == MessageStatus.pending ||
          status == MessageStatus.sending ||
          status == MessageStatus.sent ||
          status == MessageStatus.failed);

  /// هل ما زالت الرسالة الجماعية بانتظار التسليم لهذا العضو
  bool pendingFor(String peerId) =>
      mine && !deleted && (pendingTo?.contains(peerId) ?? false);

  String get preview {
    if (deleted) return '🚫 تم حذف هذه الرسالة';
    switch (kind) {
      case MessageKind.text:
        return text ?? '';
      case MessageKind.image:
        return '📷 صورة';
      case MessageKind.video:
        return '🎬 فيديو';
      case MessageKind.call:
      case MessageKind.system:
        return text ?? '';
    }
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'c': chatId,
        'm': mine,
        'k': kind.name,
        's': status.name,
        't': time.millisecondsSinceEpoch,
        if (text != null) 'x': text,
        if (senderId != null) 'sid': senderId,
        if (senderName != null) 'sn': senderName,
        if (filePath != null) 'fp': filePath,
        if (fileName != null) 'fn': fileName,
        if (fileSize != null) 'fs': fileSize,
        if (mime != null) 'mi': mime,
        if (pendingTo != null) 'pt': pendingTo,
        if (deleted) 'del': true,
      };

  factory ChatMessage.fromJson(Map<String, dynamic> j) {
    var status = MessageStatus.values.firstWhere(
      (s) => s.name == j['s'],
      orElse: () => MessageStatus.failed,
    );
    // أي نقل لم يكتمل عند إغلاق التطبيق
    if (status == MessageStatus.sending) status = MessageStatus.pending;
    if (status == MessageStatus.receiving) status = MessageStatus.failed;
    return ChatMessage(
      id: j['id'] as String,
      chatId: j['c'] as String,
      mine: j['m'] == true,
      kind: MessageKind.values.firstWhere(
        (k) => k.name == j['k'],
        orElse: () => MessageKind.text,
      ),
      status: status,
      time: DateTime.fromMillisecondsSinceEpoch((j['t'] as int?) ?? 0),
      text: j['x'] as String?,
      senderId: j['sid'] as String?,
      senderName: j['sn'] as String?,
      filePath: j['fp'] as String?,
      fileName: j['fn'] as String?,
      fileSize: j['fs'] as int?,
      mime: j['mi'] as String?,
      pendingTo: (j['pt'] as List?)?.whereType<String>().toList(),
      deleted: j['del'] == true,
    );
  }
}

/// رسالة تحكم صغيرة مضمونة التسليم (قروبات، حذف للجميع) تنتظر اتصال المستلم
class OutboxItem {
  OutboxItem({
    required this.id,
    required this.peerId,
    required this.payload,
    this.peerKey,
    DateTime? time,
  }) : time = time ?? DateTime.now();

  final String id;
  final String peerId;

  /// مفتاح المستلم (للوصول إليه حتى لو لم يعد عضواً مشتركاً، مثل من أُزيل من القروب)
  final Uint8List? peerKey;
  final Map<String, dynamic> payload;
  final DateTime time;

  Map<String, dynamic> toJson() => {
        'id': id,
        'p': peerId,
        if (peerKey != null) 'k': base64Url.encode(peerKey!),
        'd': payload,
        't': time.millisecondsSinceEpoch,
      };

  factory OutboxItem.fromJson(Map<String, dynamic> j) => OutboxItem(
        id: j['id'] as String,
        peerId: j['p'] as String,
        peerKey: j['k'] == null ? null : Uint8List.fromList(base64Url.decode(j['k'] as String)),
        payload: Map<String, dynamic>.from(j['d'] as Map),
        time: DateTime.fromMillisecondsSinceEpoch((j['t'] as int?) ?? 0),
      );
}

// ============================================================================ المكالمات
enum CallResult { answered, missed, declined, failed, cancelled }

class CallLog {
  CallLog({
    required this.chatId,
    required this.video,
    required this.incoming,
    required this.result,
    this.duration = Duration.zero,
    DateTime? time,
  }) : time = time ?? DateTime.now();

  /// جهة الاتصال أو القروب
  final String chatId;
  final bool video;
  final bool incoming;
  final CallResult result;
  final Duration duration;
  final DateTime time;

  bool get isGroup => isGroupChat(chatId);

  Map<String, dynamic> toJson() => {
        'c': chatId,
        'v': video,
        'in': incoming,
        'r': result.name,
        'd': duration.inSeconds,
        't': time.millisecondsSinceEpoch,
      };

  factory CallLog.fromJson(Map<String, dynamic> j) => CallLog(
        chatId: j['c'] as String,
        video: j['v'] == true,
        incoming: j['in'] == true,
        result: CallResult.values.firstWhere(
          (r) => r.name == j['r'],
          orElse: () => CallResult.failed,
        ),
        duration: Duration(seconds: (j['d'] as int?) ?? 0),
        time: DateTime.fromMillisecondsSinceEpoch((j['t'] as int?) ?? 0),
      );
}

class AppSettings {
  AppSettings({
    this.lockEnabled = true,
    this.lockAfterSeconds = 30,
    this.background = true,
    this.backgroundIntroShown = false,
  });

  bool lockEnabled;
  int lockAfterSeconds;

  /// البقاء متصلاً في الخلفية لاستلام الرسائل والمكالمات والتطبيق مغلق
  bool background;
  bool backgroundIntroShown;

  Map<String, dynamic> toJson() => {
        'lock': lockEnabled,
        'lockAfter': lockAfterSeconds,
        'bg': background,
        'bgIntro': backgroundIntroShown,
      };

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        lockEnabled: j['lock'] != false,
        lockAfterSeconds: (j['lockAfter'] as int?) ?? 30,
        background: j['bg'] != false,
        backgroundIntroShown: j['bgIntro'] == true,
      );
}

/// عنصر في قائمة الدردشات (جهة اتصال أو قروب)
class ChatEntry {
  ChatEntry.contact(Contact this.contact) : group = null;
  ChatEntry.group(Group this.group) : contact = null;

  final Contact? contact;
  final Group? group;

  bool get isGroup => group != null;
  String get chatId => contact?.id ?? group!.chatId;
  String get seed => contact?.id ?? group!.id;
  String get title => contact?.displayName ?? group!.name;
  String? get lastText => contact?.lastText ?? group!.lastText;
  DateTime? get lastTime => contact?.lastTime ?? group?.lastTime;
  DateTime get sortTime => lastTime ?? contact?.addedAt ?? group!.createdAt;
  int get unread => contact?.unread ?? group!.unread;
}
