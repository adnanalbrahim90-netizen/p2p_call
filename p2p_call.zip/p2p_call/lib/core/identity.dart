import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as hash;
import 'package:cryptography/cryptography.dart';

final Random _rng = Random.secure();

Uint8List randomBytes(int n) =>
    Uint8List.fromList(List<int>.generate(n, (_) => _rng.nextInt(256)));

/// معرّف عشوائي قصير للرسائل والجلسات
String newId([int bytes = 12]) => base64Url.encode(randomBytes(bytes)).replaceAll('=', '');

/// معرّف ثابت للجهاز مشتق من مفتاحه العام
String idForPublicKey(List<int> publicKey) =>
    hash.sha256.convert(publicKey).toString().substring(0, 32);

/// تنسيق المعرّف للعرض: A1B2 C3D4 E5F6
String prettyId(String id) {
  final s = id.substring(0, 12).toUpperCase();
  return '${s.substring(0, 4)} ${s.substring(4, 8)} ${s.substring(8, 12)}';
}

/// بطاقة التعريف المحمولة داخل رمز QR الثابت
class ContactCard {
  ContactCard(this.publicKey, this.name);

  static const String prefix = 'ITT1:';

  final Uint8List publicKey;
  final String name;

  String get id => idForPublicKey(publicKey);

  String encode() {
    final pk = base64Url.encode(publicKey).replaceAll('=', '');
    final nm = base64Url.encode(utf8.encode(name)).replaceAll('=', '');
    return '$prefix$pk:$nm';
  }

  static ContactCard? tryParse(String raw) {
    final text = raw.trim().replaceAll(RegExp(r'\s+'), '');
    final start = text.indexOf(prefix);
    if (start < 0) return null;
    final parts = text.substring(start + prefix.length).split(':');
    if (parts.isEmpty) return null;
    try {
      final pk = base64Url.decode(base64Url.normalize(parts[0]));
      if (pk.length != 32) return null;
      var name = '';
      if (parts.length > 1 && parts[1].isNotEmpty) {
        name = utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
      }
      return ContactCard(Uint8List.fromList(pk), name);
    } catch (_) {
      return null;
    }
  }
}

/// هوية الجهاز: زوج مفاتيح X25519 ثابت + الاسم
class Identity {
  Identity._(this.seed, this.keyPair, this.publicKey, this.name);

  final Uint8List seed;
  final SimpleKeyPair keyPair;
  final Uint8List publicKey;
  String name;

  String get id => idForPublicKey(publicKey);

  ContactCard get card => ContactCard(publicKey, name);

  static Future<Identity> fromSeed(Uint8List seed, String name) async {
    final kp = await X25519().newKeyPairFromSeed(seed);
    final pub = await kp.extractPublicKey();
    return Identity._(seed, kp, Uint8List.fromList(pub.bytes), name);
  }

  static Future<Identity> generate(String name) =>
      fromSeed(randomBytes(32), name);

  Map<String, dynamic> toJson() => {
        'seed': base64Url.encode(seed),
        'name': name,
      };

  static Future<Identity> fromJson(Map<String, dynamic> j) => fromSeed(
        Uint8List.fromList(base64Url.decode(j['seed'] as String)),
        (j['name'] as String?) ?? '',
      );

  /// رمز أمان مشترك يمكن مقارنته بين الطرفين للتأكد من عدم التلاعب
  String safetyCode(Uint8List peerKey) {
    final a = base64Url.encode(publicKey);
    final b = base64Url.encode(peerKey);
    final joined = a.compareTo(b) < 0 ? '$a$b' : '$b$a';
    final digest = hash.sha256.convert(utf8.encode(joined)).bytes;
    final buf = StringBuffer();
    for (var i = 0; i < 6; i++) {
      final n = ((digest[i * 2] << 8) | digest[i * 2 + 1]) % 100000;
      if (i > 0) buf.write(i == 3 ? '\n' : '  ');
      buf.write(n.toString().padLeft(5, '0'));
    }
    return buf.toString();
  }
}

/// تشفير طرف-لطرف لرسائل التعارف عبر الوسيط العام:
/// X25519 (تبادل مفاتيح) ← HKDF-SHA256 ← AES-256-GCM
class Cipher {
  Cipher(this.identity);

  final Identity identity;
  final _x25519 = X25519();
  final _aead = AesGcm.with256bits();
  final _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  final Map<String, SecretKey> _cache = {};

  Future<SecretKey> _keyFor(Uint8List peer) async {
    final k = base64Url.encode(peer);
    final cached = _cache[k];
    if (cached != null) return cached;
    final shared = await _x25519.sharedSecretKey(
      keyPair: identity.keyPair,
      remotePublicKey: SimplePublicKey(peer, type: KeyPairType.x25519),
    );
    final key = await _hkdf.deriveKey(
      secretKey: shared,
      nonce: utf8.encode('ittisal-v1'),
      info: utf8.encode('relay'),
    );
    _cache[k] = key;
    return key;
  }

  Future<String> seal(Uint8List peer, Map<String, dynamic> payload) async {
    final key = await _keyFor(peer);
    final box = await _aead.encrypt(
      utf8.encode(jsonEncode(payload)),
      secretKey: key,
      nonce: _aead.newNonce(),
    );
    return base64.encode(box.concatenation());
  }

  Future<Map<String, dynamic>?> open(Uint8List peer, String sealed) async {
    try {
      final key = await _keyFor(peer);
      final box = SecretBox.fromConcatenation(
        base64.decode(sealed),
        nonceLength: _aead.nonceLength,
        macLength: _aead.macAlgorithm.macLength,
      );
      final clear = await _aead.decrypt(box, secretKey: key);
      final obj = jsonDecode(utf8.decode(clear));
      return obj is Map<String, dynamic> ? obj : null;
    } catch (_) {
      return null;
    }
  }
}
