import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../../app/theme.dart';

// ============================================================================ صور رمزية
const List<List<Color>> _avatarGradients = [
  [Color(0xFF6C63FF), Color(0xFF4338CA)],
  [Color(0xFF0EA5E9), Color(0xFF2563EB)],
  [Color(0xFF14B8A6), Color(0xFF0F766E)],
  [Color(0xFFF59E0B), Color(0xFFEA580C)],
  [Color(0xFFEC4899), Color(0xFFBE185D)],
  [Color(0xFF8B5CF6), Color(0xFF6D28D9)],
  [Color(0xFF22C55E), Color(0xFF15803D)],
  [Color(0xFFF43F5E), Color(0xFFBE123C)],
];

List<Color> avatarColors(String seed) {
  var h = 0;
  for (final c in seed.codeUnits) {
    h = (h * 31 + c) & 0x7fffffff;
  }
  return _avatarGradients[h % _avatarGradients.length];
}

String initials(String name) {
  final parts = name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
  if (parts.isEmpty) return '؟';
  final first = String.fromCharCodes(parts.first.runes.take(1));
  if (parts.length == 1) return first;
  return '$first${String.fromCharCodes(parts[1].runes.take(1))}';
}

class Avatar extends StatelessWidget {
  const Avatar({
    super.key,
    required this.name,
    required this.seed,
    this.size = 48,
    this.online = false,
    this.ring = false,
  });

  final String name;
  final String seed;
  final double size;
  final bool online;
  final bool ring;

  @override
  Widget build(BuildContext context) {
    final colors = avatarColors(seed);
    final dot = math.max(11.0, size * 0.26);
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: colors,
              ),
              border: ring
                  ? Border.all(color: Colors.white.withValues(alpha: 0.9), width: 3)
                  : null,
            ),
            child: Text(
              initials(name),
              style: TextStyle(
                fontFamily: kFont,
                color: Colors.white,
                fontSize: size * 0.36,
                fontWeight: FontWeight.w700,
                height: 1.1,
              ),
            ),
          ),
          if (online)
            PositionedDirectional(
              bottom: 0,
              end: 0,
              child: Container(
                width: dot,
                height: dot,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: context.pal.online,
                  border: Border.all(color: context.pal.bg, width: 2.5),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ============================================================================ شعار التطبيق
class AppLogo extends StatelessWidget {
  const AppLogo({super.key, this.size = 72});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * 0.28),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF4C46E0).withValues(alpha: 0.35),
            blurRadius: size * 0.4,
            offset: Offset(0, size * 0.12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size * 0.28),
        child: Image.asset('assets/images/logo.png', width: size, height: size),
      ),
    );
  }
}

// ============================================================================ عناصر عامة
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actions = const [],
  });

  final IconData icon;
  final String title;
  final String message;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                color: p.brandSoft,
                borderRadius: BorderRadius.circular(32),
              ),
              child: Icon(icon, size: 44, color: p.brand),
            ),
            const SizedBox(height: 22),
            Text(title, textAlign: TextAlign.center, style: context.txt.titleLarge),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: context.txt.bodyMedium!.copyWith(color: p.muted),
            ),
            if (actions.isNotEmpty) ...[
              const SizedBox(height: 24),
              ...actions,
            ],
          ],
        ),
      ),
    );
  }
}

class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(20, 18, 20, 8),
      child: Text(
        text,
        style: context.txt.labelMedium!.copyWith(
          color: context.pal.muted,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.2,
        ),
      ),
    );
  }
}

class CardBox extends StatelessWidget {
  const CardBox({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin = const EdgeInsets.symmetric(horizontal: 16),
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry margin;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: p.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: p.line),
      ),
      child: child,
    );
  }
}

/// زر دائري بأيقونة وتسمية (يستخدم في شاشة جهة الاتصال)
class ActionTile extends StatelessWidget {
  const ActionTile({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Expanded(
      child: Material(
        color: p.card,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: p.line),
            ),
            child: Column(
              children: [
                Icon(icon, color: onTap == null ? p.muted : p.brand),
                const SizedBox(height: 6),
                Text(label, style: context.txt.labelMedium),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class StatusPill extends StatelessWidget {
  const StatusPill({super.key, required this.color, required this.label, this.pulse = false});
  final Color color;
  final String label;
  final bool pulse;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          pulse ? PulseDot(color: color, size: 7) : _Dot(color: color),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(
              fontFamily: kFont,
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: color,
              height: 1.2,
            ),
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  const _Dot({required this.color});
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        width: 7,
        height: 7,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      );
}

class PulseDot extends StatefulWidget {
  const PulseDot({super.key, required this.color, this.size = 8});
  final Color color;
  final double size;

  @override
  State<PulseDot> createState() => _PulseDotState();
}

class _PulseDotState extends State<PulseDot> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    return SizedBox(
      width: s * 2,
      height: s * 2,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: s * (1 + _c.value),
              height: s * (1 + _c.value),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.color.withValues(alpha: 0.35 * (1 - _c.value)),
              ),
            ),
            Container(
              width: s,
              height: s,
              decoration: BoxDecoration(shape: BoxShape.circle, color: widget.color),
            ),
          ],
        ),
      ),
    );
  }
}

/// حلقات نابضة حول الصورة الرمزية أثناء الرنين
class RingPulse extends StatefulWidget {
  const RingPulse({super.key, required this.child, required this.size, this.active = true});
  final Widget child;
  final double size;
  final bool active;

  @override
  State<RingPulse> createState() => _RingPulseState();
}

class _RingPulseState extends State<RingPulse> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.size * 1.9;
    return SizedBox(
      width: total,
      height: total,
      child: AnimatedBuilder(
        animation: _c,
        builder: (_, child) => Stack(
          alignment: Alignment.center,
          children: [
            if (widget.active)
              for (var i = 0; i < 3; i++)
                Builder(builder: (_) {
                  final t = (_c.value + i / 3) % 1.0;
                  final d = widget.size * (1 + 0.9 * t);
                  return Container(
                    width: d,
                    height: d,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.35 * (1 - t)),
                        width: 1.5,
                      ),
                    ),
                  );
                }),
            child!,
          ],
        ),
        child: widget.child,
      ),
    );
  }
}

// ============================================================================ أدوات
void showSnack(BuildContext context, String message, {IconData? icon}) {
  final m = ScaffoldMessenger.maybeOf(context);
  if (m == null) return;
  m
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, color: Colors.white, size: 20),
            const SizedBox(width: 10),
          ],
          Expanded(child: Text(message)),
        ],
      ),
      duration: const Duration(seconds: 3),
    ));
}

Future<void> copyText(BuildContext context, String text, String message) async {
  await Clipboard.setData(ClipboardData(text: text));
  HapticFeedback.lightImpact();
  if (context.mounted) showSnack(context, message, icon: Icons.check_circle_rounded);
}

Future<bool> confirmDialog(
  BuildContext context, {
  required String title,
  required String message,
  required String confirm,
  bool danger = false,
}) async {
  final p = context.pal;
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: Text('إلغاء', style: TextStyle(color: p.muted)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: Text(confirm, style: TextStyle(color: danger ? p.danger : p.brand)),
        ),
      ],
    ),
  );
  return ok == true;
}

Future<String?> promptText(
  BuildContext context, {
  required String title,
  String? initial,
  String hint = '',
  String confirm = 'حفظ',
}) async {
  final ctrl = TextEditingController(text: initial);
  final result = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctrl,
        autofocus: true,
        maxLength: 40,
        decoration: InputDecoration(hintText: hint, counterText: ''),
        onSubmitted: (v) => Navigator.pop(ctx, v),
      ),
      actionsPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: Text(confirm)),
      ],
    ),
  );
  ctrl.dispose();
  return result;
}

// ============================================================================ تنسيق الوقت والحجم
const _weekdays = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];

String clockTime(DateTime t) {
  final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
  final m = t.minute.toString().padLeft(2, '0');
  return '$h:$m ${t.hour < 12 ? 'ص' : 'م'}';
}

bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

/// للقوائم: الوقت اليوم، أمس، اسم اليوم خلال الأسبوع، أو التاريخ
String shortTime(DateTime t) {
  final now = DateTime.now();
  if (_sameDay(t, now)) return clockTime(t);
  if (_sameDay(t, now.subtract(const Duration(days: 1)))) return 'أمس';
  if (now.difference(t).inDays < 7) return _weekdays[t.weekday - 1];
  return '${t.day}/${t.month}/${t.year}';
}

/// لفواصل الأيام داخل المحادثة
String dayLabel(DateTime t) {
  final now = DateTime.now();
  if (_sameDay(t, now)) return 'اليوم';
  if (_sameDay(t, now.subtract(const Duration(days: 1)))) return 'أمس';
  if (now.difference(t).inDays < 7) return _weekdays[t.weekday - 1];
  return '${t.day}/${t.month}/${t.year}';
}

bool sameDay(DateTime a, DateTime b) => _sameDay(a, b);

String fileSize(int? bytes) {
  if (bytes == null || bytes <= 0) return '';
  if (bytes < 1024) return '$bytes بايت';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} ك.ب';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} م.ب';
}
