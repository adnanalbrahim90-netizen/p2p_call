import 'package:flutter/material.dart';

import '../../app/theme.dart';

const _categories = <(IconData, String)>[
  (Icons.emoji_emotions_outlined,
      '😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 😉 😊 😇 🥰 😍 🤩 😘 😗 😚 😙 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🤫 🤔 🤐 🤨 😐 😑 😶 😏 😒 🙄 😬 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🥵 🥶 😵 🤯 🤠 🥳 😎 🤓 🧐 😕 😟 🙁 😮 😯 😲 😳 🥺 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬'),
  (Icons.waving_hand_outlined,
      '👍 👎 👌 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 👏 🙌 👐 🤲 💪 ✍️ 🤳 💅 👀 👁️ 🧠 🫶 🙋 🙆 🙅 🤷 🤦 🙇 💁 🧕 👳 👨‍👩‍👧 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵'),
  (Icons.favorite_border_rounded,
      '❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💟 ☪️ 🕋 🕌 📿 🤲 ✨ ⭐ 🌟 💫 🔥 💯 ✅ ❌ ⭕ ❗ ❓ 💤 💢 💬 💭 🎉 🎊 🎁 🎈 🏆 🥇 🎯'),
  (Icons.pets_outlined,
      '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🦅 🦉 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🦎 🐙 🐬 🐳 🐟 🐪 🐫 🦒 🐘 🌵 🌴 🌲 🌳 🌱 🌿 🍀 🌷 🌹 🌺 🌸 🌼 🌻 🌞 🌙 ⛅ 🌧️ ⛈️ ❄️ 🌊'),
  (Icons.restaurant_outlined,
      '☕ 🍵 🧃 🥤 🍹 🍰 🎂 🧁 🍩 🍪 🍫 🍬 🍭 🍯 🍎 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥕 🌽 🥔 🍞 🥐 🧀 🥚 🍳 🥞 🍗 🍖 🍔 🍟 🍕 🌯 🥙 🍛 🍚 🍜 🍝 🍣 🍤 🍦 🍨 🌰 🫖'),
  (Icons.flight_outlined,
      '⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🏸 🥊 🏊 🚴 🏃 🧗 🏋️ 🎮 🎲 🎨 🎬 🎤 🎧 🎵 🎶 📚 ✏️ 💼 💻 📱 ☎️ 📷 🎥 💡 🔑 🔒 🛒 💰 💳 📦 ✉️ 📅 ⏰ 🚗 🚕 🚌 🏍️ 🚲 ✈️ 🚀 🛳️ 🏠 🏢 🏝️ 🏜️ 🏔️ 🗺️ 🧭'),
];

/// لوحة الإيموجي المدمجة (بدون مكتبات خارجية)
class EmojiPanel extends StatefulWidget {
  const EmojiPanel({super.key, required this.onPick, required this.onBackspace, this.height = 290});
  final ValueChanged<String> onPick;
  final VoidCallback onBackspace;
  final double height;

  @override
  State<EmojiPanel> createState() => _EmojiPanelState();
}

class _EmojiPanelState extends State<EmojiPanel> {
  int _cat = 0;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final items = _categories[_cat].$2.split(' ').where((e) => e.isNotEmpty).toList();
    return Container(
      height: widget.height,
      color: p.card,
      child: Column(
        children: [
          Container(
            height: 46,
            decoration: BoxDecoration(border: Border(bottom: BorderSide(color: p.line))),
            child: Row(
              children: [
                for (var i = 0; i < _categories.length; i++)
                  Expanded(
                    child: InkWell(
                      onTap: () => setState(() => _cat = i),
                      child: Container(
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          border: Border(
                            bottom: BorderSide(
                              color: i == _cat ? p.brand : Colors.transparent,
                              width: 2.5,
                            ),
                          ),
                        ),
                        child: Icon(_categories[i].$1,
                            size: 21, color: i == _cat ? p.brand : p.muted),
                      ),
                    ),
                  ),
                IconButton(
                  onPressed: widget.onBackspace,
                  icon: Icon(Icons.backspace_outlined, size: 21, color: p.muted),
                ),
              ],
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(8),
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                maxCrossAxisExtent: 46,
                mainAxisSpacing: 2,
                crossAxisSpacing: 2,
              ),
              itemCount: items.length,
              itemBuilder: (context, i) => InkWell(
                borderRadius: BorderRadius.circular(10),
                onTap: () => widget.onPick(items[i]),
                child: Center(
                  child: Text(items[i], style: const TextStyle(fontSize: 27, height: 1.1)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
