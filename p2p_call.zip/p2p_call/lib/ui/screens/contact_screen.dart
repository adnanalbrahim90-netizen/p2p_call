import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/identity.dart';
import '../../core/models.dart';
import '../widgets/common.dart';
import 'call_actions.dart';

/// معلومات جهة الاتصال: الاسم، رمز الأمان، الحذف
class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key, required this.contact});
  final Contact contact;

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(),
      body: ListenableBuilder(
        listenable: Listenable.merge([c.store, c.links, c.relay]),
        builder: (context, _) {
          final online = c.isOnline(contact.id);
          return ListView(
            padding: const EdgeInsets.only(bottom: 32),
            children: [
              Center(child: Avatar(name: contact.displayName, seed: contact.id, size: 112, online: online)),
              const SizedBox(height: 16),
              Text(contact.displayName, textAlign: TextAlign.center, style: context.txt.headlineSmall),
              if (contact.nickname != null && contact.nickname!.isNotEmpty && contact.name.isNotEmpty)
                Text('الاسم الأصلي: ${contact.name}',
                    textAlign: TextAlign.center, style: context.txt.bodySmall),
              const SizedBox(height: 4),
              Text(
                online ? 'متصل الآن' : 'غير متصل',
                textAlign: TextAlign.center,
                style: context.txt.labelMedium!.copyWith(color: online ? p.success : p.muted),
              ),
              const SizedBox(height: 22),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    ActionTile(
                      icon: Icons.chat_bubble_outline_rounded,
                      label: 'رسالة',
                      onTap: () => Navigator.of(context).pop(),
                    ),
                    const SizedBox(width: 10),
                    ActionTile(
                      icon: Icons.call_outlined,
                      label: 'صوت',
                      onTap: () => startCallFlow(context, contact, video: false),
                    ),
                    const SizedBox(width: 10),
                    ActionTile(
                      icon: Icons.videocam_outlined,
                      label: 'فيديو',
                      onTap: () => startCallFlow(context, contact, video: true),
                    ),
                  ],
                ),
              ),
              const SectionLabel('الخصوصية والأمان'),
              CardBox(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.verified_user_rounded, color: p.brand, size: 20),
                        const SizedBox(width: 8),
                        Text('رمز الأمان', style: context.txt.titleSmall),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Center(
                      child: Text(
                        c.identity!.safetyCode(contact.publicKey),
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.ltr,
                        style: context.txt.titleMedium!.copyWith(
                          letterSpacing: 2,
                          height: 1.7,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'قارن هذه الأرقام مع ما يظهر على هاتف ${contact.displayName}. '
                      'إن تطابقت فاتصالكما مشفّر ولا يمكن لأحد التنصّت عليه.',
                      style: context.txt.bodySmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'المعرّف: ${prettyId(contact.id)}',
                      textDirection: TextDirection.rtl,
                      style: context.txt.bodySmall,
                    ),
                  ],
                ),
              ),
              const SectionLabel('إدارة'),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.edit_outlined),
                      title: const Text('تعديل الاسم'),
                      onTap: () async {
                        final v = await promptText(
                          context,
                          title: 'اسم جهة الاتصال',
                          initial: contact.displayName,
                          hint: contact.name,
                        );
                        if (v == null) return;
                        contact.nickname = v.trim().isEmpty ? null : v.trim();
                        c.store.updateContact(contact);
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.cleaning_services_outlined),
                      title: const Text('مسح المحادثة'),
                      onTap: () async {
                        if (await confirmDialog(
                          context,
                          title: 'مسح المحادثة؟',
                          message: 'ستُحذف الرسائل والوسائط من هذا الجهاز فقط.',
                          confirm: 'مسح',
                          danger: true,
                        )) {
                          await c.store.clearChat(contact.id);
                        }
                      },
                    ),
                    ListTile(
                      leading: Icon(Icons.person_remove_outlined, color: p.danger),
                      title: Text('حذف جهة الاتصال', style: TextStyle(color: p.danger)),
                      onTap: () async {
                        if (await confirmDialog(
                          context,
                          title: 'حذف ${contact.displayName}؟',
                          message: 'ستُحذف جهة الاتصال والمحادثة. يمكنك إضافتها لاحقاً بمسح رمزها.',
                          confirm: 'حذف',
                          danger: true,
                        )) {
                          await c.deleteContact(contact);
                          if (context.mounted) {
                            Navigator.of(context).popUntil((r) => r.isFirst);
                          }
                        }
                      },
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
