import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/models.dart';
import '../../net/calls.dart';
import '../widgets/common.dart';
import 'call_actions.dart';
import 'home_screen.dart';

class CallsTab extends StatelessWidget {
  const CallsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    return SafeArea(
      bottom: false,
      child: ListenableBuilder(
        listenable: c.store,
        builder: (context, _) {
          final logs = c.store.calls.where((l) => c.store.contact(l.contactId) != null).toList();
          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: TabHeader(
                  title: 'المكالمات',
                  actions: [
                    if (logs.isNotEmpty)
                      PopupMenuButton<String>(
                        icon: const Icon(Icons.more_vert_rounded),
                        onSelected: (v) async {
                          if (v == 'clear' &&
                              await confirmDialog(
                                context,
                                title: 'مسح سجل المكالمات؟',
                                message: 'سيتم حذف السجل من هذا الجهاز فقط.',
                                confirm: 'مسح',
                                danger: true,
                              )) {
                            c.store.clearCalls();
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'clear', child: Text('مسح السجل')),
                        ],
                      ),
                  ],
                ),
              ),
              if (logs.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                    icon: Icons.call_rounded,
                    title: 'لا توجد مكالمات بعد',
                    message: 'افتح أي محادثة واضغط على أيقونة الهاتف أو الكاميرا للاتصال مباشرة.',
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.only(top: 8, bottom: 24),
                  sliver: SliverList.builder(
                    itemCount: logs.length,
                    itemBuilder: (context, i) => _CallTile(log: logs[i]),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _CallTile extends StatelessWidget {
  const _CallTile({required this.log});
  final CallLog log;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = AppController.I;
    final contact = c.store.contact(log.contactId)!;
    final missed = log.result == CallResult.missed && log.incoming;
    final bad = log.result != CallResult.answered;
    final color = missed ? p.danger : p.muted;
    String detail;
    switch (log.result) {
      case CallResult.answered:
        detail = formatDuration(log.duration);
        break;
      case CallResult.missed:
        detail = log.incoming ? 'فائتة' : 'لا يوجد رد';
        break;
      case CallResult.declined:
        detail = 'مرفوضة';
        break;
      case CallResult.cancelled:
        detail = 'ملغاة';
        break;
      case CallResult.failed:
        detail = 'تعذّر الاتصال';
        break;
    }

    return InkWell(
      onTap: () => openChat(context, contact),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 9),
        child: Row(
          children: [
            Avatar(name: contact.displayName, seed: contact.id, size: 50),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    contact.displayName,
                    style: context.txt.titleMedium!.copyWith(color: missed ? p.danger : p.text),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(
                        log.incoming ? Icons.call_received_rounded : Icons.call_made_rounded,
                        size: 16,
                        color: bad ? color : p.success,
                      ),
                      const SizedBox(width: 4),
                      Icon(log.video ? Icons.videocam_outlined : Icons.call_outlined,
                          size: 15, color: p.muted),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          '${shortTime(log.time)}  •  $detail',
                          style: context.txt.bodySmall,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            IconButton(
              tooltip: log.video ? 'مكالمة فيديو' : 'مكالمة صوتية',
              onPressed: () => startCallFlow(context, contact, video: log.video),
              icon: Icon(log.video ? Icons.videocam_rounded : Icons.call_rounded, color: p.brand),
            ),
          ],
        ),
      ),
    );
  }
}
