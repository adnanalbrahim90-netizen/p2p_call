import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/models.dart';
import '../../net/native.dart';
import '../widgets/common.dart';
import '../widgets/emoji_panel.dart';
import 'call_actions.dart';
import 'contact_screen.dart';
import 'group_info_screen.dart';
import 'media_viewer.dart';

/// محادثة فردية أو جماعية
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.chatId});
  final String chatId;

  static Route<void> route(String chatId) =>
      MaterialPageRoute<void>(builder: (_) => ChatScreen(chatId: chatId));

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _text = TextEditingController();
  final _focus = FocusNode();
  final _picker = ImagePicker();
  List<ChatMessage>? _messages;
  bool _emoji = false;
  DateTime _lastTyping = DateTime.fromMillisecondsSinceEpoch(0);

  AppController get c => AppController.I;
  String get chatId => widget.chatId;
  bool get isGroup => isGroupChat(chatId);
  Contact? get contact => isGroup ? null : c.store.contact(chatId);
  Group? get group => isGroup ? c.store.group(groupIdOf(chatId)) : null;
  String get title => c.store.titleOf(chatId);
  String get seed => isGroup ? groupIdOf(chatId) : chatId;

  @override
  void initState() {
    super.initState();
    c.links?.activeChat = chatId;
    c.store.markRead(chatId);
    NativeBridge.cancelChatNotification(chatId);
    c.store.loadChat(chatId).then((list) {
      if (mounted) setState(() => _messages = list);
    });
    c.links?.warmUp(chatId);
    c.store.addListener(_onStore);
    _focus.addListener(() {
      if (_focus.hasFocus && _emoji) setState(() => _emoji = false);
    });
    _text.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    if (c.links?.activeChat == chatId) c.links?.activeChat = null;
    c.store.removeListener(_onStore);
    _text.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onStore() {
    final unread = isGroup ? (group?.unread ?? 0) : (contact?.unread ?? 0);
    if (unread > 0) scheduleMicrotask(() => c.store.markRead(chatId));
  }

  void _onTextChanged() {
    setState(() {});
    final now = DateTime.now();
    if (_text.text.isNotEmpty && now.difference(_lastTyping).inSeconds >= 3) {
      _lastTyping = now;
      c.links?.sendTyping(chatId);
    }
  }

  void _send() {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    c.links?.sendText(chatId, t);
    _text.clear();
    HapticFeedback.selectionClick();
  }

  void _toggleEmoji() {
    if (_emoji) {
      setState(() => _emoji = false);
      _focus.requestFocus();
    } else {
      _focus.unfocus();
      SystemChannels.textInput.invokeMethod<void>('TextInput.hide');
      setState(() => _emoji = true);
    }
  }

  void _insertEmoji(String e) {
    final v = _text.value;
    final sel = v.selection.isValid ? v.selection : TextSelection.collapsed(offset: v.text.length);
    _text.value = TextEditingValue(
      text: v.text.replaceRange(sel.start, sel.end, e),
      selection: TextSelection.collapsed(offset: sel.start + e.length),
    );
  }

  void _backspace() {
    final v = _text.value;
    if (v.text.isEmpty) return;
    final sel = v.selection.isValid ? v.selection : TextSelection.collapsed(offset: v.text.length);
    if (!sel.isCollapsed) {
      _text.value = TextEditingValue(
        text: v.text.replaceRange(sel.start, sel.end, ''),
        selection: TextSelection.collapsed(offset: sel.start),
      );
      return;
    }
    if (sel.start == 0) return;
    final trimmed = v.text.substring(0, sel.start).characters.skipLast(1).toString();
    _text.value = TextEditingValue(
      text: trimmed + v.text.substring(sel.start),
      selection: TextSelection.collapsed(offset: trimmed.length),
    );
  }

  // ----------------------------------------------------------------- المرفقات
  Future<void> _attach() async {
    final p = context.pal;
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Row(
            children: [
              _AttachOption(icon: Icons.photo_library_rounded, label: 'صور', color: p.brand, value: 'photos'),
              const _AttachOption(icon: Icons.video_library_rounded, label: 'فيديو', color: Color(0xFFE5484D), value: 'video'),
              const _AttachOption(icon: Icons.photo_camera_rounded, label: 'الكاميرا', color: Color(0xFF12B76A), value: 'camera'),
              const _AttachOption(icon: Icons.videocam_rounded, label: 'تصوير فيديو', color: Color(0xFFE89B0C), value: 'record'),
            ],
          ),
        ),
      ),
    );
    if (choice == null) return;
    c.suppressLock();
    try {
      switch (choice) {
        case 'photos':
          final files = await _picker.pickMultiImage(imageQuality: 82, maxWidth: 2048, maxHeight: 2048);
          for (final f in files) {
            await c.links?.sendFile(chatId, f.path, MessageKind.image, mime: 'image/jpeg');
          }
          break;
        case 'video':
          final v = await _picker.pickVideo(source: ImageSource.gallery);
          if (v != null) await _sendVideo(v.path);
          break;
        case 'camera':
          if (!await _cameraAllowed()) return;
          final f = await _picker.pickImage(source: ImageSource.camera, imageQuality: 82, maxWidth: 2048);
          if (f != null) await c.links?.sendFile(chatId, f.path, MessageKind.image, mime: 'image/jpeg');
          break;
        case 'record':
          if (!await _cameraAllowed()) return;
          final v = await _picker.pickVideo(source: ImageSource.camera, maxDuration: const Duration(minutes: 3));
          if (v != null) await _sendVideo(v.path);
          break;
      }
    } catch (e) {
      if (mounted) showSnack(context, 'تعذّر إرفاق الملف');
    }
  }

  Future<bool> _cameraAllowed() async {
    final st = await Permission.camera.request();
    if (st.isGranted) return true;
    if (mounted) showSnack(context, 'يلزم إذن الكاميرا');
    return false;
  }

  Future<void> _sendVideo(String path) async {
    final size = await File(path).length();
    final limit = isGroup ? 100 : 300;
    if (size > limit * 1024 * 1024) {
      if (mounted) showSnack(context, 'الفيديو أكبر من $limit م.ب');
      return;
    }
    await c.links?.sendFile(chatId, path, MessageKind.video, mime: 'video/mp4');
  }

  // ----------------------------------------------------------------- إجراءات الرسالة
  Future<void> _messageActions(ChatMessage m) async {
    if (m.isNotice) return;
    final p = context.pal;
    final gs = c.groups;
    final canAll = gs?.canDeleteForAll(m) ?? false;
    final asAdmin = canAll && !m.mine;
    HapticFeedback.mediumImpact();
    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (m.kind == MessageKind.text && !m.deleted)
              ListTile(
                leading: const Icon(Icons.copy_rounded),
                title: const Text('نسخ'),
                onTap: () => Navigator.pop(ctx, 'copy'),
              ),
            if (m.mine && m.status == MessageStatus.failed)
              ListTile(
                leading: const Icon(Icons.refresh_rounded),
                title: const Text('إعادة الإرسال'),
                onTap: () => Navigator.pop(ctx, 'retry'),
              ),
            if (canAll)
              ListTile(
                leading: Icon(asAdmin ? Icons.shield_outlined : Icons.delete_sweep_outlined, color: p.danger),
                title: Text(asAdmin ? 'حذف للجميع (كمشرف)' : 'حذف للجميع', style: TextStyle(color: p.danger)),
                onTap: () => Navigator.pop(ctx, 'all'),
              ),
            ListTile(
              leading: Icon(Icons.delete_outline_rounded, color: p.danger),
              title: Text('حذف من هذا الجهاز', style: TextStyle(color: p.danger)),
              onTap: () => Navigator.pop(ctx, 'delete'),
            ),
          ],
        ),
      ),
    );
    if (!mounted) return;
    switch (action) {
      case 'copy':
        copyText(context, m.text ?? '', 'تم النسخ');
        break;
      case 'retry':
        c.links?.resend(m);
        break;
      case 'all':
        if (await confirmDialog(
          context,
          title: 'حذف للجميع؟',
          message: 'ستُحذف الرسالة من أجهزة كل المشاركين في المحادثة.',
          confirm: 'حذف',
          danger: true,
        )) {
          await gs?.deleteForAll(m);
        }
        break;
      case 'delete':
        c.store.deleteMessage(m);
        break;
    }
  }

  void _openMedia(ChatMessage m) {
    final path = m.filePath;
    if (path == null || !File(path).existsSync() || m.status == MessageStatus.receiving) return;
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => m.kind == MessageKind.video
          ? VideoViewer(path: path)
          : ImageViewer(path: path, heroTag: 'img-${m.id}'),
    ));
  }

  void _openInfo() {
    final g = group;
    final ct = contact;
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => g != null ? GroupInfoScreen(groupId: g.id) : ContactScreen(contact: ct!),
    ));
  }

  Future<void> _call(bool video) async {
    final g = group;
    if (g != null) {
      await startGroupCallFlow(context, g, video: video);
    } else if (contact != null) {
      await startCallFlow(context, contact!, video: video);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return ListenableBuilder(
      listenable: c.store,
      builder: (context, _) {
        // حُذفت المحادثة (مثلاً حذف جهة الاتصال)
        if (contact == null && group == null) {
          return Scaffold(appBar: AppBar(), body: const SizedBox.shrink());
        }
        return PopScope(
          canPop: !_emoji,
          onPopInvokedWithResult: (didPop, _) {
            if (!didPop && _emoji) setState(() => _emoji = false);
          },
          child: Scaffold(
            backgroundColor: p.chatBg,
            appBar: _appBar(context),
            body: Column(
              children: [
                _banners(context),
                Expanded(child: _list(context)),
                _bottom(context),
                if (_emoji)
                  Container(
                    color: p.card,
                    padding: EdgeInsets.only(bottom: MediaQuery.paddingOf(context).bottom),
                    child: EmojiPanel(onPick: _insertEmoji, onBackspace: _backspace),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _appBar(BuildContext context) {
    final p = context.pal;
    final g = group;
    return AppBar(
      backgroundColor: p.card,
      titleSpacing: 0,
      shape: Border(bottom: BorderSide(color: p.line)),
      title: ListenableBuilder(
        listenable: Listenable.merge([c.links, c.relay]),
        builder: (context, _) {
          String sub;
          Color color = p.muted;
          final typing = c.links?.typingIn(chatId);
          var online = false;
          if (g != null) {
            if (typing != null) {
              sub = '$typing يكتب…';
              color = p.brand;
            } else if (g.left) {
              sub = 'لم تعد عضواً';
            } else {
              final on = c.onlineMembers(g);
              sub = '${g.members.length} أعضاء${on > 0 ? ' • $on متصل' : ''}';
            }
          } else {
            online = c.isOnline(chatId);
            final linked = c.links?.isLinked(chatId) ?? false;
            final connecting = c.links?.isConnecting(chatId) ?? false;
            if (typing != null) {
              sub = 'يكتب…';
              color = p.brand;
            } else if (linked) {
              sub = 'متصل الآن • مباشر';
              color = p.success;
            } else if (connecting) {
              sub = 'جارٍ الربط المباشر…';
            } else if (online) {
              sub = 'متصل الآن';
              color = p.success;
            } else {
              sub = 'غير متصل';
            }
          }
          return InkWell(
            onTap: _openInfo,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  g != null
                      ? GroupAvatar(name: title, seed: seed, size: 40)
                      : Avatar(name: title, seed: seed, size: 40, online: online),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.txt.titleMedium),
                        Text(sub,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: context.txt.labelSmall!.copyWith(color: color, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      actions: [
        if (g == null || !g.left) ...[
          IconButton(
            tooltip: g != null ? 'مكالمة فيديو جماعية' : 'مكالمة فيديو',
            onPressed: () => _call(true),
            icon: const Icon(Icons.videocam_outlined),
          ),
          IconButton(
            tooltip: g != null ? 'مكالمة صوتية جماعية' : 'مكالمة صوتية',
            onPressed: () => _call(false),
            icon: const Icon(Icons.call_outlined),
          ),
        ],
        const SizedBox(width: 4),
      ],
    );
  }

  Widget _banner(BuildContext context, IconData icon, String text, {Widget? action, Color? color}) {
    final p = context.pal;
    final fg = color ?? p.brand;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(16, action == null ? 9 : 4, 8, action == null ? 9 : 4),
      color: fg.withValues(alpha: 0.10),
      child: Row(
        children: [
          Icon(icon, size: 18, color: fg),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: context.txt.labelMedium!.copyWith(color: fg))),
          if (action != null) action,
        ],
      ),
    );
  }

  Widget _banners(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([c.links, c.relay, c.groupCalls]),
      builder: (context, _) {
        final p = context.pal;
        final g = group;
        final msgs = _messages ?? const <ChatMessage>[];
        if (g != null) {
          final gcid = c.groupCalls?.activeCallIn(g.id);
          final inIt = c.groupCalls?.current?.gcid == gcid;
          if (gcid != null && !inIt && !g.left) {
            final video = c.groupCalls?.active[g.id]?.$2 ?? false;
            return _banner(
              context,
              video ? Icons.videocam_rounded : Icons.call_rounded,
              'مكالمة ${video ? 'فيديو' : 'صوتية'} جماعية جارية',
              color: p.success,
              action: FilledButton(
                style: FilledButton.styleFrom(
                  minimumSize: const Size(72, 36),
                  backgroundColor: p.success,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                ),
                onPressed: () => joinGroupCallFlow(context, g, gcid, video: video),
                child: const Text('انضم'),
              ),
            );
          }
          return const SizedBox.shrink();
        }
        final ct = contact;
        if (ct == null) return const SizedBox.shrink();
        if (!ct.confirmed) {
          return _banner(context, Icons.hourglass_top_rounded,
              'بانتظار أن يقبل ${ct.displayName} طلب الإضافة — ستصل رسائلك بعد القبول');
        }
        final pending = msgs.any((m) => m.mine && m.status == MessageStatus.pending);
        if (!pending || (c.links?.isLinked(chatId) ?? false)) return const SizedBox.shrink();
        final online = c.isOnline(chatId);
        return _banner(
          context,
          online ? Icons.sync_rounded : Icons.schedule_rounded,
          online
              ? 'جارٍ إنشاء اتصال مباشر لإرسال الرسائل…'
              : 'ستُرسل الرسائل تلقائياً عندما يتصل ${ct.displayName}',
        );
      },
    );
  }

  Widget _list(BuildContext context) {
    final msgs = _messages;
    if (msgs == null) return const Center(child: CircularProgressIndicator());
    if (msgs.isEmpty) return _emptyChat(context);
    final g = group;
    return ListView.builder(
      reverse: true,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      itemCount: msgs.length,
      itemBuilder: (context, i) {
        final idx = msgs.length - 1 - i;
        final m = msgs[idx];
        final prev = idx > 0 ? msgs[idx - 1] : null;
        final next = idx < msgs.length - 1 ? msgs[idx + 1] : null;
        final showDay = prev == null || !sameDay(prev.time, m.time);
        bool sameRun(ChatMessage? a, ChatMessage b) =>
            a != null &&
            !a.isNotice &&
            !b.isNotice &&
            a.mine == b.mine &&
            a.senderId == b.senderId &&
            sameDay(a.time, b.time) &&
            b.time.difference(a.time).inMinutes.abs() < 3;
        final groupedWithNext = sameRun(next, m);
        final firstOfRun = !sameRun(prev, m) || showDay;
        return Column(
          children: [
            if (showDay) _DayChip(label: dayLabel(m.time)),
            if (m.kind == MessageKind.call)
              _CallChip(message: m)
            else if (m.kind == MessageKind.system)
              _SystemChip(text: m.text ?? '')
            else
              MessageBubble(
                message: m,
                tail: !groupedWithNext,
                senderLabel: g != null && !m.mine && firstOfRun
                    ? c.store.nameOf(m.senderId ?? '', fallback: m.senderName ?? 'عضو')
                    : null,
                senderAdmin: g != null && m.senderId != null && g.isAdmin(m.senderId!),
                onLongPress: () => _messageActions(m),
                onOpen: () => _openMedia(m),
                onRetry: () => c.links?.resend(m),
              ),
          ],
        );
      },
    );
  }

  Widget _emptyChat(BuildContext context) {
    final p = context.pal;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            isGroup
                ? GroupAvatar(name: title, seed: seed, size: 76)
                : Avatar(name: title, seed: seed, size: 76),
            const SizedBox(height: 14),
            Text(title, style: context.txt.titleLarge, textAlign: TextAlign.center),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: p.card,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: p.line),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.lock_outline_rounded, size: 16, color: p.muted),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      'الرسائل والمكالمات مباشرة ومشفّرة طرفاً لطرف',
                      style: context.txt.labelMedium!.copyWith(color: p.muted),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 8,
              children: ['السلام عليكم 👋', 'مرحباً!', '🙂']
                  .map((s) => ActionChip(label: Text(s), onPressed: () => c.links?.sendText(chatId, s)))
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }

  /// شريط الكتابة، أو رسالة تمنع الكتابة (مغادرة / للمشرفين فقط)
  Widget _bottom(BuildContext context) {
    final g = group;
    final p = context.pal;
    String? blocked;
    if (g != null && g.left) blocked = 'لم تعد عضواً في هذا القروب';
    if (g != null && !g.left && g.adminsOnly && !g.isAdmin(c.store.selfId)) {
      blocked = 'المشرفون فقط يمكنهم الإرسال في هذا القروب';
    }
    if (blocked != null) {
      return Container(
        width: double.infinity,
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.paddingOf(context).bottom),
        decoration: BoxDecoration(color: p.card, border: Border(top: BorderSide(color: p.line))),
        child: Text(blocked, textAlign: TextAlign.center, style: context.txt.bodyMedium!.copyWith(color: p.muted)),
      );
    }
    return _composer(context);
  }

  Widget _composer(BuildContext context) {
    final p = context.pal;
    final hasText = _text.text.trim().isNotEmpty;
    return Container(
      padding: EdgeInsets.fromLTRB(8, 8, 8, _emoji ? 8 : 8 + MediaQuery.paddingOf(context).bottom),
      decoration: BoxDecoration(color: p.card, border: Border(top: BorderSide(color: p.line))),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(color: p.subtle, borderRadius: BorderRadius.circular(24)),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  IconButton(
                    onPressed: _toggleEmoji,
                    icon: Icon(_emoji ? Icons.keyboard_rounded : Icons.emoji_emotions_outlined, color: p.muted),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _text,
                      focusNode: _focus,
                      minLines: 1,
                      maxLines: 5,
                      textCapitalization: TextCapitalization.sentences,
                      keyboardType: TextInputType.multiline,
                      style: context.txt.bodyLarge,
                      decoration: const InputDecoration(
                        hintText: 'اكتب رسالة',
                        filled: false,
                        border: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(vertical: 12),
                        isDense: true,
                      ),
                    ),
                  ),
                  if (!hasText)
                    IconButton(onPressed: _attach, icon: Icon(Icons.attach_file_rounded, color: p.muted)),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          Material(
            color: p.brand,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: hasText ? _send : _attach,
              child: SizedBox(
                width: 48,
                height: 48,
                child: Icon(
                  hasText ? Icons.send_rounded : Icons.add_photo_alternate_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _AttachOption extends StatelessWidget {
  const _AttachOption({required this.icon, required this.label, required this.color, required this.value});
  final IconData icon;
  final String label;
  final Color color;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.pop(context, value),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(icon, color: color, size: 28),
              ),
              const SizedBox(height: 8),
              Text(label, style: context.txt.labelMedium),
            ],
          ),
        ),
      ),
    );
  }
}

class _DayChip extends StatelessWidget {
  const _DayChip({required this.label});
  final String label;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(
          color: p.card,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: p.line),
        ),
        child: Text(label, style: context.txt.labelSmall!.copyWith(fontWeight: FontWeight.w600)),
      ),
    );
  }
}

class _SystemChip extends StatelessWidget {
  const _SystemChip({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 24),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: p.brandSoft,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: context.txt.labelMedium!.copyWith(color: p.brand),
        ),
      ),
    );
  }
}

class _CallChip extends StatelessWidget {
  const _CallChip({required this.message});
  final ChatMessage message;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final text = message.text ?? 'مكالمة';
    final bad = text.contains('فائتة') || text.contains('مرفوضة') || text.contains('تعذّر') || text.contains('لا يوجد') || text.contains('لم ينضم');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: p.card,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: p.line),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(text.contains('فيديو') ? Icons.videocam_rounded : Icons.call_rounded,
                size: 17, color: bad ? p.danger : p.success),
            const SizedBox(width: 8),
            Flexible(child: Text(text, style: context.txt.labelMedium)),
            const SizedBox(width: 8),
            Text(clockTime(message.time), style: context.txt.labelSmall),
          ],
        ),
      ),
    );
  }
}

/// فقاعة الرسالة (نص / صورة / فيديو / محذوفة)
class MessageBubble extends StatelessWidget {
  const MessageBubble({
    super.key,
    required this.message,
    required this.tail,
    required this.onLongPress,
    required this.onOpen,
    required this.onRetry,
    this.senderLabel,
    this.senderAdmin = false,
  });

  final ChatMessage message;
  final bool tail;
  final String? senderLabel;
  final bool senderAdmin;
  final VoidCallback onLongPress;
  final VoidCallback onOpen;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final m = message;
    final mine = m.mine;
    final bg = mine ? p.mine : p.theirs;
    final fg = mine ? p.onMine : p.onTheirs;
    const r = Radius.circular(20);
    const small = Radius.circular(6);
    final radius = BorderRadiusDirectional.only(
      topStart: r,
      topEnd: r,
      bottomStart: !mine && tail ? small : r,
      bottomEnd: mine && tail ? small : r,
    );
    final maxW = MediaQuery.sizeOf(context).width * 0.78;

    Widget content;
    if (m.deleted) {
      content = Padding(
        padding: const EdgeInsets.fromLTRB(14, 9, 14, 7),
        child: Wrap(
          crossAxisAlignment: WrapCrossAlignment.end,
          spacing: 8,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.block_rounded, size: 16, color: fg.withValues(alpha: 0.6)),
                const SizedBox(width: 6),
                Text('تم حذف هذه الرسالة',
                    style: TextStyle(
                        fontFamily: kFont, fontSize: 14.5, fontStyle: FontStyle.italic, color: fg.withValues(alpha: 0.7))),
              ],
            ),
            _Meta(message: m, color: fg.withValues(alpha: 0.6)),
          ],
        ),
      );
    } else if (m.isFile) {
      content = _media(context, fg);
    } else {
      content = Padding(
        padding: const EdgeInsets.fromLTRB(14, 9, 14, 7),
        child: Wrap(
          alignment: WrapAlignment.end,
          crossAxisAlignment: WrapCrossAlignment.end,
          spacing: 8,
          children: [
            Text(m.text ?? '', style: TextStyle(fontFamily: kFont, fontSize: 15.5, height: 1.45, color: fg)),
            _Meta(message: m, color: fg.withValues(alpha: 0.7)),
          ],
        ),
      );
    }

    if (senderLabel != null) {
      final colors = avatarColors(m.senderId ?? senderLabel!);
      content = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(14, 8, 14, 0),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Flexible(
                  child: Text(
                    senderLabel!,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: kFont,
                      fontSize: 12.5,
                      fontWeight: FontWeight.w700,
                      color: context.isDark ? colors.first : colors.last,
                    ),
                  ),
                ),
                if (senderAdmin) ...[
                  const SizedBox(width: 4),
                  Icon(Icons.verified_rounded, size: 13, color: p.brand),
                ],
              ],
            ),
          ),
          content,
        ],
      );
    }

    return Padding(
      padding: EdgeInsets.only(top: 2, bottom: tail ? 6 : 1),
      child: Row(
        mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (mine && m.status == MessageStatus.failed && !m.deleted)
            IconButton(onPressed: onRetry, icon: Icon(Icons.error_outline_rounded, color: p.danger)),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxW),
            child: Material(
              color: bg,
              borderRadius: radius,
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onLongPress: onLongPress,
                onTap: m.isFile && !m.deleted ? onOpen : null,
                child: Container(
                  decoration: mine ? null : BoxDecoration(borderRadius: radius, border: Border.all(color: p.line)),
                  child: content,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _media(BuildContext context, Color fg) {
    final m = message;
    final path = m.filePath;
    final exists = path != null && File(path).existsSync();
    final transferring = m.status == MessageStatus.sending || m.status == MessageStatus.receiving;
    final ready = exists && m.status != MessageStatus.receiving;

    Widget visual;
    if (m.kind == MessageKind.image && ready) {
      visual = Hero(
        tag: 'img-${m.id}',
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 260, maxHeight: 340, minWidth: 140, minHeight: 100),
          child: Image.file(
            File(path),
            fit: BoxFit.cover,
            cacheWidth: 720,
            errorBuilder: (_, __, ___) => _placeholder(Icons.broken_image_outlined),
          ),
        ),
      );
    } else if (m.kind == MessageKind.video) {
      visual = Container(
        width: 250,
        height: 160,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF26284A), Color(0xFF0F1022)],
          ),
        ),
        child: Stack(
          children: [
            Center(
              child: Container(
                width: 54,
                height: 54,
                decoration: const BoxDecoration(color: Colors.white24, shape: BoxShape.circle),
                child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 34),
              ),
            ),
            PositionedDirectional(
              start: 10,
              top: 10,
              child: Row(
                children: [
                  const Icon(Icons.videocam_rounded, color: Colors.white70, size: 16),
                  const SizedBox(width: 4),
                  Text(fileSize(m.fileSize),
                      style: const TextStyle(fontFamily: kFont, color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      );
    } else {
      visual = _placeholder(Icons.image_outlined);
    }

    return Stack(
      children: [
        visual,
        if (transferring)
          Positioned.fill(
            child: Container(
              color: Colors.black38,
              alignment: Alignment.center,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 52,
                    height: 52,
                    child: CircularProgressIndicator(
                      value: m.progress > 0 ? m.progress : null,
                      strokeWidth: 3,
                      color: Colors.white,
                      backgroundColor: Colors.white24,
                    ),
                  ),
                  Text(
                    '${(m.progress * 100).round()}%',
                    style: const TextStyle(
                        fontFamily: kFont, color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ),
        if (m.mine && m.status == MessageStatus.pending)
          Positioned.fill(
            child: Container(
              color: Colors.black26,
              alignment: Alignment.center,
              child: const Icon(Icons.schedule_rounded, color: Colors.white, size: 30),
            ),
          ),
        PositionedDirectional(
          end: 8,
          bottom: 6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(10)),
            child: _Meta(message: m, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Widget _placeholder(IconData icon) => Container(
        width: 240,
        height: 180,
        color: const Color(0xFF2A2C44),
        child: Icon(icon, color: Colors.white54, size: 40),
      );
}

class _Meta extends StatelessWidget {
  const _Meta({required this.message, required this.color});
  final ChatMessage message;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final m = message;
    IconData? icon;
    var c = color;
    if (m.mine && !m.deleted) {
      switch (m.status) {
        case MessageStatus.pending:
          icon = Icons.schedule_rounded;
          break;
        case MessageStatus.sending:
          icon = Icons.north_rounded;
          break;
        case MessageStatus.sent:
          icon = m.isGroup ? Icons.done_all_rounded : Icons.check_rounded;
          break;
        case MessageStatus.delivered:
          icon = Icons.done_all_rounded;
          c = const Color(0xFF9BE7FF);
          break;
        case MessageStatus.failed:
          icon = Icons.error_outline_rounded;
          break;
        default:
          icon = null;
      }
    }
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(clockTime(m.time), style: TextStyle(fontFamily: kFont, fontSize: 10.5, color: color, height: 1.1)),
          if (icon != null) ...[
            const SizedBox(width: 3),
            Icon(icon, size: 14, color: c),
          ],
        ],
      ),
    );
  }
}
