import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../net/native.dart';

/// نافذة إعداد الاستقبال والتطبيق مغلق
Future<void> showBackgroundSetup(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.82,
      maxChildSize: 0.95,
      builder: (_, scroll) => BackgroundChecklist(scroll: scroll, sheet: true),
    ),
  );
}

/// قائمة التحقق من إعدادات العمل في الخلفية (تُستخدم في النافذة والإعدادات)
class BackgroundChecklist extends StatefulWidget {
  const BackgroundChecklist({super.key, this.scroll, this.sheet = false});
  final ScrollController? scroll;
  final bool sheet;

  @override
  State<BackgroundChecklist> createState() => _BackgroundChecklistState();
}

class _BackgroundChecklistState extends State<BackgroundChecklist> with WidgetsBindingObserver {
  bool _notif = false;
  bool _battery = false;
  bool _fullScreen = true;
  String _maker = '';

  AppController get c => AppController.I;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final n = await Permission.notification.status;
    final b = await NativeBridge.ignoringBatteryOptimizations();
    final f = await NativeBridge.canFullScreen();
    final m = await NativeBridge.manufacturer();
    if (!mounted) return;
    setState(() {
      _notif = n.isGranted;
      _battery = b;
      _fullScreen = f;
      _maker = m.toLowerCase();
    });
  }

  String? get _makerTip {
    if (_maker.contains('huawei') || _maker.contains('honor')) {
      return 'هواوي / هونر: الإعدادات ← البطارية ← تشغيل التطبيقات ← «اتصال مباشر» ← إدارة يدوية، '
          'ثم فعّل: التشغيل التلقائي، التشغيل الثانوي، والتشغيل في الخلفية.';
    }
    if (_maker.contains('xiaomi') || _maker.contains('redmi') || _maker.contains('poco')) {
      return 'شاومي: الإعدادات ← التطبيقات ← «اتصال مباشر» ← توفير البطارية ← بلا قيود، '
          'وفعّل «التشغيل التلقائي».';
    }
    if (_maker.contains('samsung')) {
      return 'سامسونج: الإعدادات ← البطارية ← حدود استخدام الخلفية ← '
          'أضف «اتصال مباشر» إلى «التطبيقات التي لا تدخل في السكون أبداً».';
    }
    if (_maker.contains('oppo') || _maker.contains('realme') || _maker.contains('oneplus') || _maker.contains('vivo')) {
      return 'الإعدادات ← البطارية ← «اتصال مباشر» ← السماح بالنشاط في الخلفية والتشغيل التلقائي.';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final bg = c.store.settings.background;
    final tip = _makerTip;
    return ListView(
      controller: widget.scroll,
      shrinkWrap: !widget.sheet,
      physics: widget.sheet ? null : const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.fromLTRB(20, widget.sheet ? 0 : 4, 20, widget.sheet ? 24 : 4),
      children: [
        if (widget.sheet) ...[
          Center(
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(color: p.brandSoft, borderRadius: BorderRadius.circular(24)),
              child: Icon(Icons.notifications_active_rounded, color: p.brand, size: 36),
            ),
          ),
          const SizedBox(height: 16),
          Text('استقبل كل شيء حتى والتطبيق مغلق',
              textAlign: TextAlign.center, style: context.txt.titleLarge),
          const SizedBox(height: 8),
          Text(
            'يبقى «اتصال مباشر» متصلاً في الخلفية بإشعار صغير دائم، '
            'فتصلك الرسائل والمكالمات فوراً. أكمل الخطوات التالية لضمان ذلك:',
            textAlign: TextAlign.center,
            style: context.txt.bodyMedium!.copyWith(color: p.muted),
          ),
          const SizedBox(height: 18),
        ],
        _Step(
          done: bg,
          icon: Icons.sync_rounded,
          title: 'التشغيل في الخلفية',
          text: 'يحافظ على الاتصال بعد إغلاق التطبيق',
          action: bg ? null : 'تفعيل',
          onTap: () async {
            await c.setBackground(true);
            _refresh();
          },
        ),
        _Step(
          done: _notif,
          icon: Icons.notifications_rounded,
          title: 'السماح بالإشعارات',
          text: 'لتنبيهك بالرسائل والمكالمات الواردة',
          action: 'سماح',
          onTap: () async {
            final st = await Permission.notification.request();
            if (st.isPermanentlyDenied) await openAppSettings();
            _refresh();
          },
        ),
        _Step(
          done: _battery,
          icon: Icons.battery_charging_full_rounded,
          title: 'استثناء من توفير البطارية',
          text: 'يمنع النظام من قطع الاتصال لتوفير الطاقة',
          action: 'استثناء',
          onTap: () async {
            await NativeBridge.requestIgnoreBattery();
            _refresh();
          },
        ),
        _Step(
          done: _fullScreen,
          icon: Icons.call_rounded,
          title: 'المكالمات بملء الشاشة',
          text: 'لظهور المكالمة الواردة فوق شاشة القفل',
          action: 'فتح',
          onTap: () async {
            await NativeBridge.openFullScreenSettings();
          },
        ),
        if (tip != null) ...[
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: p.warning.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.tips_and_updates_outlined, color: p.warning),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('خطوة إضافية لهاتفك', style: context.txt.titleSmall),
                      const SizedBox(height: 4),
                      Text(tip, style: context.txt.bodySmall!.copyWith(color: p.text)),
                      const SizedBox(height: 8),
                      OutlinedButton(
                        style: OutlinedButton.styleFrom(minimumSize: const Size(0, 38)),
                        onPressed: NativeBridge.openAppSettings,
                        child: const Text('فتح إعدادات التطبيق'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
        if (widget.sheet) ...[
          const SizedBox(height: 18),
          FilledButton(onPressed: () => Navigator.of(context).pop(), child: const Text('تم')),
        ],
      ],
    );
  }
}

class _Step extends StatelessWidget {
  const _Step({
    required this.done,
    required this.icon,
    required this.title,
    required this.text,
    required this.action,
    required this.onTap,
  });

  final bool done;
  final IconData icon;
  final String title;
  final String text;
  final String? action;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: p.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: done ? p.success.withValues(alpha: 0.4) : p.line),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: (done ? p.success : p.brand).withValues(alpha: 0.12),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Icon(done ? Icons.check_rounded : icon, color: done ? p.success : p.brand, size: 22),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: context.txt.titleSmall),
                  Text(text, style: context.txt.bodySmall),
                ],
              ),
            ),
            if (!done && action != null)
              FilledButton(
                style: FilledButton.styleFrom(
                  minimumSize: const Size(0, 38),
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  textStyle: const TextStyle(fontFamily: kFont, fontSize: 13.5, fontWeight: FontWeight.w600),
                ),
                onPressed: onTap,
                child: Text(action!),
              ),
          ],
        ),
      ),
    );
  }
}
