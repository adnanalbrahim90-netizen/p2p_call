import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:video_player/video_player.dart';

import '../../app/theme.dart';
import '../../net/calls.dart';

/// عارض الصور بملء الشاشة مع التكبير
class ImageViewer extends StatelessWidget {
  const ImageViewer({super.key, required this.path, required this.heroTag, this.title});
  final String path;
  final String heroTag;
  final String? title;

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: Colors.black,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.black38,
          foregroundColor: Colors.white,
          title: title == null
              ? null
              : Text(title!, style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 16)),
        ),
        body: Center(
          child: InteractiveViewer(
            minScale: 1,
            maxScale: 5,
            child: Hero(tag: heroTag, child: Image.file(File(path))),
          ),
        ),
      ),
    );
  }
}

/// مشغل الفيديو
class VideoViewer extends StatefulWidget {
  const VideoViewer({super.key, required this.path, this.title});
  final String path;
  final String? title;

  @override
  State<VideoViewer> createState() => _VideoViewerState();
}

class _VideoViewerState extends State<VideoViewer> {
  late final VideoPlayerController _c = VideoPlayerController.file(File(widget.path));
  bool _ready = false;
  bool _error = false;
  bool _controls = true;
  Timer? _hide;

  @override
  void initState() {
    super.initState();
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      _c.play();
      _scheduleHide();
    }).catchError((Object _) {
      if (mounted) setState(() => _error = true);
    });
    _c.addListener(_tick);
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  void _scheduleHide() {
    _hide?.cancel();
    _hide = Timer(const Duration(seconds: 3), () {
      if (mounted && _c.value.isPlaying) setState(() => _controls = false);
    });
  }

  @override
  void dispose() {
    _hide?.cancel();
    _c.removeListener(_tick);
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final v = _c.value;
    final pos = v.position;
    final dur = v.duration;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: Colors.black,
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.white,
        ),
        body: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () {
            setState(() => _controls = !_controls);
            if (_controls) _scheduleHide();
          },
          child: Stack(
            children: [
              Center(
                child: _error
                    ? const Text('تعذّر تشغيل الفيديو',
                        style: TextStyle(fontFamily: kFont, color: Colors.white70))
                    : !_ready
                        ? const CircularProgressIndicator(color: Colors.white)
                        : AspectRatio(aspectRatio: v.aspectRatio, child: VideoPlayer(_c)),
              ),
              if (_ready)
                AnimatedOpacity(
                  duration: const Duration(milliseconds: 200),
                  opacity: _controls ? 1 : 0,
                  child: IgnorePointer(
                    ignoring: !_controls,
                    child: Stack(
                      children: [
                        Center(
                          child: Material(
                            color: Colors.black45,
                            shape: const CircleBorder(),
                            child: IconButton(
                              iconSize: 46,
                              color: Colors.white,
                              onPressed: () {
                                v.isPlaying ? _c.pause() : _c.play();
                                _scheduleHide();
                              },
                              icon: Icon(v.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 0,
                          right: 0,
                          bottom: 0,
                          child: Container(
                            padding: EdgeInsets.fromLTRB(
                                16, 24, 16, 16 + MediaQuery.paddingOf(context).bottom),
                            decoration: const BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [Colors.black87, Colors.transparent],
                              ),
                            ),
                            child: Directionality(
                              textDirection: TextDirection.ltr,
                              child: Row(
                                children: [
                                  Text(formatDuration(pos),
                                      style: const TextStyle(color: Colors.white, fontSize: 12)),
                                  Expanded(
                                    child: Slider(
                                      value: dur.inMilliseconds == 0
                                          ? 0
                                          : (pos.inMilliseconds / dur.inMilliseconds).clamp(0.0, 1.0),
                                      activeColor: Colors.white,
                                      inactiveColor: Colors.white24,
                                      onChanged: (x) {
                                        _c.seekTo(Duration(milliseconds: (x * dur.inMilliseconds).round()));
                                        _scheduleHide();
                                      },
                                    ),
                                  ),
                                  Text(formatDuration(dur),
                                      style: const TextStyle(color: Colors.white, fontSize: 12)),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
