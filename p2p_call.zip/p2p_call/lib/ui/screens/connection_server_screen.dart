import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../net/rtc.dart';
import '../widgets/common.dart';

/// إعداد خادم الترحيل (TURN) الذي يضمن الاتصال عندما يتعذر الاتصال المباشر
class ConnectionServerScreen extends StatefulWidget {
  const ConnectionServerScreen({super.key});

  @override
  State<ConnectionServerScreen> createState() => _ConnectionServerScreenState();
}

enum _Test { idle, running, ok, fail }

class _ConnectionServerScreenState extends State<ConnectionServerScreen> {
  final _urls = TextEditingController();
  final _user = TextEditingController();
  final _pass = TextEditingController();
  bool _showPass = false;
  _Test _builtinTest = _Test.idle;
  _Test _customTest = _Test.idle;

  AppController get c => AppController.I;

  @override
  void initState() {
    super.initState();
    final t = TurnServer.fromJson(c.store.settings.turn);
    if (t != null) {
      _urls.text = t.urls.where((u) => !u.endsWith('?transport=tcp') || !t.urls.contains(u.replaceAll('?transport=tcp', ''))).join('\n');
      _user.text = t.username;
      _pass.text = t.credential;
    }
  }

  @override
  void dispose() {
    _urls.dispose();
    _user.dispose();
    _pass.dispose();
    super.dispose();
  }

  TurnServer get _draft => TurnServer(
        urls: TurnServer.parseUrls(_urls.text),
        username: _user.text.trim(),
        credential: _pass.text.trim(),
      );

  Future<void> _testBuiltin() async {
    setState(() => _builtinTest = _Test.running);
    final ok = await IceConfig.test(builtin: true);
    if (mounted) setState(() => _builtinTest = ok ? _Test.ok : _Test.fail);
  }

  Future<void> _testCustom() async {
    final t = _draft;
    if (!t.isValid) {
      showSnack(context, 'أكمل العنوان واسم المستخدم وكلمة المرور');
      return;
    }
    setState(() => _customTest = _Test.running);
    final ok = await IceConfig.test(server: t);
    if (mounted) setState(() => _customTest = ok ? _Test.ok : _Test.fail);
  }

  Future<void> _save() async {
    final t = _draft;
    if (!t.isValid) {
      showSnack(context, 'تحقق من البيانات: العنوان مثل relay1.expressturn.com:3478');
      return;
    }
    c.setCustomTurn(t);
    showSnack(context, 'تم الحفظ — سيُستخدم في كل اتصالاتك ويُشارك مع أصدقائك', icon: Icons.check_circle_rounded);
    _testCustom();
  }

  void _remove() {
    c.setCustomTurn(null);
    setState(() {
      _urls.clear();
      _user.clear();
      _pass.clear();
      _customTest = _Test.idle;
    });
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final hasCustom = c.store.settings.turn != null;
    return Scaffold(
      appBar: AppBar(title: const Text('خادم الاتصال')),
      body: ListView(
        padding: const EdgeInsets.only(bottom: 40),
        children: [
          CardBox(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.shield_outlined, color: p.brand),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'يحاول التطبيق دائماً الاتصال المباشر أولاً. إذا منعته شبكة الجوال أو الراوتر، '
                    'يمر الاتصال عبر خادم ترحيل. المحتوى يبقى مشفّراً طرفاً لطرف، '
                    'ولا يستطيع الخادم سماعه أو رؤيته.',
                    style: context.txt.bodyMedium!.copyWith(color: p.muted),
                  ),
                ),
              ],
            ),
          ),

          // ------------------------------------------------ المدمج
          const SectionLabel('الخادم المجاني المدمج'),
          CardBox(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              children: [
                SwitchListTile(
                  value: c.store.settings.turnBuiltin,
                  onChanged: (v) => setState(() => c.setTurnBuiltin(v)),
                  secondary: const Icon(Icons.public_rounded),
                  title: const Text('Open Relay'),
                  subtitle: const Text('مجاني بدون تسجيل • منافذ 80 و443 مع TLS'),
                ),
                ListTile(
                  leading: _TestIcon(state: _builtinTest),
                  title: Text(_label(_builtinTest, builtin: true)),
                  trailing: TextButton(
                    onPressed: _builtinTest == _Test.running ? null : _testBuiltin,
                    child: const Text('اختبار'),
                  ),
                ),
              ],
            ),
          ),

          // ------------------------------------------------ الخاص
          SectionLabel(hasCustom ? 'خادمك الخاص (مفعّل)' : 'خادم خاص أقوى (مستحسن)'),
          CardBox(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: _urls,
                  minLines: 1,
                  maxLines: 3,
                  textDirection: TextDirection.ltr,
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'عنوان الخادم',
                    hintText: 'relay1.expressturn.com:3478',
                    hintTextDirection: TextDirection.ltr,
                    prefixIcon: Icon(Icons.dns_outlined),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _user,
                  textDirection: TextDirection.ltr,
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'اسم المستخدم',
                    prefixIcon: Icon(Icons.person_outline_rounded),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _pass,
                  textDirection: TextDirection.ltr,
                  autocorrect: false,
                  obscureText: !_showPass,
                  decoration: InputDecoration(
                    labelText: 'كلمة المرور',
                    prefixIcon: const Icon(Icons.key_outlined),
                    suffixIcon: IconButton(
                      onPressed: () => setState(() => _showPass = !_showPass),
                      icon: Icon(_showPass ? Icons.visibility_off_outlined : Icons.visibility_outlined),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _TestIcon(state: _customTest),
                    const SizedBox(width: 8),
                    Expanded(child: Text(_label(_customTest), style: context.txt.bodySmall)),
                    TextButton(
                      onPressed: _customTest == _Test.running ? null : _testCustom,
                      child: const Text('اختبار'),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    if (hasCustom) ...[
                      Expanded(
                        child: OutlinedButton(
                          onPressed: _remove,
                          child: Text('إزالة', style: TextStyle(color: p.danger)),
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                    Expanded(
                      flex: 2,
                      child: FilledButton(
                        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
                        onPressed: _save,
                        child: const Text('حفظ وتفعيل'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ------------------------------------------------ الشرح
          const SectionLabel('احصل على خادم قوي مجاناً'),
          CardBox(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.workspace_premium_outlined, color: p.warning),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text('ExpressTURN — 1000 جيجابايت شهرياً مجاناً', style: context.txt.titleSmall),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const _GuideStep(n: '1', text: 'افتح expressturn.com واضغط Sign up (يكفي بريدك، وفي خانة الموقع اكتب أي شيء).'),
                const _GuideStep(n: '2', text: 'من لوحة التحكم انسخ: Server وUsername وPassword.'),
                const _GuideStep(n: '3', text: 'الصقها في الخانات أعلاه، ثم «حفظ وتفعيل» و«اختبار».'),
                const SizedBox(height: 6),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: p.brandSoft, borderRadius: BorderRadius.circular(14)),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.group_outlined, size: 20, color: p.brand),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'يكفي أن تضيفه أنت فقط: يُرسل التطبيق بيانات خادمك مشفّرة لأصدقائك عند كل اتصال، '
                          'فيستفيدون منه تلقائياً.',
                          style: context.txt.bodySmall!.copyWith(color: p.brand),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _label(_Test t, {bool builtin = false}) {
    switch (t) {
      case _Test.idle:
        return builtin ? 'اضغط «اختبار» للتأكد من عمله على شبكتك' : 'لم يُختبر بعد';
      case _Test.running:
        return 'جارٍ الاختبار…';
      case _Test.ok:
        return 'يعمل ✓ — الاتصال مضمون عبر هذا الخادم';
      case _Test.fail:
        return builtin
            ? 'لا يستجيب الآن على شبكتك — يُنصح بإضافة خادم خاص'
            : 'لم ينجح — تحقق من العنوان والبيانات، أو جرّب المنفذ 443';
    }
  }
}

class _TestIcon extends StatelessWidget {
  const _TestIcon({required this.state});
  final _Test state;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    switch (state) {
      case _Test.idle:
        return Icon(Icons.radio_button_unchecked_rounded, color: p.muted);
      case _Test.running:
        return const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5));
      case _Test.ok:
        return Icon(Icons.check_circle_rounded, color: p.success);
      case _Test.fail:
        return Icon(Icons.error_outline_rounded, color: p.danger);
    }
  }
}

class _GuideStep extends StatelessWidget {
  const _GuideStep({required this.n, required this.text});
  final String n;
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 24,
            height: 24,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: p.brandSoft, shape: BoxShape.circle),
            child: Text(n, style: TextStyle(fontFamily: kFont, color: p.brand, fontWeight: FontWeight.w700, fontSize: 12)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: context.txt.bodyMedium)),
        ],
      ),
    );
  }
}
