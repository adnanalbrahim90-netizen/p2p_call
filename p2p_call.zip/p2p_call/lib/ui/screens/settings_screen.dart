import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/identity.dart';
import '../widgets/common.dart';
import 'background_setup.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListenableBuilder(
        listenable: Listenable.merge([c, c.store, c.relay]),
        builder: (context, _) {
          final id = c.identity;
          if (id == null) return const SizedBox.shrink();
          final relay = c.relay;
          return ListView(
            padding: const EdgeInsets.only(bottom: 40),
            children: [
              CardBox(
                child: Row(
                  children: [
                    Avatar(name: id.name, seed: id.id, size: 60),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(id.name, style: context.txt.titleLarge),
                          Text(
                            prettyId(id.id),
                            textDirection: TextDirection.ltr,
                            style: context.txt.bodySmall!.copyWith(letterSpacing: 1.2),
                          ),
                        ],
                      ),
                    ),
                    IconButton.filledTonal(
                      onPressed: () async {
                        final v = await promptText(context, title: 'اسمك', initial: id.name);
                        if (v != null && v.trim().isNotEmpty) await c.rename(v);
                      },
                      icon: const Icon(Icons.edit_outlined),
                    ),
                  ],
                ),
              ),
              const SectionLabel('الأمان'),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    SwitchListTile(
                      value: c.store.settings.lockEnabled && c.biometricSupported,
                      onChanged: !c.biometricSupported
                          ? null
                          : (v) async {
                              if (v && !await c.verifyBiometric()) return;
                              c.setLockEnabled(v);
                            },
                      secondary: const Icon(Icons.fingerprint_rounded),
                      title: const Text('قفل التطبيق بالبصمة'),
                      subtitle: Text(c.biometricSupported
                          ? 'يُطلب التحقق عند فتح التطبيق'
                          : 'غير مدعوم على هذا الجهاز'),
                    ),
                    if (c.store.settings.lockEnabled && c.biometricSupported)
                      ListTile(
                        leading: const Icon(Icons.timer_outlined),
                        title: const Text('القفل التلقائي'),
                        subtitle: Text(_lockLabel(c.store.settings.lockAfterSeconds)),
                        onTap: () => _pickLockTime(context),
                      ),
                  ],
                ),
              ),
              const SectionLabel('الاستقبال والتطبيق مغلق'),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: SwitchListTile(
                  value: c.store.settings.background,
                  onChanged: (v) => c.setBackground(v),
                  secondary: const Icon(Icons.notifications_active_outlined),
                  title: const Text('البقاء متصلاً في الخلفية'),
                  subtitle: const Text('استقبال الرسائل والمكالمات حتى بعد إغلاق التطبيق'),
                ),
              ),
              if (c.store.settings.background) ...[
                const SizedBox(height: 10),
                const BackgroundChecklist(),
              ],
              const SectionLabel('الشبكة'),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: ListTile(
                  leading: Icon(
                    Icons.hub_outlined,
                    color: (relay?.connectedCount ?? 0) > 0 ? p.success : p.danger,
                  ),
                  title: const Text('نقاط الالتقاء'),
                  subtitle: Text(
                    'متصل بـ ${relay?.connectedCount ?? 0} من ${relay?.brokerCount ?? 0} — '
                    'تُستخدم فقط لتعارف الهاتفين، ومحتواها مشفّر',
                  ),
                ),
              ),
              const SectionLabel('كيف يعمل التطبيق'),
              CardBox(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    _Info(
                      icon: Icons.key_rounded,
                      text: 'هويتك مفتاح تشفير يُنشأ على جهازك، ورمز QR الخاص بك يحمل المفتاح العام فقط.',
                    ),
                    _Info(
                      icon: Icons.swap_horiz_rounded,
                      text: 'عند الاتصال يتبادل الهاتفان "طرقة باب" قصيرة مشفّرة عبر وسيط عام مجاني، '
                          'ثم ينشئان اتصالاً مباشراً بينهما.',
                    ),
                    _Info(
                      icon: Icons.devices_rounded,
                      text: 'الرسائل والصور والفيديو والمكالمات تنتقل مباشرة ولا تُخزَّن في أي خادم.',
                    ),
                    _Info(
                      icon: Icons.wifi_rounded,
                      text: 'مع تفعيل البقاء في الخلفية تصلك الرسائل والمكالمات والتطبيق مغلق. '
                          'إن كان هاتف صديقك مطفأً تُرسل رسائلك تلقائياً عند عودته.',
                      last: true,
                    ),
                  ],
                ),
              ),
              const SectionLabel('منطقة الخطر'),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: ListTile(
                  leading: Icon(Icons.delete_forever_outlined, color: p.danger),
                  title: Text('حذف هويتي وكل البيانات', style: TextStyle(color: p.danger)),
                  subtitle: const Text('سيتغير رمزك ويجب على أصدقائك إضافتك من جديد'),
                  onTap: () async {
                    if (await confirmDialog(
                      context,
                      title: 'حذف كل شيء؟',
                      message: 'ستُحذف جهات الاتصال والمحادثات وهويتك نهائياً من هذا الجهاز.',
                      confirm: 'حذف نهائي',
                      danger: true,
                    )) {
                      if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                      await c.resetEverything();
                    }
                  },
                ),
              ),
              const SizedBox(height: 20),
              Center(child: Text('اتصال مباشر • الإصدار 2.0', style: context.txt.bodySmall)),
            ],
          );
        },
      ),
    );
  }

  static String _lockLabel(int s) {
    if (s <= 0) return 'فوراً عند مغادرة التطبيق';
    if (s < 60) return 'بعد $s ثانية';
    return 'بعد ${s ~/ 60} دقيقة';
  }

  Future<void> _pickLockTime(BuildContext context) async {
    final c = AppController.I;
    const options = [0, 30, 60, 300];
    final v = await showModalBottomSheet<int>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (final o in options)
              ListTile(
                title: Text(_lockLabel(o)),
                trailing: c.store.settings.lockAfterSeconds == o
                    ? Icon(Icons.check_rounded, color: ctx.pal.brand)
                    : null,
                onTap: () => Navigator.pop(ctx, o),
              ),
          ],
        ),
      ),
    );
    if (v == null) return;
    c.store.settings.lockAfterSeconds = v;
    c.store.saveSettings();
  }
}

class _Info extends StatelessWidget {
  const _Info({required this.icon, required this.text, this.last = false});
  final IconData icon;
  final String text;
  final bool last;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: EdgeInsets.only(bottom: last ? 0 : 14),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: p.brand),
          const SizedBox(width: 12),
          Expanded(child: Text(text, style: context.txt.bodyMedium!.copyWith(color: p.muted))),
        ],
      ),
    );
  }
}
