import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/identity.dart';
import '../widgets/common.dart';
import 'home_screen.dart';

class MyCodeTab extends StatelessWidget {
  const MyCodeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 32),
        children: [
          const TabHeader(title: 'رمزي'),
          const SizedBox(height: 12),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: MyCodeCard(),
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: OutlinedButton.icon(
              onPressed: () => openAddContact(context),
              icon: const Icon(Icons.qr_code_scanner_rounded),
              label: const Text('مسح رمز صديق'),
            ),
          ),
          const SizedBox(height: 20),
          CardBox(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.verified_user_outlined, color: p.brand),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'هذا الرمز ثابت ومرتبط بهذا الجهاز. من يمسحه يُرسل إليك طلب إضافة، '
                    'وبعد قبوله يمكنكما المراسلة والاتصال دائماً دون مسح الرمز مرة أخرى.',
                    style: context.txt.bodyMedium!.copyWith(color: p.muted),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// بطاقة رمز QR الثابت للجهاز
class MyCodeCard extends StatelessWidget {
  const MyCodeCard({super.key, this.compact = false});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) {
        final id = c.identity;
        if (id == null) return const SizedBox.shrink();
        final p = context.pal;
        final code = id.card.encode();
        final qrSize = compact ? 190.0 : (MediaQuery.sizeOf(context).width - 120).clamp(200.0, 280.0);
        return Container(
          padding: EdgeInsets.fromLTRB(20, compact ? 18 : 24, 20, compact ? 16 : 20),
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: p.line),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Avatar(name: id.name, seed: id.id, size: 46),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(id.name, style: context.txt.titleMedium),
                        Text(
                          prettyId(id.id),
                          textDirection: TextDirection.ltr,
                          style: context.txt.bodySmall!.copyWith(letterSpacing: 1.2),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height: compact ? 14 : 22),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: QrImageView(
                  data: code,
                  version: QrVersions.auto,
                  size: qrSize,
                  padding: EdgeInsets.zero,
                  backgroundColor: Colors.white,
                  errorCorrectionLevel: QrErrorCorrectLevel.M,
                  eyeStyle: const QrEyeStyle(
                    eyeShape: QrEyeShape.square,
                    color: Color(0xFF1B1A4B),
                  ),
                  dataModuleStyle: const QrDataModuleStyle(
                    dataModuleShape: QrDataModuleShape.circle,
                    color: Color(0xFF1B1A4B),
                  ),
                ),
              ),
              SizedBox(height: compact ? 12 : 18),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                      onPressed: () => copyText(context, code, 'تم نسخ رمزك'),
                      icon: const Icon(Icons.copy_rounded, size: 19),
                      label: const Text('نسخ'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                      onPressed: () {
                        c.suppressLock();
                        Share.share(
                          'أضفني على تطبيق «اتصال مباشر»:\n'
                          'افتح التطبيق ← إضافة ← لصق الرمز\n\n$code',
                        );
                      },
                      icon: const Icon(Icons.ios_share_rounded, size: 19),
                      label: const Text('مشاركة'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
