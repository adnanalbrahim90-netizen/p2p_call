import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/models.dart';
import '../widgets/common.dart';
import 'call_actions.dart';
import 'chat_screen.dart';
import 'create_group_screen.dart';

/// معلومات القروب: الأعضاء، الصلاحيات، الإعدادات، المغادرة
class GroupInfoScreen extends StatelessWidget {
  const GroupInfoScreen({super.key, required this.groupId});
  final String groupId;

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(),
      body: ListenableBuilder(
        listenable: Listenable.merge([c.store, c.links, c.relay]),
        builder: (context, _) {
          final g = c.store.group(groupId);
          final gs = c.groups;
          if (g == null || gs == null) return const SizedBox.shrink();
          final me = c.store.selfId;
          final admin = gs.canManage(g);
          final members = [...g.members]..sort((a, b) {
              int rank(GroupMember m) => m.id == me ? -1 : m.role.index;
              final r = rank(a).compareTo(rank(b));
              return r != 0 ? r : c.store.nameOf(a.id).compareTo(c.store.nameOf(b.id));
            });

          return ListView(
            padding: const EdgeInsets.only(bottom: 40),
            children: [
              Center(child: GroupAvatar(name: g.name, seed: g.id, size: 104)),
              const SizedBox(height: 14),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    child: Text(g.name, textAlign: TextAlign.center, style: context.txt.headlineSmall),
                  ),
                  if (admin)
                    IconButton(
                      onPressed: () async {
                        final v = await promptText(context, title: 'اسم القروب', initial: g.name);
                        if (v != null) await gs.rename(g, v);
                      },
                      icon: Icon(Icons.edit_outlined, color: p.muted, size: 20),
                    ),
                ],
              ),
              Text(
                g.left ? 'لم تعد عضواً في هذا القروب' : 'قروب • ${g.members.length} أعضاء',
                textAlign: TextAlign.center,
                style: context.txt.bodySmall,
              ),
              const SizedBox(height: 20),
              if (!g.left)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      ActionTile(
                        icon: Icons.chat_bubble_outline_rounded,
                        label: 'رسالة',
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      const SizedBox(width: 10),
                      ActionTile(
                        icon: Icons.call_outlined,
                        label: 'صوت',
                        onTap: () => startGroupCallFlow(context, g, video: false),
                      ),
                      const SizedBox(width: 10),
                      ActionTile(
                        icon: Icons.videocam_outlined,
                        label: 'فيديو',
                        onTap: () => startGroupCallFlow(context, g, video: true),
                      ),
                    ],
                  ),
                ),
              if (admin) ...[
                const SectionLabel('الإعدادات'),
                CardBox(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: SwitchListTile(
                    value: g.adminsOnly,
                    onChanged: (v) => gs.setAdminsOnly(g, v),
                    secondary: const Icon(Icons.campaign_outlined),
                    title: const Text('الإرسال للمشرفين فقط'),
                    subtitle: const Text('مناسب لقروبات الإعلانات'),
                  ),
                ),
              ],
              SectionLabel('الأعضاء (${g.members.length})'),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    if (admin)
                      ListTile(
                        leading: Container(
                          width: 44,
                          height: 44,
                          decoration: BoxDecoration(color: p.brandSoft, shape: BoxShape.circle),
                          child: Icon(Icons.person_add_alt_1_rounded, color: p.brand),
                        ),
                        title: Text('إضافة أعضاء', style: TextStyle(color: p.brand)),
                        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
                          builder: (_) => CreateGroupScreen(group: g),
                        )),
                      ),
                    for (final m in members)
                      _MemberTile(group: g, member: m),
                  ],
                ),
              ),
              const SectionLabel(''),
              CardBox(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(Icons.cleaning_services_outlined),
                      title: const Text('مسح المحادثة'),
                      onTap: () async {
                        if (await confirmDialog(
                          context,
                          title: 'مسح المحادثة؟',
                          message: 'ستُحذف الرسائل والوسائط من هذا الجهاز فقط.',
                          confirm: 'مسح',
                          danger: true,
                        )) {
                          await c.store.clearChat(g.chatId);
                        }
                      },
                    ),
                    if (!g.left)
                      ListTile(
                        leading: Icon(Icons.logout_rounded, color: p.danger),
                        title: Text('مغادرة القروب', style: TextStyle(color: p.danger)),
                        subtitle: g.isOwner(me) && g.members.length > 1
                            ? const Text('ستنتقل ملكية القروب إلى مشرف آخر')
                            : null,
                        onTap: () async {
                          if (await confirmDialog(
                            context,
                            title: 'مغادرة «${g.name}»؟',
                            message: 'لن تصلك رسائل هذا القروب بعد المغادرة.',
                            confirm: 'مغادرة',
                            danger: true,
                          )) {
                            await gs.leave(g);
                          }
                        },
                      )
                    else
                      ListTile(
                        leading: Icon(Icons.delete_outline_rounded, color: p.danger),
                        title: Text('حذف القروب من جهازي', style: TextStyle(color: p.danger)),
                        onTap: () async {
                          if (await confirmDialog(
                            context,
                            title: 'حذف القروب؟',
                            message: 'سيُحذف القروب ومحادثته من هذا الجهاز.',
                            confirm: 'حذف',
                            danger: true,
                          )) {
                            if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                            await c.store.deleteGroup(g.id);
                          }
                        },
                      ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _MemberTile extends StatelessWidget {
  const _MemberTile({required this.group, required this.member});
  final Group group;
  final GroupMember member;

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    final p = context.pal;
    final me = c.store.selfId;
    final isMe = member.id == me;
    final name = isMe ? 'أنت' : c.store.nameOf(member.id, fallback: member.name);
    final isContact = c.store.hasContact(member.id);
    final online = !isMe && c.isOnline(member.id);
    return ListTile(
      onTap: isMe ? null : () => _actions(context),
      leading: Avatar(name: name, seed: member.id, size: 44, online: online),
      title: Text(name),
      subtitle: isMe
          ? null
          : Text(isContact ? (online ? 'متصل الآن' : 'جهة اتصال') : member.name,
              style: TextStyle(color: online ? p.success : null)),
      trailing: member.isAdmin ? RoleBadge(owner: member.role == GroupRole.owner) : null,
    );
  }

  Future<void> _actions(BuildContext context) async {
    final c = AppController.I;
    final gs = c.groups!;
    final p = context.pal;
    final me = c.store.selfId;
    final name = c.store.nameOf(member.id, fallback: member.name);
    final owner = group.isOwner(me) && !group.left;
    final canRemove = gs.canRemove(group, member);
    final isContact = c.store.hasContact(member.id);

    final action = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(name, style: ctx.txt.titleMedium),
            ),
            if (isContact)
              ListTile(
                leading: const Icon(Icons.chat_bubble_outline_rounded),
                title: Text('مراسلة $name'),
                onTap: () => Navigator.pop(ctx, 'chat'),
              ),
            if (owner && member.role == GroupRole.member)
              ListTile(
                leading: const Icon(Icons.verified_user_outlined),
                title: const Text('تعيين كمشرف'),
                onTap: () => Navigator.pop(ctx, 'promote'),
              ),
            if (owner && member.role == GroupRole.admin)
              ListTile(
                leading: const Icon(Icons.remove_moderator_outlined),
                title: const Text('إزالة من الإشراف'),
                onTap: () => Navigator.pop(ctx, 'demote'),
              ),
            if (canRemove)
              ListTile(
                leading: Icon(Icons.person_remove_outlined, color: p.danger),
                title: Text('إزالة من القروب', style: TextStyle(color: p.danger)),
                onTap: () => Navigator.pop(ctx, 'remove'),
              ),
            if (!isContact && !canRemove && !owner)
              const ListTile(
                leading: Icon(Icons.info_outline_rounded),
                title: Text('ليس في جهات اتصالك — يمكنكما التواصل داخل القروب'),
              ),
          ],
        ),
      ),
    );
    if (!context.mounted) return;
    switch (action) {
      case 'chat':
        Navigator.of(context).push(ChatScreen.route(member.id));
        break;
      case 'promote':
        await gs.setRole(group, member, GroupRole.admin);
        break;
      case 'demote':
        await gs.setRole(group, member, GroupRole.member);
        break;
      case 'remove':
        if (await confirmDialog(
          context,
          title: 'إزالة $name؟',
          message: 'لن يتمكن من رؤية الرسائل الجديدة في القروب.',
          confirm: 'إزالة',
          danger: true,
        )) {
          await gs.removeMember(group, member);
        }
        break;
    }
  }
}
