import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/models.dart';
import '../../net/relay.dart';
import '../widgets/common.dart';
import 'add_contact_screen.dart';
import 'calls_tab.dart';
import 'chat_screen.dart';
import 'my_code_tab.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _tab = 0;

  AppController get c => AppController.I;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      body: IndexedStack(
        index: _tab,
        children: const [ChatsTab(), CallsTab(), MyCodeTab()],
      ),
      floatingActionButton: _tab == 0
          ? FloatingActionButton.extended(
              onPressed: () => openAddContact(context),
              icon: const Icon(Icons.qr_code_scanner_rounded),
              label: const Text('إضافة', style: TextStyle(fontFamily: kFont, fontWeight: FontWeight.w600)),
            )
          : null,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(border: Border(top: BorderSide(color: p.line))),
        child: ListenableBuilder(
          listenable: c.store,
          builder: (context, _) {
            final unread = c.store.totalUnread;
            return NavigationBar(
              selectedIndex: _tab,
              onDestinationSelected: (i) => setState(() => _tab = i),
              destinations: [
                NavigationDestination(
                  icon: Badge(
                    isLabelVisible: unread > 0,
                    label: Text('$unread'),
                    child: const Icon(Icons.chat_bubble_outline_rounded),
                  ),
                  selectedIcon: Badge(
                    isLabelVisible: unread > 0,
                    label: Text('$unread'),
                    child: const Icon(Icons.chat_bubble_rounded),
                  ),
                  label: 'الدردشات',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.call_outlined),
                  selectedIcon: Icon(Icons.call_rounded),
                  label: 'المكالمات',
                ),
                const NavigationDestination(
                  icon: Icon(Icons.qr_code_2_rounded),
                  selectedIcon: Icon(Icons.qr_code_2_rounded),
                  label: 'رمزي',
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

Future<void> openAddContact(BuildContext context) {
  return Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => const AddContactScreen()),
  );
}

void openChat(BuildContext context, Contact contact) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => ChatScreen(contact: contact)),
  );
}

/// شريط العنوان المشترك للتبويبات
class TabHeader extends StatelessWidget {
  const TabHeader({super.key, required this.title, this.actions = const []});
  final String title;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    final c = AppController.I;
    return Padding(
      padding: const EdgeInsetsDirectional.fromSTEB(20, 12, 8, 4),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.txt.headlineMedium),
                const SizedBox(height: 4),
                if (c.relay != null)
                  ListenableBuilder(
                    listenable: c.relay!,
                    builder: (context, _) => _NetworkPill(status: c.relay!.status),
                  ),
              ],
            ),
          ),
          ...actions,
        ],
      ),
    );
  }
}

class _NetworkPill extends StatelessWidget {
  const _NetworkPill({required this.status});
  final RelayStatus status;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    switch (status) {
      case RelayStatus.online:
        return StatusPill(color: p.success, label: 'متصل بالشبكة');
      case RelayStatus.connecting:
        return StatusPill(color: p.warning, label: 'جارٍ الاتصال…', pulse: true);
      case RelayStatus.offline:
        return StatusPill(color: p.danger, label: 'بدون اتصال');
    }
  }
}

// ============================================================================ الدردشات
class ChatsTab extends StatefulWidget {
  const ChatsTab({super.key});

  @override
  State<ChatsTab> createState() => _ChatsTabState();
}

class _ChatsTabState extends State<ChatsTab> {
  final _search = TextEditingController();
  String _query = '';

  AppController get c => AppController.I;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: ListenableBuilder(
        listenable: Listenable.merge([c.store, c.links, c.relay]),
        builder: (context, _) {
          final all = c.store.contacts;
          final q = _query.trim();
          final list = q.isEmpty
              ? all
              : all.where((x) => x.displayName.contains(q) || x.name.contains(q)).toList();
          final requests = c.store.requests;

          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: TabHeader(
                  title: 'الدردشات',
                  actions: [
                    IconButton(
                      tooltip: 'الإعدادات',
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
                      ),
                      icon: const Icon(Icons.settings_outlined),
                    ),
                  ],
                ),
              ),
              if (all.length > 4)
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 16, 4),
                    child: TextField(
                      controller: _search,
                      onChanged: (v) => setState(() => _query = v),
                      decoration: InputDecoration(
                        hintText: 'بحث',
                        prefixIcon: const Icon(Icons.search_rounded),
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                        suffixIcon: _query.isEmpty
                            ? null
                            : IconButton(
                                onPressed: () {
                                  _search.clear();
                                  setState(() => _query = '');
                                },
                                icon: const Icon(Icons.close_rounded),
                              ),
                      ),
                    ),
                  ),
                ),
              if (requests.isNotEmpty) ...[
                const SliverToBoxAdapter(child: SectionLabel('طلبات إضافة')),
                SliverList.builder(
                  itemCount: requests.length,
                  itemBuilder: (context, i) => _RequestCard(request: requests[i]),
                ),
                if (all.isNotEmpty) const SliverToBoxAdapter(child: SectionLabel('المحادثات')),
              ],
              if (all.isEmpty && requests.isEmpty)
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: EmptyState(
                    icon: Icons.forum_rounded,
                    title: 'ابدأ أول محادثة',
                    message: 'امسح رمز صديقك أو دعه يمسح رمزك من تبويب «رمزي». '
                        'يكفي ذلك مرة واحدة فقط.',
                    actions: [
                      FilledButton.icon(
                        onPressed: () => openAddContact(context),
                        icon: const Icon(Icons.qr_code_scanner_rounded),
                        label: const Text('مسح رمز صديق'),
                      ),
                    ],
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.only(top: 6, bottom: 100),
                  sliver: SliverList.builder(
                    itemCount: list.length,
                    itemBuilder: (context, i) => _ChatTile(contact: list[i]),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _ChatTile extends StatelessWidget {
  const _ChatTile({required this.contact});
  final Contact contact;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = AppController.I;
    final online = c.isOnline(contact.id);
    final typing = c.links?.isTyping(contact.id) ?? false;
    final unread = contact.unread;
    final preview = typing ? 'يكتب…' : (contact.lastText ?? 'اضغط لبدء المحادثة');

    return InkWell(
      onTap: () => openChat(context, contact),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        child: Row(
          children: [
            Avatar(name: contact.displayName, seed: contact.id, size: 54, online: online),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          contact.displayName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: context.txt.titleMedium,
                        ),
                      ),
                      if (contact.lastTime != null)
                        Text(
                          shortTime(contact.lastTime!),
                          style: context.txt.labelSmall!.copyWith(
                            color: unread > 0 ? p.brand : p.muted,
                            fontWeight: unread > 0 ? FontWeight.w700 : FontWeight.w500,
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          preview,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: context.txt.bodyMedium!.copyWith(
                            color: typing ? p.brand : (unread > 0 ? p.text : p.muted),
                            fontWeight: unread > 0 ? FontWeight.w600 : FontWeight.w400,
                          ),
                        ),
                      ),
                      if (unread > 0)
                        Container(
                          constraints: const BoxConstraints(minWidth: 22),
                          height: 22,
                          padding: const EdgeInsets.symmetric(horizontal: 7),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: p.brand,
                            borderRadius: BorderRadius.circular(11),
                          ),
                          child: Text(
                            unread > 99 ? '99+' : '$unread',
                            style: const TextStyle(
                              fontFamily: kFont,
                              color: Colors.white,
                              fontSize: 11.5,
                              fontWeight: FontWeight.w700,
                              height: 1.1,
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({required this.request});
  final ContactRequest request;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final c = AppController.I;
    final name = request.name.isEmpty ? 'جهاز جديد' : request.name;
    return CardBox(
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Row(
            children: [
              Avatar(name: name, seed: request.id, size: 46),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: context.txt.titleMedium),
                    Text('أضافك عبر رمزك ويريد التواصل معك',
                        style: context.txt.bodySmall),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(44)),
                  onPressed: () => c.declineRequest(request),
                  child: Text('تجاهل', style: TextStyle(color: p.muted)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(44)),
                  onPressed: () {
                    final contact = c.acceptRequest(request);
                    openChat(context, contact);
                  },
                  child: const Text('قبول'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
