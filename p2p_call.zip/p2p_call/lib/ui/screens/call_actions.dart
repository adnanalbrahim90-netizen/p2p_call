import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../app/controller.dart';
import '../../core/models.dart';
import '../widgets/common.dart';

/// يطلب الأذونات اللازمة ويبدأ المكالمة
Future<void> startCallFlow(BuildContext context, Contact contact, {required bool video}) async {
  final calls = AppController.I.calls;
  if (calls == null) return;
  if (!await ensureCallPermissions(context, video: video)) return;
  final error = await calls.startCall(contact, video: video);
  if (error != null && context.mounted) {
    showSnack(context, error, icon: Icons.info_outline_rounded);
  }
}

Future<bool> ensureCallPermissions(BuildContext context, {required bool video}) async {
  final wanted = [Permission.microphone, if (video) Permission.camera];
  final statuses = await wanted.request();
  final ok = statuses.values.every((s) => s.isGranted);
  if (ok) return true;
  if (!context.mounted) return false;
  final permanent = statuses.values.any((s) => s.isPermanentlyDenied);
  if (permanent) {
    final open = await confirmDialog(
      context,
      title: 'الإذن مطلوب',
      message: video
          ? 'يحتاج التطبيق إلى الكاميرا والميكروفون لإجراء مكالمة فيديو. افتح الإعدادات وفعّلهما.'
          : 'يحتاج التطبيق إلى الميكروفون لإجراء المكالمة. افتح الإعدادات وفعّله.',
      confirm: 'فتح الإعدادات',
    );
    if (open) await openAppSettings();
  } else {
    showSnack(context, 'لا يمكن الاتصال بدون إذن الميكروفون${video ? ' والكاميرا' : ''}');
  }
  return false;
}
