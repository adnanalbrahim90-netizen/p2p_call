import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/identity.dart';
import '../../net/native.dart';
import '../widgets/common.dart';
import 'chat_screen.dart';
import 'my_code_tab.dart';

/// إضافة جهة اتصال: مسح رمزها بماسح أندرويد الأصلي، أو لصقه، أو عرض رمزي لها
class AddContactScreen extends StatefulWidget {
  const AddContactScreen({super.key});

  @override
  State<AddContactScreen> createState() => _AddContactScreenState();
}

class _AddContactScreenState extends State<AddContactScreen> {
  bool _busy = false;

  AppController get c => AppController.I;

  Future<void> _scan() async {
    if (_busy) return;
    final st = await Permission.camera.request();
    if (!mounted) return;
    if (!st.isGranted) {
      if (st.isPermanentlyDenied) {
        final open = await confirmDialog(
          context,
          title: 'إذن الكاميرا مطلوب',
          message: 'افتح الإعدادات واسمح للتطبيق باستخدام الكاميرا لمسح الرموز.',
          confirm: 'فتح الإعدادات',
        );
        if (open) await openAppSettings();
      } else {
        showSnack(context, 'يلزم إذن الكاميرا لمسح الرمز');
      }
      return;
    }
    setState(() => _busy = true);
    c.suppressLock();
    final raw = await NativeBridge.scanQr();
    if (!mounted) return;
    setState(() => _busy = false);
    if (raw == null || raw.isEmpty) return;
    final card = ContactCard.tryParse(raw);
    if (card == null) {
      showSnack(context, 'هذا الرمز لا يخص تطبيق اتصال مباشر', icon: Icons.qr_code_2_rounded);
      return;
    }
    await _handle(card);
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final card = ContactCard.tryParse(data?.text ?? '');
    if (!mounted) return;
    if (card == null) {
      showSnack(context, 'لا يوجد رمز صالح في الحافظة', icon: Icons.content_paste_off_rounded);
      return;
    }
    await _handle(card);
  }

  Future<void> _handle(ContactCard card) async {
    HapticFeedback.mediumImpact();
    if (card.id == c.identity!.id) {
      showSnack(context, 'هذا رمزك أنت 🙂');
      return;
    }
    final existing = c.store.contact(card.id);
    if (existing != null) {
      Navigator.of(context).pushReplacement(ChatScreen.route(existing.id));
      return;
    }
    final add = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => _ConfirmSheet(card: card),
    );
    if (!mounted || add != true) return;
    final contact = c.addContact(card);
    Navigator.of(context).pushReplacement(ChatScreen.route(contact.id));
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة جهة اتصال')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 32),
        children: [
          // ------------------------------------------------ مسح رمز صديق
          Material(
            color: p.brand,
            borderRadius: BorderRadius.circular(24),
            child: InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: _scan,
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: brandGradient,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: _busy
                          ? const Padding(
                              padding: EdgeInsets.all(18),
                              child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                            )
                          : const Icon(Icons.qr_code_scanner_rounded, color: Colors.white, size: 32),
                    ),
                    const SizedBox(width: 16),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'امسح رمز صديقك',
                            style: TextStyle(
                              fontFamily: kFont,
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            'افتح الكاميرا ووجّهها نحو رمزه في تبويب «رمزي»',
                            style: TextStyle(fontFamily: kFont, color: Colors.white70, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_left_rounded, color: Colors.white70),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: _paste,
            icon: const Icon(Icons.content_paste_rounded, size: 20),
            label: const Text('لصق رمز وصلك برسالة'),
          ),

          // ------------------------------------------------ رمزي
          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(child: Divider(color: p.line)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('أو دعه يمسح رمزك', style: context.txt.labelMedium!.copyWith(color: p.muted)),
              ),
              Expanded(child: Divider(color: p.line)),
            ],
          ),
          const SizedBox(height: 18),
          const MyCodeCard(),
        ],
      ),
    );
  }
}

class _ConfirmSheet extends StatelessWidget {
  const _ConfirmSheet({required this.card});
  final ContactCard card;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final name = card.name.isEmpty ? 'جهة اتصال' : card.name;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Avatar(name: name, seed: card.id, size: 84),
            const SizedBox(height: 14),
            Text(name, style: context.txt.headlineSmall),
            const SizedBox(height: 4),
            Text(
              prettyId(card.id),
              textDirection: TextDirection.ltr,
              style: context.txt.bodySmall!.copyWith(letterSpacing: 1.4),
            ),
            const SizedBox(height: 14),
            Text(
              'ستُضاف إلى جهات اتصالك، ويصله طلب لإضافتك أيضاً.',
              textAlign: TextAlign.center,
              style: context.txt.bodyMedium!.copyWith(color: p.muted),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context, true),
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: const Text('إضافة وبدء المحادثة'),
            ),
            const SizedBox(height: 6),
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('إلغاء', style: TextStyle(color: p.muted)),
            ),
          ],
        ),
      ),
    );
  }
}
