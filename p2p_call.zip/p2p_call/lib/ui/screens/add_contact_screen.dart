import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/identity.dart';
import '../widgets/common.dart';
import 'chat_screen.dart';
import 'my_code_tab.dart';

/// إضافة جهة اتصال: مسح رمزها الثابت، أو لصقه، أو عرض رمزي لها
class AddContactScreen extends StatefulWidget {
  const AddContactScreen({super.key});

  @override
  State<AddContactScreen> createState() => _AddContactScreenState();
}

class _AddContactScreenState extends State<AddContactScreen> {
  MobileScannerController? _scanner;
  bool _showMine = false;
  bool _handled = false;
  bool _torch = false;
  bool _denied = false;
  DateTime _lastHint = DateTime.fromMillisecondsSinceEpoch(0);

  AppController get c => AppController.I;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _startCamera());
  }

  Future<void> _startCamera() async {
    final st = await Permission.camera.request();
    if (!mounted) return;
    if (!st.isGranted) {
      setState(() => _denied = true);
      return;
    }
    setState(() {
      _denied = false;
      _scanner = MobileScannerController(
        detectionSpeed: DetectionSpeed.noDuplicates,
        formats: const [BarcodeFormat.qrCode],
      );
    });
  }

  @override
  void dispose() {
    _scanner?.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_handled || _showMine) return;
    for (final b in capture.barcodes) {
      final raw = b.rawValue;
      if (raw == null) continue;
      final card = ContactCard.tryParse(raw);
      if (card != null) {
        _handle(card);
        return;
      }
    }
    final now = DateTime.now();
    if (now.difference(_lastHint).inSeconds > 3) {
      _lastHint = now;
      showSnack(context, 'هذا الرمز لا يخص تطبيق اتصال مباشر');
    }
  }

  Future<void> _paste() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final card = ContactCard.tryParse(data?.text ?? '');
    if (!mounted) return;
    if (card == null) {
      showSnack(context, 'لا يوجد رمز صالح في الحافظة', icon: Icons.content_paste_off_rounded);
      return;
    }
    _handle(card);
  }

  Future<void> _handle(ContactCard card) async {
    if (_handled) return;
    _handled = true;
    HapticFeedback.mediumImpact();
    await _scanner?.stop();
    if (!mounted) return;

    if (card.id == c.identity!.id) {
      showSnack(context, 'هذا رمزك أنت 🙂');
      await _resume();
      return;
    }
    final existing = c.store.contact(card.id);
    if (existing != null) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => ChatScreen(contact: existing)),
      );
      return;
    }
    final add = await showModalBottomSheet<bool>(
      context: context,
      builder: (ctx) => _ConfirmSheet(card: card),
    );
    if (!mounted) return;
    if (add == true) {
      final contact = c.addContact(card);
      Navigator.of(context).pushReplacement(
        MaterialPageRoute<void>(builder: (_) => ChatScreen(contact: contact)),
      );
    } else {
      await _resume();
    }
  }

  Future<void> _resume() async {
    _handled = false;
    if (!_showMine) {
      try {
        await _scanner?.start();
      } catch (_) {}
    }
  }

  Future<void> _toggleMine(bool mine) async {
    if (mine == _showMine) return;
    // عنصر MobileScanner يوقف الكاميرا عند إزالته ويشغلها عند عودته
    setState(() {
      _showMine = mine;
      _torch = false;
      _handled = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(
          children: [
            Positioned.fill(child: _cameraLayer()),
            // الشريط العلوي
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Row(
                  children: [
                    _GlassButton(icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
                    const Expanded(
                      child: Text(
                        'إضافة جهة اتصال',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontFamily: kFont,
                          color: Colors.white,
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    _GlassButton(
                      icon: _torch ? Icons.flash_on_rounded : Icons.flash_off_rounded,
                      active: _torch,
                      onTap: _scanner == null || _showMine
                          ? null
                          : () async {
                              await _scanner?.toggleTorch();
                              if (mounted) setState(() => _torch = !_torch);
                            },
                    ),
                  ],
                ),
              ),
            ),
            // اللوحة السفلية
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _bottomPanel(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cameraLayer() {
    if (_showMine) {
      return Container(
        color: const Color(0xFF0B0C14),
        alignment: Alignment.topCenter,
        padding: EdgeInsets.fromLTRB(20, MediaQuery.paddingOf(context).top + 70, 20, 0),
        child: Theme(
          data: buildTheme(Brightness.dark),
          child: const MyCodeCard(compact: true),
        ),
      );
    }
    if (_denied) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.no_photography_outlined, color: Colors.white70, size: 48),
              const SizedBox(height: 14),
              const Text(
                'يلزم إذن الكاميرا لمسح الرمز',
                style: TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 16),
              ),
              const SizedBox(height: 16),
              FilledButton(
                style: FilledButton.styleFrom(minimumSize: const Size(180, 48)),
                onPressed: () async {
                  final st = await Permission.camera.status;
                  if (st.isPermanentlyDenied) {
                    await openAppSettings();
                  } else {
                    await _startCamera();
                  }
                },
                child: const Text('السماح بالكاميرا'),
              ),
            ],
          ),
        ),
      );
    }
    final scanner = _scanner;
    if (scanner == null) {
      return const Center(child: CircularProgressIndicator(color: Colors.white));
    }
    return LayoutBuilder(
      builder: (context, box) {
        final side = (box.maxWidth * 0.72).clamp(200.0, 320.0);
        final window = Rect.fromCenter(
          center: Offset(box.maxWidth / 2, box.maxHeight * 0.40),
          width: side,
          height: side,
        );
        return Stack(
          fit: StackFit.expand,
          children: [
            MobileScanner(
              controller: scanner,
              fit: BoxFit.cover,
              onDetect: _onDetect,
              errorBuilder: (context, error, _) => Center(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Text(
                    'تعذّر تشغيل الكاميرا\n${error.errorDetails?.message ?? error.errorCode.name}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontFamily: kFont, color: Colors.white70),
                  ),
                ),
              ),
            ),
            IgnorePointer(child: CustomPaint(painter: _FramePainter(window))),
            Positioned(
              top: window.bottom + 18,
              left: 24,
              right: 24,
              child: const Text(
                'وجّه الكاميرا نحو رمز صديقك',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: kFont,
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  shadows: [Shadow(blurRadius: 8, color: Colors.black54)],
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _bottomPanel(BuildContext context) {
    final bottom = MediaQuery.paddingOf(context).bottom;
    return Container(
      padding: EdgeInsets.fromLTRB(16, 14, 16, 14 + bottom),
      decoration: const BoxDecoration(
        color: Color(0xFF12131D),
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // مبدّل: مسح / رمزي
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              color: const Color(0xFF1E2030),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                _Segment(
                  label: 'مسح رمز',
                  icon: Icons.qr_code_scanner_rounded,
                  selected: !_showMine,
                  onTap: () => _toggleMine(false),
                ),
                _Segment(
                  label: 'رمزي',
                  icon: Icons.qr_code_2_rounded,
                  selected: _showMine,
                  onTap: () => _toggleMine(true),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          TextButton.icon(
            onPressed: _paste,
            style: TextButton.styleFrom(foregroundColor: Colors.white70),
            icon: const Icon(Icons.content_paste_rounded, size: 19),
            label: const Text('لصق رمز وصلك برسالة'),
          ),
        ],
      ),
    );
  }
}

class _Segment extends StatelessWidget {
  const _Segment({required this.label, required this.icon, required this.selected, required this.onTap});
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          height: 44,
          decoration: BoxDecoration(
            color: selected ? Colors.white : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 19, color: selected ? const Color(0xFF12131D) : Colors.white70),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                  fontFamily: kFont,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  color: selected ? const Color(0xFF12131D) : Colors.white70,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GlassButton extends StatelessWidget {
  const _GlassButton({required this.icon, required this.onTap, this.active = false});
  final IconData icon;
  final VoidCallback? onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? Colors.white : Colors.black.withValues(alpha: 0.35),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon, color: active ? Colors.black : Colors.white, size: 22),
        ),
      ),
    );
  }
}

/// إطار المسح: تعتيم حول نافذة مستديرة الزوايا مع زوايا مضيئة.
/// يستخدم drawDRRect (بدون عمليات Path معقدة) لضمان رسم صحيح على كل الأجهزة.
class _FramePainter extends CustomPainter {
  _FramePainter(this.window);
  final Rect window;

  @override
  void paint(Canvas canvas, Size size) {
    const r = Radius.circular(28);
    final outer = RRect.fromRectAndRadius(Offset.zero & size, Radius.zero);
    final inner = RRect.fromRectAndRadius(window, r);
    canvas.drawDRRect(outer, inner, Paint()..color = Colors.black.withValues(alpha: 0.55));

    final stroke = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    const len = 30.0;
    const rad = 28.0;
    final l = window.left, t = window.top, rt = window.right, b = window.bottom;
    // كل زاوية: خطان + قوس
    void corner(Offset a, Offset c1, Rect arcRect, double start, Offset c2, Offset d) {
      canvas.drawLine(a, c1, stroke);
      canvas.drawArc(arcRect, start, 1.5708, false, stroke);
      canvas.drawLine(c2, d, stroke);
    }

    corner(Offset(l, t + rad + len), Offset(l, t + rad),
        Rect.fromLTWH(l, t, rad * 2, rad * 2), 3.14159, Offset(l + rad, t), Offset(l + rad + len, t));
    corner(Offset(rt - rad - len, t), Offset(rt - rad, t),
        Rect.fromLTWH(rt - rad * 2, t, rad * 2, rad * 2), -1.5708, Offset(rt, t + rad), Offset(rt, t + rad + len));
    corner(Offset(rt, b - rad - len), Offset(rt, b - rad),
        Rect.fromLTWH(rt - rad * 2, b - rad * 2, rad * 2, rad * 2), 0, Offset(rt - rad, b), Offset(rt - rad - len, b));
    corner(Offset(l + rad + len, b), Offset(l + rad, b),
        Rect.fromLTWH(l, b - rad * 2, rad * 2, rad * 2), 1.5708, Offset(l, b - rad), Offset(l, b - rad - len));
  }

  @override
  bool shouldRepaint(covariant _FramePainter old) => old.window != window;
}

class _ConfirmSheet extends StatelessWidget {
  const _ConfirmSheet({required this.card});
  final ContactCard card;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final name = card.name.isEmpty ? 'جهة اتصال' : card.name;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Avatar(name: name, seed: card.id, size: 84),
            const SizedBox(height: 14),
            Text(name, style: context.txt.headlineSmall),
            const SizedBox(height: 4),
            Text(
              prettyId(card.id),
              textDirection: TextDirection.ltr,
              style: context.txt.bodySmall!.copyWith(letterSpacing: 1.4),
            ),
            const SizedBox(height: 14),
            Text(
              'ستُضاف إلى جهات اتصالك، ويصله طلب لإضافتك أيضاً.',
              textAlign: TextAlign.center,
              style: context.txt.bodyMedium!.copyWith(color: p.muted),
            ),
            const SizedBox(height: 22),
            FilledButton.icon(
              onPressed: () => Navigator.pop(context, true),
              icon: const Icon(Icons.person_add_alt_1_rounded),
              label: const Text('إضافة وبدء المحادثة'),
            ),
            const SizedBox(height: 6),
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('إلغاء', style: TextStyle(color: p.muted)),
            ),
          ],
        ),
      ),
    );
  }
}
