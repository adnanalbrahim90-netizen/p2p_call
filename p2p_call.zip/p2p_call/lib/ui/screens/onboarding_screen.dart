import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../widgets/common.dart';

/// الإعداد الأول: تعريف بالتطبيق ثم الاسم وقفل البصمة
class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _name = TextEditingController();
  int _step = 0;
  bool _lock = true;
  bool _busy = false;

  AppController get c => AppController.I;

  @override
  void initState() {
    super.initState();
    c.refreshBiometric().then((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _finish() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      showSnack(context, 'اكتب اسمك ليعرفك أصدقاؤك');
      return;
    }
    setState(() => _busy = true);
    var lock = _lock && c.biometricSupported;
    if (lock) {
      lock = await c.verifyBiometric();
      if (!lock && mounted) {
        showSnack(context, 'لم يتم تفعيل القفل — يمكنك تفعيله لاحقاً من الإعدادات');
      }
    }
    await c.createIdentity(name, lock: lock);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 350),
          switchInCurve: Curves.easeOutCubic,
          transitionBuilder: (child, anim) => FadeTransition(
            opacity: anim,
            child: SlideTransition(
              position: Tween(begin: const Offset(0, 0.04), end: Offset.zero).animate(anim),
              child: child,
            ),
          ),
          child: _step == 0 ? _welcome(context) : _profile(context),
        ),
      ),
    );
  }

  Widget _welcome(BuildContext context) {
    final p = context.pal;
    return Padding(
      key: const ValueKey('welcome'),
      padding: const EdgeInsets.fromLTRB(24, 32, 24, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const AppLogo(size: 76),
          const SizedBox(height: 28),
          Text('اتصال مباشر', style: context.txt.displaySmall),
          const SizedBox(height: 10),
          Text(
            'رسائل ومكالمات صوت وفيديو تنتقل مباشرة من هاتفك إلى هاتف صديقك.',
            style: context.txt.bodyLarge!.copyWith(color: p.muted),
          ),
          const SizedBox(height: 32),
          const _Feature(
            icon: Icons.bolt_rounded,
            title: 'مباشر بين الهاتفين',
            text: 'لا توجد خوادم تخزّن رسائلك أو صورك أو مكالماتك.',
          ),
          const _Feature(
            icon: Icons.lock_rounded,
            title: 'مشفّر بالكامل',
            text: 'كل ما ترسله مشفّر طرفاً لطرف، ولا يقرؤه أحد غيركما.',
          ),
          const _Feature(
            icon: Icons.qr_code_2_rounded,
            title: 'رمز ثابت لجهازك',
            text: 'يمسح صديقك رمزك مرة واحدة فقط، وبعدها تتواصلان بضغطة.',
          ),
          const Spacer(),
          FilledButton(
            onPressed: () => setState(() => _step = 1),
            child: const Text('ابدأ'),
          ),
        ],
      ),
    );
  }

  Widget _profile(BuildContext context) {
    final p = context.pal;
    return ListView(
      key: const ValueKey('profile'),
      padding: const EdgeInsets.fromLTRB(24, 12, 24, 24),
      children: [
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: IconButton(
            onPressed: _busy ? null : () => setState(() => _step = 0),
            icon: const Icon(Icons.arrow_back_rounded),
          ),
        ),
        const SizedBox(height: 8),
        Text('عرّف بنفسك', style: context.txt.headlineMedium),
        const SizedBox(height: 8),
        Text(
          'هذا الاسم يظهر لمن يضيفك. يمكنك تغييره لاحقاً.',
          style: context.txt.bodyMedium!.copyWith(color: p.muted),
        ),
        const SizedBox(height: 28),
        Center(
          child: ValueListenableBuilder<TextEditingValue>(
            valueListenable: _name,
            builder: (_, v, __) => Avatar(
              name: v.text.isEmpty ? '؟' : v.text,
              seed: v.text.isEmpty ? 'x' : v.text,
              size: 92,
            ),
          ),
        ),
        const SizedBox(height: 24),
        TextField(
          controller: _name,
          autofocus: true,
          maxLength: 40,
          textInputAction: TextInputAction.done,
          style: context.txt.titleMedium,
          decoration: const InputDecoration(
            hintText: 'اسمك',
            counterText: '',
            prefixIcon: Icon(Icons.person_outline_rounded),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: p.card,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: p.line),
          ),
          child: SwitchListTile(
            value: _lock && c.biometricSupported,
            onChanged: c.biometricSupported ? (v) => setState(() => _lock = v) : null,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            secondary: Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: p.brandSoft,
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(Icons.fingerprint_rounded, color: p.brand),
            ),
            title: const Text('قفل التطبيق بالبصمة'),
            subtitle: Text(
              c.biometricSupported
                  ? 'يُطلب منك فتح القفل عند فتح التطبيق'
                  : 'جهازك لا يدعم القفل البيومتري',
            ),
          ),
        ),
        const SizedBox(height: 32),
        FilledButton(
          onPressed: _busy ? null : _finish,
          child: _busy
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                )
              : const Text('إنشاء حسابي على هذا الجهاز'),
        ),
        const SizedBox(height: 12),
        Text(
          'لا يوجد بريد ولا رقم هاتف — هويتك مفتاح تشفير يُنشأ ويُحفظ على جهازك فقط.',
          textAlign: TextAlign.center,
          style: context.txt.bodySmall,
        ),
      ],
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: p.brandSoft,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Icon(icon, color: p.brand),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: context.txt.titleMedium),
                const SizedBox(height: 2),
                Text(text, style: context.txt.bodyMedium!.copyWith(color: p.muted)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
