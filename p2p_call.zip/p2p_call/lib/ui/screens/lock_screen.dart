import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../net/calls.dart';
import '../widgets/common.dart';

/// طبقة القفل فوق التطبيق كله
class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> with WidgetsBindingObserver {
  AppController get c => AppController.I;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (c.foreground) _unlock();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // قد يكون التطبيق بدأ في الخلفية؛ نطلب البصمة عند ظهوره
    if (state == AppLifecycleState.resumed) {
      Future<void>.delayed(const Duration(milliseconds: 250), _unlock);
    }
  }

  Future<void> _unlock() async {
    final ok = await c.unlock();
    if (!ok && mounted) setState(() => _failed = true);
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final calls = c.calls;
    return Material(
      color: p.bg,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(flex: 3),
              const AppLogo(size: 84),
              const SizedBox(height: 26),
              Text('التطبيق مقفل', style: context.txt.headlineSmall),
              const SizedBox(height: 8),
              Text(
                _failed ? 'لم يتم التحقق. حاول مرة أخرى.' : 'استخدم البصمة أو رمز قفل الهاتف للمتابعة',
                textAlign: TextAlign.center,
                style: context.txt.bodyMedium!.copyWith(color: _failed ? p.danger : p.muted),
              ),
              const Spacer(flex: 2),
              Material(
                color: p.brandSoft,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: _unlock,
                  child: Padding(
                    padding: const EdgeInsets.all(26),
                    child: Icon(Icons.fingerprint_rounded, size: 56, color: p.brand),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text('اضغط لفتح القفل', style: context.txt.labelMedium!.copyWith(color: p.muted)),
              const Spacer(flex: 2),
              if (calls != null)
                ListenableBuilder(
                  listenable: calls,
                  builder: (context, _) {
                    final s = calls.current;
                    if (s == null || s.phase != CallPhase.ringing) return const SizedBox.shrink();
                    return _IncomingBanner(name: s.contact.displayName, video: s.video, onDecline: calls.decline);
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _IncomingBanner extends StatelessWidget {
  const _IncomingBanner({required this.name, required this.video, required this.onDecline});
  final String name;
  final bool video;
  final VoidCallback onDecline;

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: p.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: p.line),
      ),
      child: Row(
        children: [
          PulseDot(color: p.success, size: 9),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(video ? 'مكالمة فيديو واردة' : 'مكالمة صوتية واردة',
                    style: context.txt.labelMedium!.copyWith(color: p.muted)),
                Text(name, style: context.txt.titleMedium),
                Text('افتح القفل للرد', style: context.txt.bodySmall),
              ],
            ),
          ),
          IconButton.filled(
            style: IconButton.styleFrom(backgroundColor: p.danger),
            onPressed: onDecline,
            icon: const Icon(Icons.call_end_rounded, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
