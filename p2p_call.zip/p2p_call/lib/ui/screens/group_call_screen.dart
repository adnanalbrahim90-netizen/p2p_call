import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../net/calls.dart';
import '../../net/group_calls.dart';
import '../widgets/common.dart';
import 'call_actions.dart';

/// شاشة المكالمة الجماعية: رنين ← شبكة مشاركين
class GroupCallScreen extends StatefulWidget {
  const GroupCallScreen({super.key, required this.session});
  final GroupCallSession session;

  static Route<void> route(GroupCallSession s) => PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 320),
        reverseTransitionDuration: const Duration(milliseconds: 240),
        pageBuilder: (_, __, ___) => GroupCallScreen(session: s),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
      );

  @override
  State<GroupCallScreen> createState() => _GroupCallScreenState();
}

class _GroupCallScreenState extends State<GroupCallScreen> {
  GroupCallSession get s => widget.session;
  GroupCallManager get gc => AppController.I.groupCalls!;

  Timer? _ticker;
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    s.addListener(_onChange);
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && s.firstPeerAt != null) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    s.removeListener(_onChange);
    super.dispose();
  }

  void _onChange() {
    if (!mounted) return;
    if (s.phase == GroupCallPhase.ended && !_closing) {
      _closing = true;
      Timer(const Duration(milliseconds: 1300), () {
        if (mounted) Navigator.of(context).maybePop();
      });
    }
    setState(() {});
  }

  Future<void> _join() async {
    HapticFeedback.mediumImpact();
    if (!await ensureCallPermissions(context, video: s.video)) {
      gc.decline();
      return;
    }
    await gc.join(ringing: s);
  }

  String get _status {
    switch (s.phase) {
      case GroupCallPhase.ringing:
        final who = AppController.I.store.nameOf(s.inviterId);
        return '$who يدعوك إلى ${s.video ? 'مكالمة فيديو' : 'مكالمة صوتية'} جماعية';
      case GroupCallPhase.joined:
        if (s.peers.isEmpty) return s.startedByMe ? 'جارٍ دعوة الأعضاء…' : 'جارٍ الانضمام…';
        final n = s.peers.length + 1;
        return '$n مشاركين • ${formatDuration(s.elapsed)}';
      case GroupCallPhase.ended:
        return s.endReason ?? 'انتهت المكالمة';
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: s.phase == GroupCallPhase.ended,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (s.phase == GroupCallPhase.ringing) {
          gc.decline();
          return;
        }
        if (await confirmDialog(
          context,
          title: 'مغادرة المكالمة؟',
          message: 'ستستمر المكالمة بين بقية المشاركين.',
          confirm: 'مغادرة',
          danger: true,
        )) {
          gc.leave();
        }
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: Scaffold(
          backgroundColor: const Color(0xFF07080F),
          body: Stack(
            fit: StackFit.expand,
            children: [
              _backdrop(),
              SafeArea(
                child: Column(
                  children: [
                    _header(),
                    Expanded(
                      child: s.phase == GroupCallPhase.ringing ? _ringing() : _grid(),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                      child: s.phase == GroupCallPhase.ringing ? _ringControls() : _controls(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _backdrop() {
    final colors = avatarColors(s.group.id);
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(0, -0.5),
          radius: 1.3,
          colors: [colors.first.withValues(alpha: 0.45), const Color(0xFF07080F)],
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
      child: Row(
        children: [
          GroupAvatar(name: s.group.name, seed: s.group.id, size: 42),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  s.group.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
                ),
                Text(
                  _status,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: kFont,
                    color: s.phase == GroupCallPhase.ended ? const Color(0xFFFFA8AB) : Colors.white70,
                    fontSize: 13,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.lock_rounded, color: Colors.white60, size: 13),
                SizedBox(width: 4),
                Text('مشفّرة', style: TextStyle(fontFamily: kFont, color: Colors.white60, fontSize: 11.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ringing() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          RingPulse(
            size: 120,
            child: GroupAvatar(name: s.group.name, seed: s.group.id, size: 120),
          ),
          const SizedBox(height: 18),
          Text(
            s.video ? 'مكالمة فيديو جماعية' : 'مكالمة صوتية جماعية',
            style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 22, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Text(
            '${s.group.members.length} أعضاء في القروب',
            style: const TextStyle(fontFamily: kFont, color: Colors.white60, fontSize: 14),
          ),
        ],
      ),
    );
  }

  /// شبكة المشاركين: أنا + كل طرف متصل
  Widget _grid() {
    final tiles = <Widget>[
      _Tile(
        name: 'أنت',
        seed: AppController.I.store.selfId,
        renderer: s.video && s.camOn && s.localStream != null ? s.localRenderer : null,
        mirror: s.frontCamera,
        muted: !s.micOn,
      ),
      for (final p in s.peers.values)
        _Tile(
          name: p.name,
          seed: p.id,
          renderer: s.video && p.hasVideo && p.camOn ? p.renderer : null,
          connecting: !p.connected,
        ),
    ];
    return LayoutBuilder(
      builder: (context, box) {
        final n = tiles.length;
        final cols = n <= 2 ? 1 : 2;
        final rows = (n / cols).ceil();
        const gap = 8.0;
        final w = (box.maxWidth - 24 - gap * (cols - 1)) / cols;
        final h = ((box.maxHeight - 8 - gap * (rows - 1)) / rows).clamp(120.0, 600.0);
        return SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
          child: Wrap(
            spacing: gap,
            runSpacing: gap,
            children: [
              for (final t in tiles) SizedBox(width: w, height: h, child: t),
            ],
          ),
        );
      },
    );
  }

  Widget _ringControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _BigButton(color: const Color(0xFFE5484D), icon: Icons.call_end_rounded, label: 'رفض', onTap: gc.decline),
        _BigButton(
          color: const Color(0xFF12B76A),
          icon: s.video ? Icons.videocam_rounded : Icons.call_rounded,
          label: 'انضمام',
          onTap: _join,
        ),
      ],
    );
  }

  Widget _controls() {
    final ended = s.phase == GroupCallPhase.ended;
    return ClipRRect(
      borderRadius: BorderRadius.circular(32),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: Colors.white12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _Ctrl(
                icon: s.speakerOn ? Icons.volume_up_rounded : Icons.hearing_rounded,
                label: s.speakerOn ? 'السماعة' : 'الأذن',
                on: s.speakerOn,
                onTap: ended ? null : gc.toggleSpeaker,
              ),
              _Ctrl(
                icon: s.micOn ? Icons.mic_rounded : Icons.mic_off_rounded,
                label: s.micOn ? 'الميكروفون' : 'مكتوم',
                on: !s.micOn,
                onTap: ended ? null : gc.toggleMic,
              ),
              if (s.video)
                _Ctrl(
                  icon: s.camOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                  label: 'الكاميرا',
                  on: !s.camOn,
                  onTap: ended ? null : gc.toggleCamera,
                ),
              if (s.video)
                _Ctrl(
                  icon: Icons.cameraswitch_rounded,
                  label: 'تبديل',
                  on: false,
                  onTap: ended || !s.camOn ? null : gc.switchCamera,
                ),
              _Ctrl(
                icon: Icons.call_end_rounded,
                label: 'مغادرة',
                on: false,
                danger: true,
                onTap: ended ? null : gc.leave,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.name,
    required this.seed,
    this.renderer,
    this.mirror = false,
    this.muted = false,
    this.connecting = false,
  });

  final String name;
  final String seed;
  final RTCVideoRenderer? renderer;
  final bool mirror;
  final bool muted;
  final bool connecting;

  @override
  Widget build(BuildContext context) {
    final colors = avatarColors(seed);
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [colors.first.withValues(alpha: 0.35), const Color(0xFF151724)],
              ),
            ),
          ),
          if (renderer != null)
            RTCVideoView(renderer!, mirror: mirror, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)
          else
            Center(child: Avatar(name: name, seed: seed, size: 72)),
          if (connecting)
            Container(
              color: Colors.black38,
              alignment: Alignment.center,
              child: const SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
              ),
            ),
          PositionedDirectional(
            start: 10,
            bottom: 10,
            end: 10,
            child: Row(
              children: [
                Flexible(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(10)),
                    child: Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 12.5),
                    ),
                  ),
                ),
                if (muted) ...[
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(color: Colors.black45, shape: BoxShape.circle),
                    child: const Icon(Icons.mic_off_rounded, color: Colors.white, size: 14),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BigButton extends StatelessWidget {
  const _BigButton({required this.color, required this.icon, required this.label, required this.onTap});
  final Color color;
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: color,
          shape: const CircleBorder(),
          elevation: 6,
          shadowColor: color.withValues(alpha: 0.6),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(width: 74, height: 74, child: Icon(icon, color: Colors.white, size: 34)),
          ),
        ),
        const SizedBox(height: 10),
        Text(label, style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 14)),
      ],
    );
  }
}

class _Ctrl extends StatelessWidget {
  const _Ctrl({required this.icon, required this.label, required this.on, required this.onTap, this.danger = false});
  final IconData icon;
  final String label;
  final bool on;
  final bool danger;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final bg = danger ? const Color(0xFFE5484D) : (on ? Colors.white : Colors.white.withValues(alpha: 0.14));
    final fg = danger ? Colors.white : (on ? const Color(0xFF111426) : Colors.white);
    final size = danger ? 60.0 : 52.0;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
          child: Material(
            color: Colors.transparent,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap == null
                  ? null
                  : () {
                      HapticFeedback.lightImpact();
                      onTap!();
                    },
              child: Icon(icon, color: onTap == null ? fg.withValues(alpha: 0.4) : fg, size: danger ? 28 : 24),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontFamily: kFont, color: Colors.white70, fontSize: 11)),
      ],
    );
  }
}
