import 'package:flutter/material.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../core/models.dart';
import '../widgets/common.dart';
import 'chat_screen.dart';

/// إنشاء قروب جديد، أو إضافة أعضاء لقروب موجود (عند تمرير [group])
class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key, this.group});
  final Group? group;

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen> {
  final _name = TextEditingController();
  final Set<String> _selected = {};
  bool _busy = false;

  AppController get c => AppController.I;
  bool get adding => widget.group != null;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final gs = c.groups;
    if (gs == null) return;
    final chosen = c.store.contacts.where((x) => _selected.contains(x.id)).toList();
    if (adding) {
      if (chosen.isEmpty) return;
      setState(() => _busy = true);
      await gs.addMembers(widget.group!, chosen);
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final name = _name.text.trim();
    if (name.isEmpty) {
      showSnack(context, 'اكتب اسماً للقروب');
      return;
    }
    if (chosen.isEmpty) {
      showSnack(context, 'اختر عضواً واحداً على الأقل');
      return;
    }
    setState(() => _busy = true);
    final g = await gs.create(name, chosen);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(ChatScreen.route(g.chatId));
  }

  @override
  Widget build(BuildContext context) {
    final p = context.pal;
    final all = c.store.contacts;
    final existing = widget.group;
    final candidates = all.where((x) => existing == null || !existing.has(x.id)).toList();

    return Scaffold(
      appBar: AppBar(title: Text(adding ? 'إضافة أعضاء' : 'قروب جديد')),
      body: Column(
        children: [
          if (!adding)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
              child: Row(
                children: [
                  ValueListenableBuilder<TextEditingValue>(
                    valueListenable: _name,
                    builder: (_, v, __) => GroupAvatar(
                      name: v.text.isEmpty ? '؟' : v.text,
                      seed: v.text.isEmpty ? 'group' : v.text,
                      size: 56,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: TextField(
                      controller: _name,
                      maxLength: 40,
                      autofocus: true,
                      style: context.txt.titleMedium,
                      decoration: const InputDecoration(hintText: 'اسم القروب', counterText: ''),
                    ),
                  ),
                ],
              ),
            ),
          SectionLabel(adding ? 'اختر من جهات اتصالك' : 'الأعضاء (${_selected.length})'),
          Expanded(
            child: candidates.isEmpty
                ? EmptyState(
                    icon: Icons.person_search_rounded,
                    title: adding ? 'كل جهات اتصالك في القروب' : 'لا توجد جهات اتصال',
                    message: adding
                        ? 'أضف جهات اتصال جديدة بمسح رموزها ثم عد إلى هنا.'
                        : 'أضف أصدقاءك أولاً بمسح رموزهم، ثم أنشئ القروب.',
                  )
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 100),
                    itemCount: candidates.length,
                    itemBuilder: (context, i) {
                      final ct = candidates[i];
                      final ok = ct.confirmed;
                      final sel = _selected.contains(ct.id);
                      return ListTile(
                        enabled: ok,
                        onTap: () => setState(() => sel ? _selected.remove(ct.id) : _selected.add(ct.id)),
                        leading: Avatar(name: ct.displayName, seed: ct.id, size: 44, online: c.isOnline(ct.id)),
                        title: Text(ct.displayName),
                        subtitle: ok ? null : const Text('بانتظار قبوله لطلب الإضافة'),
                        trailing: AnimatedContainer(
                          duration: const Duration(milliseconds: 160),
                          width: 26,
                          height: 26,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: sel ? p.brand : Colors.transparent,
                            border: Border.all(color: sel ? p.brand : p.line, width: 2),
                          ),
                          child: sel ? const Icon(Icons.check_rounded, size: 17, color: Colors.white) : null,
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: candidates.isEmpty
          ? null
          : FloatingActionButton.extended(
              onPressed: _busy || _selected.isEmpty ? null : _submit,
              backgroundColor: _selected.isEmpty ? p.muted : p.brand,
              icon: _busy
                  ? const SizedBox(
                      width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                  : Icon(adding ? Icons.person_add_alt_1_rounded : Icons.check_rounded),
              label: Text(
                adding ? 'إضافة (${_selected.length})' : 'إنشاء القروب',
                style: const TextStyle(fontFamily: kFont, fontWeight: FontWeight.w600),
              ),
            ),
    );
  }
}
