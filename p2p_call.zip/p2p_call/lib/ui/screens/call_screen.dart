import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../../app/controller.dart';
import '../../app/theme.dart';
import '../../net/calls.dart';
import '../widgets/common.dart';
import 'call_actions.dart';

/// شاشة المكالمة: صادرة / واردة / جارية — صوت أو فيديو
class CallScreen extends StatefulWidget {
  const CallScreen({super.key, required this.session});
  final CallSession session;

  static Route<void> route(CallSession s) => PageRouteBuilder<void>(
        opaque: true,
        transitionDuration: const Duration(milliseconds: 320),
        reverseTransitionDuration: const Duration(milliseconds: 240),
        pageBuilder: (_, __, ___) => CallScreen(session: s),
        transitionsBuilder: (_, anim, __, child) => FadeTransition(
          opacity: anim,
          child: ScaleTransition(
            scale: Tween(begin: 1.04, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
            child: child,
          ),
        ),
      );

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  CallSession get s => widget.session;
  CallManager get calls => AppController.I.calls!;

  Timer? _ticker;
  Offset? _pip;
  bool _dragging = false;
  bool _controls = true;
  bool _closing = false;

  static const double _pipW = 108;
  static const double _pipH = 156;

  @override
  void initState() {
    super.initState();
    s.addListener(_onChange);
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && s.phase == CallPhase.active) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    s.removeListener(_onChange);
    super.dispose();
  }

  void _onChange() {
    if (!mounted) return;
    if (s.phase == CallPhase.ended && !_closing) {
      _closing = true;
      Timer(const Duration(milliseconds: 1300), () {
        if (mounted) Navigator.of(context).maybePop();
      });
    }
    setState(() {});
  }

  Future<void> _accept() async {
    HapticFeedback.mediumImpact();
    if (!await ensureCallPermissions(context, video: s.video)) {
      calls.decline();
      return;
    }
    await calls.accept();
  }

  String get _status {
    switch (s.phase) {
      case CallPhase.calling:
        return AppController.I.isOnline(s.contact.id) ? 'جارٍ الرنين…' : 'جارٍ الاتصال…';
      case CallPhase.ringing:
        return s.video ? 'مكالمة فيديو واردة' : 'مكالمة صوتية واردة';
      case CallPhase.connecting:
        return 'جارٍ الاتصال المباشر…';
      case CallPhase.active:
        return s.reconnecting ? 'انقطاع مؤقت… جارٍ الاستعادة' : formatDuration(s.elapsed);
      case CallPhase.ended:
        return s.endReason ?? 'انتهت المكالمة';
    }
  }

  @override
  Widget build(BuildContext context) {
    final showRemoteVideo =
        s.video && s.phase == CallPhase.active && s.hasRemoteVideo && s.remoteCamOn;
    final showLocalFull = s.video && s.camOn && s.phase != CallPhase.active && s.phase != CallPhase.ringing &&
        s.localStream != null;

    return PopScope(
      canPop: s.phase == CallPhase.ended,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmHangUp();
      },
      child: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: Scaffold(
          backgroundColor: const Color(0xFF07080F),
          body: LayoutBuilder(
            builder: (context, box) {
              final pad = MediaQuery.paddingOf(context);
              _pip ??= Offset(16, pad.top + 84);
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: s.phase == CallPhase.active && s.video
                    ? () => setState(() => _controls = !_controls)
                    : null,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    _Backdrop(seed: s.contact.id),
                    if (showLocalFull)
                      RTCVideoView(
                        s.localRenderer,
                        mirror: s.frontCamera,
                        objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                      ),
                    if (s.video && s.hasRemoteVideo)
                      AnimatedOpacity(
                        duration: const Duration(milliseconds: 400),
                        opacity: showRemoteVideo ? 1 : 0,
                        child: RTCVideoView(
                          s.remoteRenderer,
                          objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                        ),
                      ),
                    if (showRemoteVideo || showLocalFull) const _Scrims(),
                    if (!showRemoteVideo) _identity(context, compact: showLocalFull),
                    if (showRemoteVideo) _topBar(context, pad),
                    if (s.video && s.phase == CallPhase.active && s.camOn) _pipView(box, pad),
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: AnimatedSlide(
                        duration: const Duration(milliseconds: 250),
                        offset: _controls || !showRemoteVideo ? Offset.zero : const Offset(0, 1.3),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(20, 0, 20, pad.bottom + 28),
                          child: s.phase == CallPhase.ringing ? _incomingControls() : _activeControls(),
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _identity(BuildContext context, {required bool compact}) {
    final ringing = s.phase == CallPhase.calling || s.phase == CallPhase.ringing;
    final name = s.contact.displayName;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(top: compact ? 24 : 70),
        child: Align(
          alignment: Alignment.topCenter,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!compact)
                RingPulse(
                  size: 128,
                  active: ringing,
                  child: Avatar(name: name, seed: s.contact.id, size: 128, ring: true),
                ),
              SizedBox(height: compact ? 0 : 8),
              Text(
                name,
                style: const TextStyle(
                  fontFamily: kFont,
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w700,
                  height: 1.3,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                _status,
                style: TextStyle(
                  fontFamily: kFont,
                  color: s.phase == CallPhase.ended ? const Color(0xFFFFA8AB) : Colors.white70,
                  fontSize: 16,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.lock_rounded, color: Colors.white60, size: 14),
                    SizedBox(width: 6),
                    Text('مباشر ومشفّر طرفاً لطرف',
                        style: TextStyle(fontFamily: kFont, color: Colors.white60, fontSize: 12)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topBar(BuildContext context, EdgeInsets pad) {
    return Positioned(
      top: pad.top + 12,
      left: 16,
      right: 16,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 250),
        opacity: _controls ? 1 : 0,
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    s.contact.displayName,
                    style: const TextStyle(
                      fontFamily: kFont,
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w700,
                      shadows: [Shadow(blurRadius: 10, color: Colors.black54)],
                    ),
                  ),
                  Text(
                    _status,
                    style: const TextStyle(
                      fontFamily: kFont,
                      color: Colors.white70,
                      fontSize: 13.5,
                      fontFeatures: [FontFeature.tabularFigures()],
                      shadows: [Shadow(blurRadius: 10, color: Colors.black54)],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _pipView(BoxConstraints box, EdgeInsets pad) {
    final pos = _pip!;
    return AnimatedPositioned(
      duration: _dragging ? Duration.zero : const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      left: pos.dx,
      top: pos.dy,
      width: _pipW,
      height: _pipH,
      child: GestureDetector(
        onPanStart: (_) => setState(() => _dragging = true),
        onPanUpdate: (d) => setState(() {
          final n = _pip! + d.delta;
          _pip = Offset(
            n.dx.clamp(8.0, box.maxWidth - _pipW - 8).toDouble(),
            n.dy.clamp(pad.top + 8, box.maxHeight - _pipH - 170).toDouble(),
          );
        }),
        onPanEnd: (_) => setState(() {
          _dragging = false;
          final left = _pip!.dx + _pipW / 2 < box.maxWidth / 2;
          _pip = Offset(left ? 16 : box.maxWidth - _pipW - 16, _pip!.dy);
        }),
        onDoubleTap: calls.switchCamera,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white30, width: 1.5),
            boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 18)],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(19),
            child: RTCVideoView(
              s.localRenderer,
              mirror: s.frontCamera,
              objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
            ),
          ),
        ),
      ),
    );
  }

  Widget _incomingControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _BigButton(
          color: const Color(0xFFE5484D),
          icon: Icons.call_end_rounded,
          label: 'رفض',
          onTap: calls.decline,
        ),
        _BigButton(
          color: const Color(0xFF12B76A),
          icon: s.video ? Icons.videocam_rounded : Icons.call_rounded,
          label: 'رد',
          onTap: _accept,
        ),
      ],
    );
  }

  Widget _activeControls() {
    final ended = s.phase == CallPhase.ended;
    return ClipRRect(
      borderRadius: BorderRadius.circular(32),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: Colors.white12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _CtrlButton(
                icon: s.speakerOn ? Icons.volume_up_rounded : Icons.hearing_rounded,
                label: s.speakerOn ? 'السماعة' : 'الأذن',
                on: s.speakerOn,
                onTap: ended ? null : calls.toggleSpeaker,
              ),
              _CtrlButton(
                icon: s.micOn ? Icons.mic_rounded : Icons.mic_off_rounded,
                label: s.micOn ? 'الميكروفون' : 'مكتوم',
                on: !s.micOn,
                onTap: ended ? null : calls.toggleMic,
              ),
              if (s.video)
                _CtrlButton(
                  icon: s.camOn ? Icons.videocam_rounded : Icons.videocam_off_rounded,
                  label: 'الكاميرا',
                  on: !s.camOn,
                  onTap: ended ? null : calls.toggleCamera,
                ),
              if (s.video)
                _CtrlButton(
                  icon: Icons.cameraswitch_rounded,
                  label: 'تبديل',
                  on: false,
                  onTap: ended || !s.camOn ? null : calls.switchCamera,
                ),
              _CtrlButton(
                icon: Icons.call_end_rounded,
                label: 'إنهاء',
                danger: true,
                on: false,
                onTap: ended ? null : calls.hangUp,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmHangUp() async {
    if (s.phase == CallPhase.ringing) {
      calls.decline();
      return;
    }
    final ok = await confirmDialog(
      context,
      title: 'إنهاء المكالمة؟',
      message: 'سيتم قطع الاتصال مع ${s.contact.displayName}.',
      confirm: 'إنهاء',
      danger: true,
    );
    if (ok) calls.hangUp();
  }
}

class _Backdrop extends StatelessWidget {
  const _Backdrop({required this.seed});
  final String seed;

  @override
  Widget build(BuildContext context) {
    final colors = avatarColors(seed);
    return Container(
      decoration: BoxDecoration(
        gradient: RadialGradient(
          center: const Alignment(0, -0.45),
          radius: 1.2,
          colors: [colors.first.withValues(alpha: 0.55), const Color(0xFF07080F)],
        ),
      ),
    );
  }
}

class _Scrims extends StatelessWidget {
  const _Scrims();

  @override
  Widget build(BuildContext context) {
    return const IgnorePointer(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0x99000000), Colors.transparent, Colors.transparent, Color(0xAA000000)],
            stops: [0, 0.22, 0.65, 1],
          ),
        ),
      ),
    );
  }
}

class _BigButton extends StatelessWidget {
  const _BigButton({required this.color, required this.icon, required this.label, required this.onTap});
  final Color color;
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: color,
          shape: const CircleBorder(),
          elevation: 6,
          shadowColor: color.withValues(alpha: 0.6),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onTap,
            child: SizedBox(width: 74, height: 74, child: Icon(icon, color: Colors.white, size: 34)),
          ),
        ),
        const SizedBox(height: 10),
        Text(label, style: const TextStyle(fontFamily: kFont, color: Colors.white, fontSize: 14)),
      ],
    );
  }
}

class _CtrlButton extends StatelessWidget {
  const _CtrlButton({
    required this.icon,
    required this.label,
    required this.on,
    required this.onTap,
    this.danger = false,
  });

  final IconData icon;
  final String label;
  final bool on;
  final bool danger;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final bg = danger
        ? const Color(0xFFE5484D)
        : on
            ? Colors.white
            : Colors.white.withValues(alpha: 0.14);
    final fg = danger ? Colors.white : (on ? const Color(0xFF111426) : Colors.white);
    final size = danger ? 60.0 : 52.0;
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          width: size,
          height: size,
          decoration: BoxDecoration(color: bg, shape: BoxShape.circle),
          child: Material(
            color: Colors.transparent,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap == null
                  ? null
                  : () {
                      HapticFeedback.lightImpact();
                      onTap!();
                    },
              child: Icon(icon, color: onTap == null ? fg.withValues(alpha: 0.4) : fg, size: danger ? 28 : 24),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(label, style: const TextStyle(fontFamily: kFont, color: Colors.white70, fontSize: 11)),
      ],
    );
  }
}
