import 'package:flutter/material.dart';

import '../theme.dart';
import '../widgets/common.dart';
import 'guest_screen.dart';
import 'host_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _go(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AppBackground(
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(22, 24, 22, 28),
            children: [
              const SizedBox(height: 12),
              Center(
                child: Container(
                  width: 92,
                  height: 92,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: AppColors.primaryGradient,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.mint.withOpacity(0.45),
                        blurRadius: 40,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.wifi_tethering_rounded,
                      size: 46, color: Color(0xFF04121A)),
                ),
              ),
              const SizedBox(height: 22),
              const Text(
                'اتصال مباشر',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              const Text(
                'صوت وفيديو ودردشة من هاتف إلى هاتف\nبدون سيرفر وبدون حسابات',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, fontSize: 15, height: 1.6),
              ),
              const SizedBox(height: 34),
              _ActionCard(
                title: 'إنشاء غرفة اتصال',
                subtitle: 'أنت المضيف — اعرض الرمز لصديقك',
                tag: 'Host',
                icon: Icons.add_call,
                gradient: AppColors.primaryGradient,
                onTap: () => _go(context, const HostScreen()),
              ),
              const SizedBox(height: 14),
              _ActionCard(
                title: 'الانضمام لمكالمة',
                subtitle: 'امسح رمز المضيف وانضم فوراً',
                tag: 'Join',
                icon: Icons.qr_code_scanner_rounded,
                gradient: AppColors.secondaryGradient,
                onTap: () => _go(context, const GuestScreen()),
              ),
              const SizedBox(height: 30),
              const Text(
                'كيف يعمل؟',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),
              const GlassCard(
                padding: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: Column(
                  children: [
                    _HowStep(
                        n: '1',
                        text: 'المضيف ينشئ الغرفة ويعرض رمز الدعوة.'),
                    _HowStep(
                        n: '2',
                        text: 'الضيف يمسح رمز الدعوة فيظهر عنده رمز الرد.'),
                    _HowStep(
                        n: '3',
                        text: 'المضيف يمسح رمز الرد — وتبدأ المكالمة مباشرة.',
                        last: true),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline_rounded,
                      size: 16, color: AppColors.muted.withOpacity(0.8)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'يمكن أيضاً نسخ الرمز وإرساله عبر واتساب إن كان صديقك بعيداً. '
                      'أفضل نتيجة عندما يكون الهاتفان على شبكة Wi-Fi.',
                      style: TextStyle(
                          color: AppColors.muted.withOpacity(0.85),
                          fontSize: 12.5,
                          height: 1.6),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ActionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String tag;
  final IconData icon;
  final Gradient gradient;
  final VoidCallback onTap;

  const _ActionCard({
    required this.title,
    required this.subtitle,
    required this.tag,
    required this.icon,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: EdgeInsets.zero,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    gradient: gradient,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: gradient.colors.first.withOpacity(0.4),
                        blurRadius: 18,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: Icon(icon, color: Colors.white, size: 30),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(title,
                                style: const TextStyle(
                                    fontSize: 17, fontWeight: FontWeight.w800)),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.white10,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(tag,
                                style: const TextStyle(
                                    fontSize: 10.5,
                                    color: AppColors.muted,
                                    fontWeight: FontWeight.w700)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5),
                      Text(subtitle,
                          style: const TextStyle(
                              color: AppColors.muted, fontSize: 13)),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_forward_ios_rounded,
                    size: 16, color: AppColors.muted),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _HowStep extends StatelessWidget {
  final String n;
  final String text;
  final bool last;
  const _HowStep({required this.n, required this.text, this.last = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        border: last
            ? null
            : const Border(bottom: BorderSide(color: AppColors.stroke)),
      ),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.mint.withOpacity(0.14),
            ),
            child: Text(n,
                style: const TextStyle(
                    color: AppColors.mint, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(text,
                style: const TextStyle(fontSize: 13.5, height: 1.5)),
          ),
        ],
      ),
    );
  }
}
