import 'package:flutter/material.dart';

import '../services/permissions.dart';
import '../services/webrtc_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'call_screen.dart';
import 'scanner_screen.dart';

enum _HostStage { preparing, ready, applying, error }

/// مسار المُنشئ (Host):
/// تجهيز الوسائط ← Offer ← انتظار ICE ← عرض QR 1 ← مسح QR 2 ← بدء المكالمة
class HostScreen extends StatefulWidget {
  const HostScreen({super.key});

  @override
  State<HostScreen> createState() => _HostScreenState();
}

class _HostScreenState extends State<HostScreen> {
  WebRTCService _svc = WebRTCService(CallRole.host);
  _HostStage _stage = _HostStage.preparing;
  String? _code;
  String? _error;
  bool _permanentlyDenied = false;
  bool _handedOff = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  @override
  void dispose() {
    if (!_handedOff) _svc.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    if (_svc.isDisposed || _stage == _HostStage.error) {
      if (!_svc.isDisposed) _svc.dispose();
      _svc = WebRTCService(CallRole.host);
    }
    setState(() {
      _stage = _HostStage.preparing;
      _error = null;
      _code = null;
    });

    final perm = await ensureCallPermissions();
    if (!mounted) return;
    if (perm != PermissionResult.granted) {
      setState(() {
        _stage = _HostStage.error;
        _permanentlyDenied = perm == PermissionResult.permanentlyDenied;
        _error = 'يلزم السماح بالكاميرا والميكروفون لإجراء المكالمة.';
      });
      return;
    }

    try {
      await _svc.init();
      final code = await _svc.createOfferCode();
      if (!mounted) return;
      setState(() {
        _code = code;
        _stage = _HostStage.ready;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _stage = _HostStage.error;
        _permanentlyDenied = false;
        _error = 'تعذّر تجهيز الاتصال.\n$e';
      });
    }
  }

  Future<void> _scanReply() async {
    // تحرير الكاميرا حتى يتمكن الماسح من استخدامها
    await _svc.releaseCamera();
    if (!mounted) return;
    final raw = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => const ScannerScreen(
          title: 'امسح رمز الرد',
          hint: 'وجّه الكاميرا نحو رمز الرد الظاهر على هاتف صديقك',
        ),
      ),
    );
    await _svc.reacquireCamera();
    if (raw != null && mounted) await _applyReply(raw);
  }

  Future<void> _pasteReply() async {
    final text = await readClipboard();
    if (!mounted) return;
    if (text == null) {
      showSnack(context, 'الحافظة فارغة — انسخ رمز الرد أولاً', error: true);
      return;
    }
    await _applyReply(text);
  }

  Future<void> _applyReply(String raw) async {
    setState(() => _stage = _HostStage.applying);
    try {
      await _svc.applyAnswerCode(raw);
      if (!mounted) return;
      _handedOff = true;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => CallScreen(service: _svc)),
      );
    } on FormatException catch (e) {
      if (!mounted) return;
      setState(() => _stage = _HostStage.ready);
      showSnack(context, e.message, error: true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _stage = _HostStage.ready);
      showSnack(context, 'تعذّر تطبيق الرد: $e', error: true);
    }
  }

  int get _stepIndex {
    switch (_stage) {
      case _HostStage.preparing:
      case _HostStage.error:
        return 0;
      case _HostStage.ready:
        return 1;
      case _HostStage.applying:
        return 2;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: const Text('إنشاء غرفة اتصال')),
      body: AppBackground(
        child: SafeArea(
          child: AnimatedBuilder(
            animation: _svc,
            builder: (context, _) => ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              children: [
                StepsBar(
                  steps: const ['تجهيز الاتصال', 'اعرض الرمز', 'امسح الرد'],
                  current: _stepIndex,
                ),
                const SizedBox(height: 22),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 350),
                  child: _buildStage(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStage() {
    switch (_stage) {
      case _HostStage.preparing:
        return _PreparingView(
          key: const ValueKey('prep'),
          svc: _svc,
        );
      case _HostStage.error:
        return ErrorPanel(
          key: const ValueKey('err'),
          message: _error ?? 'حدث خطأ',
          onRetry: _start,
          onOpenSettings: _permanentlyDenied ? openSettings : null,
        );
      case _HostStage.ready:
      case _HostStage.applying:
        return Column(
          key: const ValueKey('ready'),
          children: [
            Row(
              children: [
                SelfPreview(
                  renderer: _svc.localRenderer,
                  visible: _svc.mediaReady,
                ),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('الغرفة جاهزة ✨',
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      SizedBox(height: 4),
                      Text('دع صديقك يمسح هذا الرمز من زر "الانضمام لمكالمة"',
                          style: TextStyle(
                              color: AppColors.muted, fontSize: 13, height: 1.5)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            QrCodeCard(
              data: _code!,
              caption: 'رمز الدعوة (1) — بعد مسحه سيظهر عند صديقك رمز الرد',
            ),
            const SizedBox(height: 24),
            if (_stage == _HostStage.applying)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 14),
                child: CircularProgressIndicator(color: AppColors.mint),
              )
            else ...[
              GradientButton(
                label: 'مسح رد الطرف الآخر',
                icon: Icons.qr_code_scanner_rounded,
                onPressed: _scanReply,
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: GhostButton(
                      label: 'نسخ الرمز',
                      icon: Icons.copy_rounded,
                      onPressed: () => copyToClipboard(context, _code!),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GhostButton(
                      label: 'لصق الرد',
                      icon: Icons.content_paste_rounded,
                      onPressed: _pasteReply,
                    ),
                  ),
                ],
              ),
            ],
          ],
        );
    }
  }
}

class _PreparingView extends StatelessWidget {
  final WebRTCService svc;
  const _PreparingView({super.key, required this.svc});

  @override
  Widget build(BuildContext context) {
    final status = !svc.mediaReady
        ? 'جارٍ تشغيل الكاميرا والميكروفون…'
        : 'جارٍ جمع مسارات الشبكة (ICE)… ${svc.candidateCount}';
    return GlassCard(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
      child: Column(
        children: [
          SelfPreview(
              renderer: svc.localRenderer, visible: svc.mediaReady, size: 110),
          const SizedBox(height: 26),
          const SizedBox(
            width: 30,
            height: 30,
            child: CircularProgressIndicator(
                strokeWidth: 3, color: AppColors.mint),
          ),
          const SizedBox(height: 18),
          Text(status,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          const Text(
            'ننتظر اكتمال جميع المسارات ليعمل الاتصال بدون سيرفر',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.muted, fontSize: 12.5),
          ),
        ],
      ),
    );
  }
}
