import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../services/webrtc_service.dart';
import '../theme.dart';
import '../widgets/chat_sheet.dart';

/// شاشة المكالمة: فيديو الطرف الآخر بملء الشاشة + فيديو المستخدم (PiP)
/// + أزرار التحكم + الدردشة النصية.
class CallScreen extends StatefulWidget {
  final WebRTCService service;
  const CallScreen({super.key, required this.service});

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  static const double _pipW = 112;
  static const double _pipH = 160;

  WebRTCService get s => widget.service;

  Timer? _ticker;
  Timer? _toastTimer;
  DateTime? _connectedAt;
  ChatMessage? _toast;
  Offset? _pip;
  bool _ending = false;
  bool _controlsVisible = true;
  bool _chatSheetOpen = false;
  bool _dragging = false;

  @override
  void initState() {
    super.initState();
    s.addListener(_onServiceChanged);
    s.onIncomingMessage = _showToast;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _connectedAt != null) setState(() {});
    });
    _onServiceChanged();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    _toastTimer?.cancel();
    if (!_ending) {
      s.removeListener(_onServiceChanged);
      s.dispose();
    }
    super.dispose();
  }

  void _onServiceChanged() {
    if (!mounted || _ending) return;
    if (s.isConnected && _connectedAt == null) {
      _connectedAt = DateTime.now();
      HapticFeedback.mediumImpact();
    }
    if (s.remoteHungUp) {
      _end(message: 'أنهى الطرف الآخر المكالمة', notifyRemote: false);
    }
  }

  void _showToast(ChatMessage msg) {
    if (!mounted || _chatSheetOpen) return;
    HapticFeedback.selectionClick();
    setState(() => _toast = msg);
    _toastTimer?.cancel();
    _toastTimer = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => _toast = null);
    });
  }

  Future<void> _end({String? message, bool notifyRemote = true}) async {
    if (_ending) return;
    _ending = true;
    s.removeListener(_onServiceChanged);
    s.onIncomingMessage = null;
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    await s.hangUp(notifyRemote: notifyRemote);
    if (!mounted) return;
    navigator.popUntil((route) => route.isFirst);
    if (message != null) {
      messenger.showSnackBar(SnackBar(content: Text(message)));
    }
  }

  Future<void> _confirmEnd() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.surface,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text('إنهاء المكالمة؟'),
        content: const Text('سيتم قطع الاتصال مع الطرف الآخر.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('متابعة'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('إنهاء', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok == true) _end();
  }

  Future<void> _openChat() async {
    _chatSheetOpen = true;
    _toastTimer?.cancel();
    setState(() => _toast = null);
    s.openChat();
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black38,
      builder: (_) => ChatSheet(service: s),
    );
    _chatSheetOpen = false;
    if (!s.isDisposed) s.closeChat();
  }

  String get _duration {
    final start = _connectedAt;
    if (start == null) return '00:00';
    final d = DateTime.now().difference(start);
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final sec = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$sec' : '$m:$sec';
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _confirmEnd();
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        resizeToAvoidBottomInset: false,
        body: AnimatedBuilder(
          animation: s,
          builder: (context, _) {
            if (s.isDisposed) return const SizedBox.shrink();
            return LayoutBuilder(
              builder: (context, box) {
                final pad = MediaQuery.of(context).padding;
                _pip ??= Offset(box.maxWidth - _pipW - 16, pad.top + 70);
                return Stack(
                  children: [
                    Positioned.fill(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () =>
                            setState(() => _controlsVisible = !_controlsVisible),
                        child: _remoteView(),
                      ),
                    ),
                    _topScrim(),
                    _topBar(pad),
                    _pipView(box, pad),
                    if (_toast != null) _toastBanner(pad),
                    _controls(pad),
                    if (s.isFailed) _failureOverlay(),
                  ],
                );
              },
            );
          },
        ),
      ),
    );
  }

  // ----------------------------- فيديو الطرف الآخر -----------------------------
  Widget _remoteView() {
    final showVideo = s.isConnected && s.hasRemoteVideo && s.remoteCamOn;
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF111A30), Color(0xFF05070D)],
            ),
          ),
        ),
        if (s.hasRemoteVideo)
          AnimatedOpacity(
            duration: const Duration(milliseconds: 400),
            opacity: showVideo ? 1 : 0,
            child: RTCVideoView(
              s.remoteRenderer,
              objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
            ),
          ),
        if (!showVideo) Center(child: _remotePlaceholder()),
      ],
    );
  }

  Widget _remotePlaceholder() {
    String title;
    String subtitle;
    IconData icon;
    if (!s.isConnected) {
      title = 'جارٍ الاتصال…';
      subtitle = 'يتم إنشاء مسار مباشر بين الهاتفين';
      icon = Icons.wifi_tethering_rounded;
    } else if (!s.remoteCamOn) {
      title = 'الكاميرا متوقفة';
      subtitle = 'أوقف الطرف الآخر الفيديو — الصوت مستمر';
      icon = Icons.videocam_off_rounded;
    } else {
      title = 'متصل';
      subtitle = 'بانتظار وصول الفيديو…';
      icon = Icons.person_rounded;
    }
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 130,
          height: 130,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: AppColors.secondaryGradient,
            boxShadow: [
              BoxShadow(
                  color: AppColors.violet.withOpacity(0.45), blurRadius: 50),
            ],
          ),
          child: Icon(icon, size: 58, color: Colors.white),
        ),
        const SizedBox(height: 22),
        Text(title,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Text(subtitle,
            style: const TextStyle(color: AppColors.muted, fontSize: 14)),
      ],
    );
  }

  // ----------------------------- الشريط العلوي -----------------------------
  Widget _topScrim() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      height: 170,
      child: IgnorePointer(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Colors.black54, Colors.transparent],
            ),
          ),
        ),
      ),
    );
  }

  Widget _topBar(EdgeInsets pad) {
    Color dot;
    String label;
    if (s.isConnected) {
      dot = AppColors.mint;
      label = 'متصل  •  $_duration';
    } else if (s.isReconnecting) {
      dot = AppColors.warning;
      label = 'انقطاع مؤقت… جارٍ الاستعادة';
    } else if (s.isFailed) {
      dot = AppColors.danger;
      label = 'فشل الاتصال';
    } else {
      dot = AppColors.sky;
      label = 'جارٍ الاتصال…';
    }

    return Positioned(
      top: pad.top + 10,
      left: 16,
      right: 16,
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 250),
        opacity: _controlsVisible ? 1 : 0,
        child: Row(
          children: [
            _GlassPill(
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 9,
                    height: 9,
                    decoration:
                        BoxDecoration(shape: BoxShape.circle, color: dot),
                  ),
                  const SizedBox(width: 8),
                  Text(label,
                      style: const TextStyle(
                          fontSize: 13.5,
                          fontWeight: FontWeight.w700,
                          fontFeatures: [FontFeature.tabularFigures()])),
                ],
              ),
            ),
            const Spacer(),
            _GlassPill(
              padding: EdgeInsets.zero,
              child: IconButton(
                tooltip: s.speakerOn ? 'السماعة الخارجية' : 'سماعة الأذن',
                onPressed: s.toggleSpeaker,
                icon: Icon(
                  s.speakerOn
                      ? Icons.volume_up_rounded
                      : Icons.phone_in_talk_rounded,
                  color: Colors.white,
                  size: 21,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ----------------------------- فيديو المستخدم (PiP) -----------------------------
  Widget _pipView(BoxConstraints box, EdgeInsets pad) {
    final pos = _pip!;
    return AnimatedPositioned(
      duration: _dragging ? Duration.zero : const Duration(milliseconds: 220),
      curve: Curves.easeOut,
      left: pos.dx,
      top: pos.dy,
      width: _pipW,
      height: _pipH,
      child: GestureDetector(
        onPanStart: (_) => setState(() => _dragging = true),
        onPanUpdate: (d) {
          final next = pos + d.delta;
          setState(() {
            _pip = Offset(
              next.dx.clamp(8.0, box.maxWidth - _pipW - 8).toDouble(),
              next.dy.clamp(pad.top + 8, box.maxHeight - _pipH - 150).toDouble(),
            );
          });
        },
        onPanEnd: (_) {
          // الالتصاق بأقرب جانب
          final p = _pip!;
          final snapLeft = p.dx + _pipW / 2 < box.maxWidth / 2;
          setState(() {
            _dragging = false;
            _pip = Offset(snapLeft ? 16 : box.maxWidth - _pipW - 16, p.dy);
          });
        },
        onDoubleTap: s.switchCamera,
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white24, width: 1.5),
            boxShadow: const [
              BoxShadow(color: Colors.black54, blurRadius: 20),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(19),
            child: Container(
              color: AppColors.surface,
              child: s.camOn
                  ? RTCVideoView(
                      s.localRenderer,
                      mirror: s.frontCamera,
                      objectFit:
                          RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                    )
                  : const Center(
                      child: Icon(Icons.videocam_off_rounded,
                          color: AppColors.muted, size: 30),
                    ),
            ),
          ),
        ),
      ),
    );
  }

  // ----------------------------- إشعار رسالة واردة -----------------------------
  Widget _toastBanner(EdgeInsets pad) {
    final msg = _toast!;
    return Positioned(
      top: pad.top + 64,
      left: 16,
      right: _pipW + 28,
      child: GestureDetector(
        onTap: _openChat,
        child: _GlassPill(
          radius: 18,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(
            children: [
              const Icon(Icons.chat_bubble_rounded,
                  color: AppColors.mint, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  msg.text,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ----------------------------- أزرار التحكم -----------------------------
  Widget _controls(EdgeInsets pad) {
    return Positioned(
      left: 16,
      right: 16,
      bottom: pad.bottom + 18,
      child: AnimatedSlide(
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOut,
        offset: _controlsVisible ? Offset.zero : const Offset(0, 1.6),
        child: _GlassPill(
          radius: 34,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _CtrlButton(
                icon: s.micOn ? Icons.mic_rounded : Icons.mic_off_rounded,
                label: s.micOn ? 'كتم' : 'مكتوم',
                active: s.micOn,
                onTap: s.toggleMic,
              ),
              _CtrlButton(
                icon: s.camOn
                    ? Icons.videocam_rounded
                    : Icons.videocam_off_rounded,
                label: 'الكاميرا',
                active: s.camOn,
                onTap: s.toggleCamera,
              ),
              _CtrlButton(
                icon: Icons.call_end_rounded,
                label: 'إنهاء',
                danger: true,
                onTap: _confirmEnd,
              ),
              _CtrlButton(
                icon: Icons.cameraswitch_rounded,
                label: 'تبديل',
                active: true,
                onTap: s.camOn ? s.switchCamera : null,
              ),
              _CtrlButton(
                icon: Icons.chat_rounded,
                label: 'دردشة',
                active: true,
                badge: s.unread,
                onTap: _openChat,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ----------------------------- فشل الاتصال -----------------------------
  Widget _failureOverlay() {
    return Positioned.fill(
      child: Container(
        color: Colors.black.withOpacity(0.7),
        padding: const EdgeInsets.all(28),
        alignment: Alignment.center,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: AppColors.stroke),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 70,
                height: 70,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.danger.withOpacity(0.15),
                ),
                child: const Icon(Icons.wifi_off_rounded,
                    color: AppColors.danger, size: 36),
              ),
              const SizedBox(height: 18),
              const Text('تعذّر إنشاء الاتصال المباشر',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              const Text(
                'قد تكون شبكة أحد الطرفين تمنع الاتصال المباشر (NAT صارم، '
                'شائع في بيانات الجوال). جرّب أن يكون الهاتفان على نفس شبكة Wi-Fi '
                'ثم أعد المحاولة.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, height: 1.6),
              ),
              const SizedBox(height: 22),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: FilledButton.icon(
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.mint,
                    foregroundColor: const Color(0xFF04121A),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: () => _end(notifyRemote: false),
                  icon: const Icon(Icons.home_rounded),
                  label: const Text('العودة للرئيسية',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _GlassPill extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius;
  const _GlassPill({
    required this.child,
    this.padding = const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
    this.radius = 30,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.32),
            borderRadius: BorderRadius.circular(radius),
            border: Border.all(color: Colors.white12),
          ),
          child: child,
        ),
      ),
    );
  }
}

class _CtrlButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final bool danger;
  final int badge;
  final VoidCallback? onTap;

  const _CtrlButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.active = false,
    this.danger = false,
    this.badge = 0,
  });

  @override
  Widget build(BuildContext context) {
    final double size = danger ? 62 : 52;
    final Color bg = danger
        ? AppColors.danger
        : active
            ? Colors.white.withOpacity(0.14)
            : Colors.white;
    final Color fg = danger
        ? Colors.white
        : active
            ? Colors.white
            : const Color(0xFF0B1222);

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: size,
              height: size,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: bg,
                boxShadow: danger
                    ? [
                        BoxShadow(
                          color: AppColors.danger.withOpacity(0.5),
                          blurRadius: 20,
                        )
                      ]
                    : null,
              ),
              child: Material(
                color: Colors.transparent,
                shape: const CircleBorder(),
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: onTap == null
                      ? null
                      : () {
                          HapticFeedback.lightImpact();
                          onTap!();
                        },
                  child: Icon(icon,
                      color: onTap == null ? fg.withOpacity(0.4) : fg,
                      size: danger ? 30 : 24),
                ),
              ),
            ),
            if (badge > 0)
              PositionedDirectional(
                top: -4,
                end: -4,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  constraints: const BoxConstraints(minWidth: 20),
                  decoration: BoxDecoration(
                    color: AppColors.mint,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    badge > 9 ? '9+' : '$badge',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF04121A)),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 6),
        Text(label,
            style: const TextStyle(fontSize: 11, color: Colors.white70)),
      ],
    );
  }
}
