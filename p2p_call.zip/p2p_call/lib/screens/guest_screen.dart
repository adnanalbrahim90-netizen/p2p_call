import 'package:flutter/material.dart';

import '../services/permissions.dart';
import '../services/signaling_codec.dart';
import '../services/webrtc_service.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'call_screen.dart';
import 'scanner_screen.dart';

enum _GuestStage { scan, preparing, ready, error }

/// مسار المنضم (Guest):
/// مسح QR 1 ← فك الضغط ← تشغيل الوسائط ← Answer ← انتظار ICE ← عرض QR 2
class GuestScreen extends StatefulWidget {
  const GuestScreen({super.key});

  @override
  State<GuestScreen> createState() => _GuestScreenState();
}

class _GuestScreenState extends State<GuestScreen> {
  WebRTCService _svc = WebRTCService(CallRole.guest);
  _GuestStage _stage = _GuestStage.scan;
  String? _code;
  String? _error;
  bool _permanentlyDenied = false;
  bool _handedOff = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _svc.addListener(_onServiceChanged);
    WidgetsBinding.instance.addPostFrameCallback((_) => _scan());
  }

  @override
  void dispose() {
    _svc.removeListener(_onServiceChanged);
    if (!_handedOff) _svc.dispose();
    super.dispose();
  }

  void _onServiceChanged() {
    if (!mounted || _handedOff) return;
    if (_stage == _GuestStage.ready && _svc.isFailed) {
      setState(() {
        _stage = _GuestStage.error;
        _error = 'تعذّر الوصول إلى المضيف عبر الشبكة.\n'
            'جرّب أن يكون الهاتفان على نفس شبكة Wi-Fi ثم أعد المحاولة.';
      });
      return;
    }
    if (_stage == _GuestStage.ready && _svc.isConnected) {
      _handedOff = true;
      _svc.removeListener(_onServiceChanged);
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => CallScreen(service: _svc)),
      );
    }
  }

  Future<bool> _ensurePermissions() async {
    final perm = await ensureCallPermissions();
    if (!mounted) return false;
    if (perm == PermissionResult.granted) return true;
    setState(() {
      _stage = _GuestStage.error;
      _permanentlyDenied = perm == PermissionResult.permanentlyDenied;
      _error = 'يلزم السماح بالكاميرا والميكروفون لإجراء المكالمة.';
    });
    return false;
  }

  Future<void> _scan() async {
    if (_busy) return;
    if (!await _ensurePermissions()) return;
    if (!mounted) return;
    final raw = await Navigator.of(context).push<String>(
      MaterialPageRoute(
        builder: (_) => const ScannerScreen(
          title: 'امسح رمز الدعوة',
          hint: 'امسح رمز الدعوة الظاهر على هاتف المضيف',
        ),
      ),
    );
    if (raw != null && mounted) await _process(raw);
  }

  Future<void> _paste() async {
    final text = await readClipboard();
    if (!mounted) return;
    if (text == null) {
      showSnack(context, 'الحافظة فارغة — انسخ رمز الدعوة أولاً', error: true);
      return;
    }
    if (!await _ensurePermissions()) return;
    await _process(text);
  }

  Future<void> _process(String raw) async {
    // 1) فك الضغط والتحقق قبل تشغيل أي شيء
    SignalPayload payload;
    try {
      payload = SignalingCodec.decode(raw);
      if (payload.type != SignalType.offer) {
        throw const FormatException(
            'هذا رمز رد وليس رمز دعوة. امسح الرمز الأول من هاتف المضيف.');
      }
    } on FormatException catch (e) {
      if (mounted) {
        setState(() => _stage = _GuestStage.scan);
        showSnack(context, e.message, error: true);
      }
      return;
    }

    // خدمة جديدة إن كانت السابقة قد استُخدمت
    if (_svc.isDisposed || _svc.mediaReady) {
      _svc.removeListener(_onServiceChanged);
      if (!_svc.isDisposed) _svc.dispose();
      _svc = WebRTCService(CallRole.guest)..addListener(_onServiceChanged);
    }

    _busy = true;
    setState(() {
      _stage = _GuestStage.preparing;
      _error = null;
    });

    try {
      await _svc.init();
      final code = await _svc.createAnswerCode(payload.sdp);
      if (!mounted) return;
      setState(() {
        _code = code;
        _stage = _GuestStage.ready;
      });
      _onServiceChanged();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _stage = _GuestStage.error;
        _permanentlyDenied = false;
        _error = 'تعذّر الانضمام.\n$e';
      });
    } finally {
      _busy = false;
    }
  }

  int get _stepIndex {
    switch (_stage) {
      case _GuestStage.scan:
      case _GuestStage.error:
        return 0;
      case _GuestStage.preparing:
        return 1;
      case _GuestStage.ready:
        return 2;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: const Text('الانضمام لمكالمة')),
      body: AppBackground(
        child: SafeArea(
          child: AnimatedBuilder(
            animation: _svc,
            builder: (context, _) => ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              children: [
                StepsBar(
                  steps: const ['امسح الدعوة', 'تجهيز الرد', 'اعرض الرد'],
                  current: _stepIndex,
                ),
                const SizedBox(height: 22),
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 350),
                  child: _buildStage(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStage() {
    switch (_stage) {
      case _GuestStage.scan:
        return GlassCard(
          key: const ValueKey('scan'),
          padding: const EdgeInsets.fromLTRB(20, 34, 20, 22),
          child: Column(
            children: [
              Container(
                width: 96,
                height: 96,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppColors.secondaryGradient,
                  boxShadow: [
                    BoxShadow(
                        color: AppColors.violet.withOpacity(0.45),
                        blurRadius: 30),
                  ],
                ),
                child: const Icon(Icons.qr_code_2_rounded,
                    size: 50, color: Colors.white),
              ),
              const SizedBox(height: 20),
              const Text('امسح رمز الدعوة',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              const Text(
                'اطلب من صديقك فتح "إنشاء غرفة اتصال" ثم امسح الرمز الظاهر عنده',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted, fontSize: 13.5, height: 1.6),
              ),
              const SizedBox(height: 24),
              GradientButton(
                label: 'فتح الكاميرا للمسح',
                icon: Icons.qr_code_scanner_rounded,
                gradient: AppColors.secondaryGradient,
                foreground: Colors.white,
                onPressed: _scan,
              ),
              const SizedBox(height: 10),
              GhostButton(
                label: 'لصق رمز الدعوة',
                icon: Icons.content_paste_rounded,
                onPressed: _paste,
              ),
            ],
          ),
        );

      case _GuestStage.preparing:
        return _preparingCard();
      case _GuestStage.error:
        return ErrorPanel(
          key: const ValueKey('err'),
          message: _error ?? 'حدث خطأ',
          onRetry: () => setState(() => _stage = _GuestStage.scan),
          onOpenSettings: _permanentlyDenied ? openSettings : null,
        );

      case _GuestStage.ready:
        return Column(
          key: const ValueKey('ready'),
          children: [
            Row(
              children: [
                SelfPreview(
                    renderer: _svc.localRenderer, visible: _svc.mediaReady),
                const SizedBox(width: 14),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('خطوة أخيرة!',
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                      SizedBox(height: 4),
                      Text('اجعل المضيف يضغط "مسح رد الطرف الآخر" ويمسح هذا الرمز',
                          style: TextStyle(
                              color: AppColors.muted, fontSize: 13, height: 1.5)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 22),
            QrCodeCard(
              data: _code!,
              caption: 'رمز الرد (2) — ستبدأ المكالمة تلقائياً بعد مسحه',
            ),
            const SizedBox(height: 22),
            GlassCard(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  const PulseDot(color: AppColors.violet),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _svc.connectionState == null
                          ? 'بانتظار أن يمسح المضيف الرمز…'
                          : 'جارٍ الاتصال بالمضيف…',
                      style: const TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            GhostButton(
              label: 'نسخ رمز الرد',
              icon: Icons.copy_rounded,
              onPressed: () => copyToClipboard(context, _code!),
            ),
          ],
        );
    }
  }

  Widget _preparingCard() {
        final status = !_svc.mediaReady
            ? 'جارٍ تشغيل الكاميرا والميكروفون…'
            : 'جارٍ تجهيز الرد وجمع مسارات الشبكة… ${_svc.candidateCount}';
        return GlassCard(
          key: const ValueKey('prep'),
          padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 20),
          child: Column(
            children: [
              SelfPreview(
                  renderer: _svc.localRenderer,
                  visible: _svc.mediaReady,
                  size: 110),
              const SizedBox(height: 26),
              const SizedBox(
                width: 30,
                height: 30,
                child: CircularProgressIndicator(
                    strokeWidth: 3, color: AppColors.violet),
              ),
              const SizedBox(height: 18),
              Text(status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 15, fontWeight: FontWeight.w600)),
            ],
          ),
        );
  }
}
