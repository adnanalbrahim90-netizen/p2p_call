import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../services/signaling_codec.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// شاشة مسح QR — تُرجع النص المقروء عبر Navigator.pop
class ScannerScreen extends StatefulWidget {
  final String title;
  final String hint;
  const ScannerScreen({super.key, required this.title, required this.hint});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen>
    with SingleTickerProviderStateMixin {
  final MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal,
    formats: const [BarcodeFormat.qrCode],
  );
  late final AnimationController _line = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 1800),
  )..repeat(reverse: true);

  bool _done = false;
  bool _torch = false;
  DateTime _lastWrongHint = DateTime.fromMillisecondsSinceEpoch(0);

  @override
  void dispose() {
    _line.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _finish(String value) {
    if (_done) return;
    _done = true;
    HapticFeedback.mediumImpact();
    Navigator.of(context).pop(value);
  }

  void _onDetect(BarcodeCapture capture) {
    if (_done) return;
    for (final barcode in capture.barcodes) {
      final value = barcode.rawValue;
      if (value == null) continue;
      if (SignalingCodec.looksLikeCode(value)) {
        _finish(value);
        return;
      }
    }
    final now = DateTime.now();
    if (now.difference(_lastWrongHint).inSeconds > 3) {
      _lastWrongHint = now;
      showSnack(context, 'هذا الرمز لا يخص التطبيق');
    }
  }

  Future<void> _paste() async {
    final text = await readClipboard();
    if (!mounted) return;
    if (text == null || !SignalingCodec.looksLikeCode(text)) {
      showSnack(context, 'لا يوجد رمز اتصال صالح في الحافظة', error: true);
      return;
    }
    _finish(text);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final side = constraints.maxWidth * 0.78;
          final window = Rect.fromCenter(
            center: Offset(constraints.maxWidth / 2, constraints.maxHeight * 0.44),
            width: side,
            height: side,
          );

          return Stack(
            children: [
              Positioned.fill(
                child: MobileScanner(
                  controller: _controller,
                  onDetect: _onDetect,
                ),
              ),
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(painter: _ScanOverlayPainter(window)),
                ),
              ),
              // خط المسح المتحرك
              AnimatedBuilder(
                animation: _line,
                builder: (context, _) => Positioned(
                  left: window.left + 18,
                  width: window.width - 36,
                  top: window.top + 14 + (window.height - 28) * _line.value,
                  child: Container(
                    height: 2.5,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(2),
                      gradient: LinearGradient(colors: [
                        AppColors.mint.withOpacity(0),
                        AppColors.mint,
                        AppColors.mint.withOpacity(0),
                      ]),
                      boxShadow: [
                        BoxShadow(
                            color: AppColors.mint.withOpacity(0.6),
                            blurRadius: 12),
                      ],
                    ),
                  ),
                ),
              ),
              // الشريط العلوي
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    children: [
                      _RoundIcon(
                        icon: Icons.close_rounded,
                        onTap: () => Navigator.of(context).pop(),
                      ),
                      Expanded(
                        child: Text(
                          widget.title,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800),
                        ),
                      ),
                      _RoundIcon(
                        icon: _torch
                            ? Icons.flash_on_rounded
                            : Icons.flash_off_rounded,
                        active: _torch,
                        onTap: () async {
                          await _controller.toggleTorch();
                          if (mounted) setState(() => _torch = !_torch);
                        },
                      ),
                    ],
                  ),
                ),
              ),
              // التلميح والأزرار السفلية
              Positioned(
                left: 24,
                right: 24,
                top: window.bottom + 28,
                child: Column(
                  children: [
                    Text(
                      widget.hint,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 14.5, height: 1.6),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'قرّب الهاتف حتى يملأ الرمز الإطار، وارفع سطوع الشاشة الأخرى',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: AppColors.muted.withOpacity(0.9), fontSize: 12),
                    ),
                    const SizedBox(height: 18),
                    GhostButton(
                      label: 'لصق الرمز من الحافظة',
                      icon: Icons.content_paste_rounded,
                      onPressed: _paste,
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _RoundIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool active;
  const _RoundIcon({required this.icon, required this.onTap, this.active = false});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? AppColors.mint : Colors.black45,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(11),
          child: Icon(icon,
              color: active ? const Color(0xFF04121A) : Colors.white, size: 22),
        ),
      ),
    );
  }
}

class _ScanOverlayPainter extends CustomPainter {
  final Rect window;
  _ScanOverlayPainter(this.window);

  @override
  void paint(Canvas canvas, Size size) {
    final rrect = RRect.fromRectAndRadius(window, const Radius.circular(28));
    final background = Path()..addRect(Offset.zero & size);
    final hole = Path()..addRRect(rrect);
    canvas.drawPath(
      Path.combine(PathOperation.difference, background, hole),
      Paint()..color = Colors.black.withOpacity(0.62),
    );

    final corner = Paint()
      ..color = AppColors.mint
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    const len = 34.0;
    const r = 28.0;
    final l = window.left, t = window.top, rt = window.right, b = window.bottom;

    // أعلى يسار
    canvas.drawPath(
        Path()
          ..moveTo(l, t + r + len)
          ..lineTo(l, t + r)
          ..arcToPoint(Offset(l + r, t), radius: const Radius.circular(r))
          ..lineTo(l + r + len, t),
        corner);
    // أعلى يمين
    canvas.drawPath(
        Path()
          ..moveTo(rt - r - len, t)
          ..lineTo(rt - r, t)
          ..arcToPoint(Offset(rt, t + r), radius: const Radius.circular(r))
          ..lineTo(rt, t + r + len),
        corner);
    // أسفل يمين
    canvas.drawPath(
        Path()
          ..moveTo(rt, b - r - len)
          ..lineTo(rt, b - r)
          ..arcToPoint(Offset(rt - r, b), radius: const Radius.circular(r))
          ..lineTo(rt - r - len, b),
        corner);
    // أسفل يسار
    canvas.drawPath(
        Path()
          ..moveTo(l + r + len, b)
          ..lineTo(l + r, b)
          ..arcToPoint(Offset(l, b - r), radius: const Radius.circular(r))
          ..lineTo(l, b - r - len),
        corner);
  }

  @override
  bool shouldRepaint(covariant _ScanOverlayPainter old) => old.window != window;
}
