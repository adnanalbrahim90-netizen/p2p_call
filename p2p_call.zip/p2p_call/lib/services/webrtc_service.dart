import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import 'signaling_codec.dart';

enum CallRole { host, guest }

class ChatMessage {
  final String text;
  final bool mine;
  final DateTime time;
  ChatMessage({required this.text, required this.mine, DateTime? time})
      : time = time ?? DateTime.now();
}

/// يدير كل ما يخص WebRTC: الوسائط، الاتصال، قناة البيانات، وأدوات التحكم.
class WebRTCService extends ChangeNotifier {
  WebRTCService(this.role);

  final CallRole role;

  static const Map<String, dynamic> _rtcConfig = {
    'iceServers': [
      {'urls': 'stun:stun.l.google.com:19302'},
    ],
    'sdpSemantics': 'unified-plan',
  };

  static const Map<String, dynamic> _videoConstraints = {
    'facingMode': 'user',
    'width': 640,
    'height': 480,
    'frameRate': 24,
  };

  /// أقصى مدة لانتظار اكتمال جمع مسارات ICE
  static const Duration _gatherTimeout = Duration(seconds: 8);

  final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer remoteRenderer = RTCVideoRenderer();

  MediaStream? _localStream;
  MediaStream? _remoteFallbackStream;
  RTCPeerConnection? _pc;
  RTCDataChannel? _dc;
  RTCRtpSender? _videoSender;
  Completer<void>? _gatherCompleter;

  bool _initialized = false;
  bool _disposed = false;
  bool _cameraReleased = false;

  // ---- حالة عامة تقرأها الواجهة ----
  bool mediaReady = false;
  bool micOn = true;
  bool camOn = true;
  bool speakerOn = true;
  bool frontCamera = true;
  bool remoteCamOn = true;
  bool hasRemoteVideo = false;
  bool chatReady = false;
  bool remoteHungUp = false;
  bool answerApplied = false;
  bool chatOpen = false;
  int unread = 0;
  int candidateCount = 0;
  RTCPeerConnectionState? connectionState;
  RTCIceConnectionState? iceState;
  final List<ChatMessage> messages = [];

  /// يُستدعى عند وصول رسالة نصية جديدة (لإظهار إشعار داخل المكالمة)
  void Function(ChatMessage message)? onIncomingMessage;

  bool get isDisposed => _disposed;

  bool get isConnected =>
      connectionState == RTCPeerConnectionState.RTCPeerConnectionStateConnected ||
      (connectionState == null &&
          (iceState == RTCIceConnectionState.RTCIceConnectionStateConnected ||
              iceState == RTCIceConnectionState.RTCIceConnectionStateCompleted));

  bool get isFailed =>
      connectionState == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
      iceState == RTCIceConnectionState.RTCIceConnectionStateFailed;

  bool get isReconnecting =>
      connectionState == RTCPeerConnectionState.RTCPeerConnectionStateDisconnected;

  // ===========================================================================
  // التهيئة: الكاميرا + الميكروفون + PeerConnection (+ DataChannel للمضيف)
  // ===========================================================================
  Future<void> init() async {
    if (_initialized || _disposed) return;

    await localRenderer.initialize();
    await remoteRenderer.initialize();
    if (_disposed) return;

    _localStream = await navigator.mediaDevices.getUserMedia({
      'audio': true,
      'video': _videoConstraints,
    });
    if (_disposed) {
      _stopLocalTracks();
      return;
    }
    localRenderer.srcObject = _localStream;
    mediaReady = true;
    notifyListeners();

    final pc = await createPeerConnection(_rtcConfig);
    _pc = pc;
    _registerPeerCallbacks(pc);

    for (final track in _localStream!.getTracks()) {
      final sender = await pc.addTrack(track, _localStream!);
      if (track.kind == 'video') _videoSender = sender;
    }

    if (role == CallRole.host) {
      final init = RTCDataChannelInit()..ordered = true;
      final dc = await pc.createDataChannel('chat', init);
      _bindDataChannel(dc);
    }

    _initialized = true;
    notifyListeners();
  }

  void _registerPeerCallbacks(RTCPeerConnection pc) {
    pc.onIceCandidate = (RTCIceCandidate candidate) {
      candidateCount++;
      notifyListeners();
    };

    pc.onIceGatheringState = (RTCIceGatheringState state) {
      if (state == RTCIceGatheringState.RTCIceGatheringStateComplete) {
        final c = _gatherCompleter;
        if (c != null && !c.isCompleted) c.complete();
      }
    };

    pc.onConnectionState = (RTCPeerConnectionState state) {
      connectionState = state;
      if (state == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        _safe(() => Helper.setSpeakerphoneOn(speakerOn));
      }
      notifyListeners();
    };

    pc.onIceConnectionState = (RTCIceConnectionState state) {
      iceState = state;
      notifyListeners();
    };

    pc.onTrack = (RTCTrackEvent event) async {
      if (event.track.kind != 'video') return;
      if (event.streams.isNotEmpty) {
        remoteRenderer.srcObject = event.streams.first;
      } else {
        _remoteFallbackStream ??= await createLocalMediaStream('remote');
        await _remoteFallbackStream!.addTrack(event.track);
        remoteRenderer.srcObject = _remoteFallbackStream;
      }
      hasRemoteVideo = true;
      notifyListeners();
    };

    pc.onDataChannel = (RTCDataChannel channel) => _bindDataChannel(channel);
  }

  // ===========================================================================
  // Signaling يدوي (بدون Trickle ICE)
  // ===========================================================================

  /// المضيف: إنشاء Offer وانتظار اكتمال ICE ثم إرجاع الرمز المضغوط.
  Future<String> createOfferCode() async {
    final pc = _requirePc();
    final offer = await pc.createOffer({});
    final local = await _setLocalAndGather(offer);
    return SignalingCodec.encode(SignalType.offer, local.sdp!);
  }

  /// الضيف: ضبط Offer البعيد، إنشاء Answer وانتظار ICE ثم إرجاع الرمز.
  Future<String> createAnswerCode(String offerSdp) async {
    final pc = _requirePc();
    await pc.setRemoteDescription(RTCSessionDescription(offerSdp, 'offer'));
    final answer = await pc.createAnswer({});
    final local = await _setLocalAndGather(answer);
    return SignalingCodec.encode(SignalType.answer, local.sdp!);
  }

  /// المضيف: تطبيق رمز الرد القادم من الضيف — يبدأ الاتصال فوراً.
  Future<void> applyAnswerCode(String code) async {
    if (answerApplied) return;
    final payload = SignalingCodec.decode(code);
    if (payload.type != SignalType.answer) {
      throw const FormatException(
          'هذا رمز الدعوة نفسه! امسح رمز الرد الظاهر على هاتف صديقك.');
    }
    await _requirePc()
        .setRemoteDescription(RTCSessionDescription(payload.sdp, 'answer'));
    answerApplied = true;
    notifyListeners();
  }

  Future<RTCSessionDescription> _setLocalAndGather(
      RTCSessionDescription description) async {
    final pc = _requirePc();
    _gatherCompleter = Completer<void>();
    candidateCount = 0;
    await pc.setLocalDescription(description);
    // انتظار RTCIceGatheringStateComplete (مع مهلة احتياطية)
    await _gatherCompleter!.future.timeout(_gatherTimeout, onTimeout: () {});
    final local = await pc.getLocalDescription();
    return local ?? description;
  }

  RTCPeerConnection _requirePc() {
    final pc = _pc;
    if (pc == null) throw StateError('الاتصال غير مُهيّأ');
    return pc;
  }

  // ===========================================================================
  // تحرير الكاميرا مؤقتاً (للمضيف أثناء مسح رمز الرد) ثم استعادتها
  // ===========================================================================
  Future<void> releaseCamera() async {
    final stream = _localStream;
    if (stream == null || _cameraReleased) return;
    for (final t in stream.getVideoTracks().toList()) {
      await t.stop();
      await stream.removeTrack(t);
    }
    _cameraReleased = true;
    notifyListeners();
  }

  Future<void> reacquireCamera() async {
    final stream = _localStream;
    if (stream == null || !_cameraReleased || _disposed) return;
    try {
      final fresh = await navigator.mediaDevices.getUserMedia({
        'audio': false,
        'video': _videoConstraints,
      });
      final track = fresh.getVideoTracks().first;
      track.enabled = camOn;
      await stream.addTrack(track);
      await _videoSender?.replaceTrack(track);
      localRenderer.srcObject = stream;
      frontCamera = true;
      _cameraReleased = false;
      notifyListeners();
    } catch (e) {
      debugPrint('reacquireCamera failed: $e');
    }
  }

  // ===========================================================================
  // قناة البيانات (الدردشة + رسائل التحكم)
  // ===========================================================================
  void _bindDataChannel(RTCDataChannel channel) {
    _dc = channel;
    chatReady = channel.state == RTCDataChannelState.RTCDataChannelOpen;

    channel.onDataChannelState = (RTCDataChannelState state) {
      chatReady = state == RTCDataChannelState.RTCDataChannelOpen;
      if (chatReady) _sendRaw({'type': 'cam', 'on': camOn});
      notifyListeners();
    };

    channel.onMessage = (RTCDataChannelMessage message) {
      if (message.isBinary) return;
      _handleIncoming(message.text);
    };

    if (chatReady) _sendRaw({'type': 'cam', 'on': camOn});
    notifyListeners();
  }

  void _handleIncoming(String text) {
    Map<String, dynamic> data;
    try {
      data = jsonDecode(text) as Map<String, dynamic>;
    } catch (_) {
      data = {'type': 'chat', 'text': text};
    }

    final type = data['type'];
    if (type == 'chat') {
      final msg = ChatMessage(text: '${data['text'] ?? ''}', mine: false);
      messages.add(msg);
      if (!chatOpen) unread++;
      onIncomingMessage?.call(msg);
    } else if (type == 'cam') {
      remoteCamOn = data['on'] == true;
    } else if (type == 'bye') {
      remoteHungUp = true;
    }
    notifyListeners();
  }

  Future<bool> sendChat(String text) async {
    final t = text.trim();
    if (t.isEmpty) return false;
    final ok = await _sendRaw({'type': 'chat', 'text': t});
    if (ok) {
      messages.add(ChatMessage(text: t, mine: true));
      notifyListeners();
    }
    return ok;
  }

  Future<bool> _sendRaw(Map<String, dynamic> data) async {
    final dc = _dc;
    if (dc == null || dc.state != RTCDataChannelState.RTCDataChannelOpen) {
      return false;
    }
    try {
      await dc.send(RTCDataChannelMessage(jsonEncode(data)));
      return true;
    } catch (e) {
      debugPrint('DataChannel send failed: $e');
      return false;
    }
  }

  void openChat() {
    chatOpen = true;
    unread = 0;
    notifyListeners();
  }

  void closeChat() {
    chatOpen = false;
    notifyListeners();
  }

  // ===========================================================================
  // أدوات التحكم
  // ===========================================================================
  void toggleMic() {
    micOn = !micOn;
    for (final t in _localStream?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = micOn;
    }
    notifyListeners();
  }

  void toggleCamera() {
    camOn = !camOn;
    for (final t in _localStream?.getVideoTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = camOn;
    }
    _sendRaw({'type': 'cam', 'on': camOn});
    notifyListeners();
  }

  Future<void> switchCamera() async {
    final tracks = _localStream?.getVideoTracks() ?? const <MediaStreamTrack>[];
    if (tracks.isEmpty) return;
    await _safe(() => Helper.switchCamera(tracks.first));
    frontCamera = !frontCamera;
    notifyListeners();
  }

  Future<void> toggleSpeaker() async {
    speakerOn = !speakerOn;
    await _safe(() => Helper.setSpeakerphoneOn(speakerOn));
    notifyListeners();
  }

  /// إنهاء المكالمة (مع إبلاغ الطرف الآخر) ثم تحرير كل الموارد.
  Future<void> hangUp({bool notifyRemote = true}) async {
    if (_disposed) return;
    if (notifyRemote) {
      await _sendRaw({'type': 'bye'});
      await Future<void>.delayed(const Duration(milliseconds: 200));
    }
    dispose();
  }

  Future<void> _safe(Future<dynamic> Function() action) async {
    try {
      await action();
    } catch (e) {
      debugPrint('WebRTC helper error: $e');
    }
  }

  void _stopLocalTracks() {
    for (final t in _localStream?.getTracks() ?? const <MediaStreamTrack>[]) {
      try {
        t.stop();
      } catch (_) {}
    }
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    onIncomingMessage = null;

    _stopLocalTracks();
    try {
      _localStream?.dispose();
    } catch (_) {}
    try {
      _dc?.close();
    } catch (_) {}
    try {
      _pc?.close();
    } catch (_) {}
    try {
      localRenderer.srcObject = null;
      remoteRenderer.srcObject = null;
      localRenderer.dispose();
      remoteRenderer.dispose();
    } catch (_) {}

    _dc = null;
    _pc = null;
    _localStream = null;
    super.dispose();
  }
}
