import 'dart:convert';
import 'dart:io';

/// نوع رسالة التعارف (Signaling)
enum SignalType { offer, answer }

class SignalPayload {
  final SignalType type;
  final String sdp;
  const SignalPayload(this.type, this.sdp);
}

/// تحويل نص الـ SDP إلى رمز قصير يصلح لـ QR Code والعكس.
///
/// الخطوات: تنحيف SDP (حذف الكوديكات غير المستخدمة ومسارات TCP)
/// ← GZip ← Base64 ← إضافة بادئة للتعرّف على الرمز.
class SignalingCodec {
  static const String prefix = 'P2P1:';

  static bool looksLikeCode(String text) =>
      text.replaceAll(RegExp(r'\s+'), '').startsWith(prefix);

  static String encode(SignalType type, String sdp) {
    final compact = compactSdp(sdp);
    final raw = '${type.name}\n$compact';
    final zipped = GZipCodec(level: 9).encode(utf8.encode(raw));
    return '$prefix${base64Encode(zipped)}';
  }

  static SignalPayload decode(String input) {
    var text = input.replaceAll(RegExp(r'\s+'), '');
    if (!text.startsWith(prefix)) {
      throw const FormatException('هذا ليس رمز اتصال صالحاً من هذا التطبيق.');
    }
    text = text.substring(prefix.length);
    final raw = _unzip(text);

    final nl = raw.indexOf('\n');
    if (nl <= 0) {
      throw const FormatException('الرمز ناقص أو تالف.');
    }
    final typeName = raw.substring(0, nl).trim();
    final sdp = raw.substring(nl + 1);

    SignalType? type;
    for (final t in SignalType.values) {
      if (t.name == typeName) type = t;
    }
    if (type == null || !sdp.startsWith('v=0')) {
      throw const FormatException('الرمز ناقص أو تالف.');
    }
    return SignalPayload(type, sdp);
  }

  static String _unzip(String b64) {
    try {
      return utf8.decode(GZipCodec().decode(base64Decode(b64)));
    } catch (_) {
      throw const FormatException('تعذّر فك الرمز — ربما لم يُنسخ أو يُمسح بالكامل.');
    }
  }

  // ---------------------------------------------------------------------------
  // تنحيف SDP لتصغير حجم الـ QR:
  //  • الصوت: إبقاء Opus فقط.
  //  • الفيديو: إبقاء VP8 (+ RTX الخاص به) فقط.
  //  • حذف مسارات ICE من نوع TCP (لا فائدة منها بدون TURN).
  // يُطبّق على النص المُرسل فقط، لا على الوصف المحلي، لذلك هو آمن.
  // ---------------------------------------------------------------------------
  static String compactSdp(String sdp) {
    final lines =
        sdp.split(RegExp(r'\r?\n')).where((l) => l.trim().isNotEmpty).toList();
    final out = <String>[];
    var section = <String>[];

    void flush() {
      if (section.isEmpty) return;
      out.addAll(_filterSection(section));
      section = <String>[];
    }

    for (final line in lines) {
      if (line.startsWith('m=')) flush();
      section.add(line);
    }
    flush();
    return '${out.join('\r\n')}\r\n';
  }

  static List<String> _filterSection(List<String> sec) {
    final first = sec.first;
    if (!first.startsWith('m=')) return sec; // جزء الجلسة العام

    final noTcp = sec
        .where((l) => !(l.startsWith('a=candidate') && l.contains(' tcp ')))
        .toList();

    String? target;
    if (first.startsWith('m=audio')) target = 'opus';
    if (first.startsWith('m=video')) target = 'vp8';
    if (target == null) return noTcp; // m=application (DataChannel)

    final rtpmap = RegExp(r'^a=rtpmap:(\d+) ([^/]+)/');
    final keep = <String>{};
    for (final l in noTcp) {
      final m = rtpmap.firstMatch(l);
      if (m != null && m.group(2)!.toLowerCase() == target) keep.add(m.group(1)!);
    }
    if (keep.isEmpty) return noTcp; // لم نجد الكوديك — نترك القسم كما هو

    // RTX المرتبط بـ VP8
    final apt = RegExp(r'^a=fmtp:(\d+) apt=(\d+)');
    final rtx = <String>{};
    for (final l in noTcp) {
      final m = apt.firstMatch(l);
      if (m != null && keep.contains(m.group(2))) rtx.add(m.group(1)!);
    }
    keep.addAll(rtx);

    final parts = first.split(' ');
    if (parts.length < 4) return noTcp;
    final header = parts.take(3).toList();
    final payloads = parts.skip(3).where(keep.contains).toList();
    final result = <String>[[...header, ...payloads].join(' ')];

    final ptLine = RegExp(r'^a=(rtpmap|rtcp-fb|fmtp):(\d+) ');
    for (final l in noTcp.skip(1)) {
      final m = ptLine.firstMatch(l);
      if (m != null && !keep.contains(m.group(2))) continue;
      result.add(l);
    }
    return result;
  }
}
