import 'package:permission_handler/permission_handler.dart';

enum PermissionResult { granted, denied, permanentlyDenied }

/// طلب أذونات الكاميرا والميكروفون معاً.
Future<PermissionResult> ensureCallPermissions() async {
  final statuses = await [Permission.camera, Permission.microphone].request();
  if (statuses.values.every((s) => s.isGranted)) return PermissionResult.granted;
  if (statuses.values.any((s) => s.isPermanentlyDenied)) {
    return PermissionResult.permanentlyDenied;
  }
  return PermissionResult.denied;
}

Future<void> openSettings() => openAppSettings();
