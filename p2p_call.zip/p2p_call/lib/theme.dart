import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF070B14);
  static const surface = Color(0xFF101726);
  static const surface2 = Color(0xFF18213A);
  static const stroke = Color(0x1FFFFFFF);
  static const mint = Color(0xFF2EE6A8);
  static const violet = Color(0xFF7B61FF);
  static const sky = Color(0xFF38BDF8);
  static const danger = Color(0xFFFF4D67);
  static const warning = Color(0xFFFFC14D);
  static const text = Colors.white;
  static const muted = Color(0xFF93A1B8);

  static const primaryGradient = LinearGradient(
    colors: [mint, sky],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const secondaryGradient = LinearGradient(
    colors: [violet, Color(0xFFB45CFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

ThemeData buildAppTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: AppColors.mint,
    brightness: Brightness.dark,
  ).copyWith(
    primary: AppColors.mint,
    secondary: AppColors.violet,
    surface: AppColors.surface,
    error: AppColors.danger,
  );

  return ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: scheme,
    scaffoldBackgroundColor: AppColors.bg,
    appBarTheme: const AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      foregroundColor: Colors.white,
      titleTextStyle: TextStyle(
          fontSize: 18, fontWeight: FontWeight.w700, color: Colors.white),
    ),
    snackBarTheme: const SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: AppColors.surface2,
      contentTextStyle: TextStyle(color: Colors.white, fontSize: 14),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(14))),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: Colors.transparent,
      elevation: 0,
    ),
  );
}
