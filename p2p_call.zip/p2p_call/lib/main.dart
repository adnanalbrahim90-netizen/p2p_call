import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'app/controller.dart';
import 'app/theme.dart';
import 'net/calls.dart';
import 'ui/screens/call_screen.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/lock_screen.dart';
import 'ui/screens/onboarding_screen.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> messengerKey = GlobalKey<ScaffoldMessengerState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarContrastEnforced: false,
  ));
  final controller = await AppController.boot();
  runApp(IttisalApp(controller: controller));
}

class IttisalApp extends StatefulWidget {
  const IttisalApp({super.key, required this.controller});
  final AppController controller;

  @override
  State<IttisalApp> createState() => _IttisalAppState();
}

class _IttisalAppState extends State<IttisalApp> {
  AppController get c => widget.controller;
  CallManager? _wiredCalls;

  @override
  void initState() {
    super.initState();
    c.addListener(_wire);
    c.toast.addListener(_onToast);
    _wire();
  }

  @override
  void dispose() {
    c.removeListener(_wire);
    c.toast.removeListener(_onToast);
    super.dispose();
  }

  /// ربط شاشة المكالمة بمدير المكالمات (بعد إنشاء الهوية أيضاً)
  void _wire() {
    final calls = c.calls;
    if (calls == null || calls == _wiredCalls) return;
    _wiredCalls = calls;
    calls.onShowCall = (session) {
      navigatorKey.currentState?.push(CallScreen.route(session));
    };
  }

  void _onToast() {
    final msg = c.toast.value;
    if (msg == null) return;
    c.toast.value = null;
    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(msg),
        duration: const Duration(seconds: 2),
      ));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => MaterialApp(
        title: 'اتصال مباشر',
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        scaffoldMessengerKey: messengerKey,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: ThemeMode.system,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: c.ready ? const HomeScreen() : const OnboardingScreen(),
        builder: (context, child) {
          return Stack(
            children: [
              child ?? const SizedBox.shrink(),
              if (c.ready && c.locked) const Positioned.fill(child: LockScreen()),
            ],
          );
        },
      ),
    );
  }
}
