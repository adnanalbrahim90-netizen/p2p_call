import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'screens/home_screen.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle.light.copyWith(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: AppColors.bg,
    ),
  );
  runApp(const P2PCallApp());
}

class P2PCallApp extends StatelessWidget {
  const P2PCallApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'اتصال مباشر',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      // واجهة عربية من اليمين لليسار
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const HomeScreen(),
    );
  }
}
