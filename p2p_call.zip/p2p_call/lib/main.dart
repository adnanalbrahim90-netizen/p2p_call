import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'app/controller.dart';
import 'app/theme.dart';
import 'core/models.dart';
import 'ui/screens/call_screen.dart';
import 'ui/screens/chat_screen.dart';
import 'ui/screens/group_call_screen.dart';
import 'ui/screens/home_screen.dart';
import 'ui/screens/lock_screen.dart';
import 'ui/screens/onboarding_screen.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> messengerKey = GlobalKey<ScaffoldMessengerState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // ملاحظة: قد يعمل هذا الكود بدون شاشة (من خدمة الخلفية) ثم تُربط الشاشة لاحقاً،
  // لذلك إعدادات واجهة النظام تُطبّق عند ظهور التطبيق فقط.
  final controller = await AppController.boot();
  runApp(IttisalApp(controller: controller));
}

/// واجهة النظام: من حافة لحافة وأشرطة شفافة
Future<void> applySystemUi() async {
  try {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarContrastEnforced: false,
    ));
  } catch (_) {}
}

class IttisalApp extends StatefulWidget {
  const IttisalApp({super.key, required this.controller});
  final AppController controller;

  @override
  State<IttisalApp> createState() => _IttisalAppState();
}

class _IttisalAppState extends State<IttisalApp> with WidgetsBindingObserver {
  AppController get c => widget.controller;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) applySystemUi();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (c.foreground) applySystemUi();
    c.showCall = (s) => navigatorKey.currentState?.push(CallScreen.route(s));
    c.showGroupCall = (s) => navigatorKey.currentState?.push(GroupCallScreen.route(s));
    c.toast.addListener(_onToast);
    c.openChatRequest.addListener(_onOpenChat);
    // طلب فتح محادثة وصل قبل بناء الواجهة
    WidgetsBinding.instance.addPostFrameCallback((_) => _onOpenChat());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    c.toast.removeListener(_onToast);
    c.openChatRequest.removeListener(_onOpenChat);
    super.dispose();
  }

  void _onToast() {
    final msg = c.toast.value;
    if (msg == null) return;
    c.toast.value = null;
    messengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }

  /// فتح محادثة عند الضغط على إشعارها
  void _onOpenChat() {
    final chatId = c.openChatRequest.value;
    final nav = navigatorKey.currentState;
    if (chatId == null || nav == null || !c.ready) return;
    c.openChatRequest.value = null;
    final exists = isGroupChat(chatId)
        ? c.store.group(groupIdOf(chatId)) != null
        : c.store.contact(chatId) != null;
    if (!exists || c.inCall) return;
    nav.popUntil((r) => r.isFirst);
    nav.push(ChatScreen.route(chatId));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => MaterialApp(
        title: 'اتصال مباشر',
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        scaffoldMessengerKey: messengerKey,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        themeMode: ThemeMode.system,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: c.ready ? const HomeScreen() : const OnboardingScreen(),
        builder: (context, child) {
          return Stack(
            children: [
              child ?? const SizedBox.shrink(),
              // القفل لا يمنع الرد على المكالمات؛ يعود بعد انتهائها
              if (c.ready)
                ListenableBuilder(
                  listenable: Listenable.merge([c, c.calls, c.groupCalls]),
                  builder: (context, _) => c.locked && !c.inCall
                      ? const Positioned.fill(child: LockScreen())
                      : const SizedBox.shrink(),
                ),
            ],
          );
        },
      ),
    );
  }
}
