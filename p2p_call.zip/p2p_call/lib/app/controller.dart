import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:local_auth/local_auth.dart';
import 'package:permission_handler/permission_handler.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import '../net/calls.dart';
import '../net/group_calls.dart';
import '../net/groups.dart';
import '../net/link.dart';
import '../net/native.dart';
import '../net/relay.dart';
import '../net/rtc.dart';

/// نقطة التحكم المركزية في التطبيق
class AppController extends ChangeNotifier with WidgetsBindingObserver {
  AppController._(this.store);

  static late AppController I;

  final Store store;
  Identity? identity;
  Relay? relay;
  LinkManager? links;
  CallManager? calls;
  GroupService? groups;
  GroupCallManager? groupCalls;

  final LocalAuthentication _auth = LocalAuthentication();
  bool biometricSupported = false;
  bool _biometricChecked = false;
  bool locked = false;
  bool _authInProgress = false;
  DateTime? _pausedAt;
  DateTime? _suppressLockUntil;
  DateTime? _graceUntil;
  final Map<String, DateTime> _helloSent = {};
  Timer? _heartbeat;
  StreamSubscription<RelayMessage>? _relaySub;
  StreamSubscription<String>? _presenceSub;

  /// التطبيق ظاهر على الشاشة الآن
  bool foreground = false;

  /// تنبيهات داخل التطبيق (رسالة جديدة / طلب إضافة)
  final ValueNotifier<String?> toast = ValueNotifier<String?>(null);

  /// طلب فتح محادثة (من إشعار)
  final ValueNotifier<String?> openChatRequest = ValueNotifier<String?>(null);

  /// عرض شاشة مكالمة (فردية أو جماعية) — تربطها الواجهة
  void Function(CallSession s)? showCall;
  void Function(GroupCallSession s)? showGroupCall;

  bool get ready => identity != null;

  /// توجد مكالمة جارية أو واردة (فردية أو جماعية)
  bool get inCall => (calls?.busy ?? false) || (groupCalls?.busy ?? false);

  static Future<AppController> boot() async {
    final store = await Store.open();
    final c = AppController._(store);
    I = c;
    c._applyIce();
    WidgetsBinding.instance.addObserver(c);
    c.foreground = WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed;
    final j = store.identityJson;
    if (j != null) {
      try {
        c.identity = await Identity.fromJson(j);
      } catch (_) {
        c.identity = null;
      }
    }
    if (c.identity != null) {
      store.selfId = c.identity!.id;
      // يُقفل دائماً عند التشغيل إن كان القفل مفعلاً (نتحقق من دعم البصمة عند الظهور)
      c.locked = store.settings.lockEnabled;
      c._startNetwork();
    }
    NativeBridge.listen(c._onNativeAction);
    return c;
  }

  /// دعم البصمة لا يُعرف إلا بعد ظهور الشاشة
  Future<void> refreshBiometric() async {
    // بدون شاشة ظاهرة يعيد النظام دائماً "غير مدعوم" — لا نعتمد على النتيجة
    if (!foreground) return;
    try {
      biometricSupported = await _auth.isDeviceSupported();
      _biometricChecked = true;
    } catch (_) {
      biometricSupported = false;
    }
    if (_biometricChecked && !biometricSupported && locked) {
      locked = false;
    }
    notifyListeners();
  }

  // ------------------------------------------------------------------ الإعداد الأول
  Future<void> createIdentity(String name, {required bool lock}) async {
    final id = await Identity.generate(name.trim());
    await store.saveIdentity(id.toJson());
    store.selfId = id.id;
    store.settings.lockEnabled = lock && biometricSupported;
    store.saveSettings();
    identity = id;
    _startNetwork();
    notifyListeners();
  }

  void _startNetwork() {
    final id = identity!;
    final r = Relay(id, Cipher(id));
    final l = LinkManager(id, store, r);
    final c = CallManager(id, store, r);
    final gs = GroupService(id, store, l, r);
    final gc = GroupCallManager(id, store, r);
    relay = r;
    links = l;
    calls = c;
    groups = gs;
    groupCalls = gc;

    c.otherBusy = () => gc.busy;
    gc.otherBusy = () => c.busy;
    c.onShowCall = _onShowCall;
    gc.onShow = _onShowGroupCall;
    l.onGroupControl = gs.onControl;
    l.onIncoming = _onIncomingMessage;
    l.onLinked = (pid) {
      final contact = store.contact(pid);
      if (contact != null && !contact.confirmed) {
        contact.confirmed = true;
        store.updateContact(contact);
      }
    };
    gs.onNotice = (msg) {
      if (foreground) {
        toast.value = msg;
      } else {
        NativeBridge.notifyInfo('قروب جديد', msg);
      }
    };

    for (final pid in store.allPeerIds) {
      r.watch(pid);
    }
    _relaySub = r.messages.listen(_onRelay);
    _presenceSub = r.presenceChanges.listen((pid) => l.onPresence(pid));
    r.start();
    Timer(const Duration(seconds: 5), _resendHellos);
    _heartbeat = Timer.periodic(const Duration(seconds: 30), (_) {
      r.kick();
      l.retryAll();
      _resendHellos();
    });
    if (store.settings.background) NativeBridge.setBackground(true);
  }

  void _onRelay(RelayMessage m) {
    final t = m.type;
    if (t == 'hello') {
      _onHello(m);
    } else if (t == 'hello_ack') {
      final c = store.contact(m.senderId);
      if (c == null) return;
      final name = (m.data['name'] as String?)?.trim();
      if (name != null && name.isNotEmpty) c.name = name;
      c.confirmed = true;
      store.updateContact(c);
      links?.onPresence(c.id);
    } else if (t == 'link_offer' || t == 'link_answer') {
      links?.onRelay(m);
    } else if (t.startsWith('call_')) {
      calls?.onRelay(m);
    } else if (t.startsWith('gc_')) {
      groupCalls?.onRelay(m);
    }
  }

  void _onHello(RelayMessage m) {
    final name = ((m.data['name'] as String?) ?? '').trim();
    final existing = store.contact(m.senderId);
    if (existing != null) {
      if (name.isNotEmpty) existing.name = name;
      existing.confirmed = true;
      store.updateContact(existing);
      relay?.send(existing.publicKey, {'t': 'hello_ack', 'name': identity!.name});
      return;
    }
    if (store.ignored.contains(m.senderId)) return;
    final already = store.requests.any((r) => r.id == m.senderId);
    store.addRequest(ContactRequest(id: m.senderId, publicKey: m.senderKey, name: name));
    if (!already) {
      final who = name.isEmpty ? 'جهاز جديد' : name;
      if (foreground) {
        toast.value = 'طلب إضافة جديد من $who';
        NativeBridge.vibrate();
      } else {
        NativeBridge.notifyInfo('طلب إضافة جديد', '$who يريد التواصل معك');
      }
    }
  }

  /// إعادة إرسال التعريف لمن لم يؤكد استلامه بعد (قد يكون كان غير متصل)
  void _resendHellos() {
    final r = relay;
    final id = identity;
    if (r == null || id == null || r.connectedCount == 0) return;
    final now = DateTime.now();
    for (final c in store.contacts) {
      if (c.confirmed) continue;
      final last = _helloSent[c.id];
      if (last != null && now.difference(last).inSeconds < 60) continue;
      _helloSent[c.id] = now;
      r.send(c.publicKey, {'t': 'hello', 'name': id.name});
    }
  }

  // ------------------------------------------------------------------ الإشعارات
  void _onIncomingMessage(ChatMessage m) {
    final title = store.titleOf(m.chatId);
    final body = m.isGroup ? '${m.senderName ?? 'عضو'}: ${m.preview}' : m.preview;
    if (!foreground) {
      NativeBridge.notifyMessage(chatId: m.chatId, title: title, body: body, sender: m.senderName);
      return;
    }
    if (links?.activeChat != m.chatId) {
      toast.value = m.isGroup ? '$title — $body' : 'رسالة جديدة من $title';
      NativeBridge.vibrate();
    }
  }

  void _onShowCall(CallSession s) {
    showCall?.call(s);
    if (!s.outgoing && !foreground) {
      NativeBridge.notifyIncomingCall(
        title: s.contact.displayName,
        body: s.video ? 'مكالمة فيديو واردة' : 'مكالمة صوتية واردة',
        video: s.video,
      );
    }
  }

  void _onShowGroupCall(GroupCallSession s) {
    showGroupCall?.call(s);
    if (!s.startedByMe && s.phase == GroupCallPhase.ringing && !foreground) {
      NativeBridge.notifyIncomingCall(
        title: s.group.name,
        body: '${store.nameOf(s.inviterId)} يدعوك إلى ${s.video ? 'مكالمة فيديو' : 'مكالمة صوتية'} جماعية',
        video: s.video,
      );
    }
  }

  Future<void> _onNativeAction(NativeAction a) async {
    if (a.type == 'chat') {
      final chatId = a.data['chatId'];
      if (chatId is String && chatId.isNotEmpty) openChatRequest.value = chatId;
    } else if (a.type == 'call') {
      final action = a.data['action'];
      if (action == 'decline') {
        calls?.decline();
        groupCalls?.decline();
      } else if (action == 'accept') {
        await _acceptFromNotification();
      }
    }
  }

  Future<void> _acceptFromNotification() async {
    final c = calls?.current;
    final g = groupCalls?.current;
    final video = (c?.video ?? false) || (g?.video ?? false);
    final perms = [Permission.microphone, if (video) Permission.camera];
    var granted = true;
    for (final p in perms) {
      if (!(await p.status).isGranted) granted = false;
    }
    // بدون أذونات: نترك شاشة الرنين ظاهرة ليضغط المستخدم "رد" فتُطلب الأذونات
    if (!granted) return;
    if (c != null && c.phase == CallPhase.ringing) {
      await calls!.accept();
    } else if (g != null && g.phase == GroupCallPhase.ringing) {
      await groupCalls!.join(ringing: g);
    }
  }

  // ------------------------------------------------------------------ جهات الاتصال
  /// إضافة جهة اتصال من رمز QR ثابت، وإرسال تعريف بنا إليها
  Contact addContact(ContactCard card) {
    final existing = store.contact(card.id);
    if (existing != null) return existing;
    final c = Contact(id: card.id, publicKey: card.publicKey, name: card.name);
    store.unignore(c.id);
    // إن كان قد أرسل لنا طلباً من قبل فنحن متأكدون أنه يعرفنا
    c.confirmed = store.requests.any((r) => r.id == c.id);
    store.upsertContact(c);
    relay?.watch(c.id);
    _helloSent[c.id] = DateTime.now();
    relay?.send(c.publicKey, {
      't': c.confirmed ? 'hello_ack' : 'hello',
      'name': identity!.name,
    });
    return c;
  }

  Contact acceptRequest(ContactRequest r) {
    final c = Contact(id: r.id, publicKey: r.publicKey, name: r.name, confirmed: true);
    store.unignore(c.id);
    store.upsertContact(c);
    relay?.watch(c.id);
    relay?.send(c.publicKey, {'t': 'hello_ack', 'name': identity!.name});
    return c;
  }

  void declineRequest(ContactRequest r) {
    store.ignore(r.id);
    store.removeRequest(r.id);
  }

  Future<void> deleteContact(Contact c) async {
    if (!store.sharesGroup(c.id)) {
      links?.closeLink(c.id);
      relay?.unwatch(c.id);
    }
    await store.deleteContact(c.id);
  }

  bool isOnline(String peerId) => links?.isReachable(peerId) ?? false;

  /// عدد أعضاء القروب المتصلين الآن (بدوني)
  int onlineMembers(Group g) =>
      g.members.where((m) => m.id != store.selfId && isOnline(m.id)).length;

  // ------------------------------------------------------------------ الملف الشخصي
  Future<void> rename(String name) async {
    final id = identity;
    if (id == null || name.trim().isEmpty) return;
    id.name = name.trim();
    await store.saveIdentity(id.toJson());
    for (final g in store.groups) {
      final me = g.member(id.id);
      if (me != null) {
        me.name = id.name;
        store.groupChanged(g);
      }
    }
    links?.broadcastProfile();
    notifyListeners();
  }

  Future<void> resetEverything() async {
    NativeBridge.setBackground(false);
    _heartbeat?.cancel();
    await _relaySub?.cancel();
    await _presenceSub?.cancel();
    links?.closeAll();
    await relay?.stop();
    relay = null;
    links = null;
    calls = null;
    groups = null;
    groupCalls = null;
    identity = null;
    locked = false;
    await store.wipeAll();
    notifyListeners();
  }

  // ------------------------------------------------------------------ خادم الترحيل
  void _applyIce() {
    IceConfig.useBuiltin = store.settings.turnBuiltin;
    IceConfig.custom = TurnServer.fromJson(store.settings.turn);
  }

  void setTurnBuiltin(bool v) {
    store.settings.turnBuiltin = v;
    store.saveSettings();
    _applyIce();
    notifyListeners();
  }

  void setCustomTurn(TurnServer? t) {
    store.settings.turn = t?.toJson();
    store.saveSettings();
    _applyIce();
    notifyListeners();
  }

  // ------------------------------------------------------------------ الخلفية
  Future<void> setBackground(bool v) async {
    store.settings.background = v;
    store.saveSettings();
    await NativeBridge.setBackground(v);
    notifyListeners();
  }

  // ------------------------------------------------------------------ القفل
  void setLockEnabled(bool v) {
    store.settings.lockEnabled = v;
    store.saveSettings();
    notifyListeners();
  }

  /// لتجنّب القفل أثناء اختيار صورة أو المشاركة
  void suppressLock([Duration d = const Duration(minutes: 3)]) {
    _suppressLockUntil = DateTime.now().add(d);
  }

  Future<bool> unlock() async {
    if (_authInProgress || !foreground) return false;
    if (!_biometricChecked) await refreshBiometric();
    if (!locked) return true;
    _authInProgress = true;
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'افتح "اتصال مباشر"',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
      );
      if (ok) {
        locked = false;
        _graceUntil = DateTime.now().add(const Duration(seconds: 4));
        notifyListeners();
      }
      return ok;
    } catch (e) {
      debugPrint('auth error: $e');
      return false;
    } finally {
      _authInProgress = false;
    }
  }

  /// يُستخدم عند تفعيل القفل للتأكد أن البصمة تعمل
  Future<bool> verifyBiometric() async {
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'تأكيد تفعيل قفل التطبيق',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
      );
      _graceUntil = DateTime.now().add(const Duration(seconds: 4));
      return ok;
    } catch (_) {
      return false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.hidden:
      case AppLifecycleState.detached:
        foreground = false;
        _pausedAt ??= DateTime.now();
        store.flush();
        break;
      case AppLifecycleState.inactive:
        break;
      case AppLifecycleState.resumed:
        foreground = true;
        relay?.kick();
        links?.retryAll();
        final active = links?.activeChat;
        if (active != null) NativeBridge.cancelChatNotification(active);
        if (inCall) NativeBridge.cancelCallNotification();
        if (!_biometricChecked) refreshBiometric();
        final paused = _pausedAt;
        _pausedAt = null;
        final now = DateTime.now();
        final suppressed = (_suppressLockUntil != null && now.isBefore(_suppressLockUntil!)) ||
            (_graceUntil != null && now.isBefore(_graceUntil!));
        _suppressLockUntil = null;
        if (ready &&
            !_authInProgress &&
            !suppressed &&
            paused != null &&
            store.settings.lockEnabled &&
            (biometricSupported || !_biometricChecked) &&
            now.difference(paused).inSeconds >= store.settings.lockAfterSeconds) {
          locked = true;
        }
        notifyListeners();
        break;
    }
  }
}
