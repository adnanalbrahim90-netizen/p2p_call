import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:local_auth/local_auth.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import '../net/calls.dart';
import '../net/link.dart';
import '../net/native.dart';
import '../net/relay.dart';

/// نقطة التحكم المركزية في التطبيق
class AppController extends ChangeNotifier with WidgetsBindingObserver {
  AppController._(this.store);

  static late AppController I;

  final Store store;
  Identity? identity;
  Relay? relay;
  LinkManager? links;
  CallManager? calls;

  final LocalAuthentication _auth = LocalAuthentication();
  bool biometricSupported = false;
  bool locked = false;
  bool _authInProgress = false;
  DateTime? _pausedAt;
  DateTime? _suppressLockUntil;
  DateTime? _graceUntil;
  final Map<String, DateTime> _helloSent = {};
  Timer? _heartbeat;
  StreamSubscription<RelayMessage>? _relaySub;
  StreamSubscription<String>? _presenceSub;

  /// تنبيهات داخل التطبيق (رسالة جديدة / طلب إضافة)
  final ValueNotifier<String?> toast = ValueNotifier<String?>(null);

  bool get ready => identity != null;

  static Future<AppController> boot() async {
    final store = await Store.open();
    final c = AppController._(store);
    I = c;
    WidgetsBinding.instance.addObserver(c);
    try {
      c.biometricSupported = await c._auth.isDeviceSupported();
    } catch (_) {
      c.biometricSupported = false;
    }
    final j = store.identityJson;
    if (j != null) {
      try {
        c.identity = await Identity.fromJson(j);
      } catch (_) {
        c.identity = null;
      }
    }
    if (c.identity != null) {
      c.locked = store.settings.lockEnabled && c.biometricSupported;
      c._startNetwork();
    }
    return c;
  }

  // ------------------------------------------------------------------ الإعداد الأول
  Future<void> createIdentity(String name, {required bool lock}) async {
    final id = await Identity.generate(name.trim());
    await store.saveIdentity(id.toJson());
    store.settings.lockEnabled = lock && biometricSupported;
    store.saveSettings();
    identity = id;
    _startNetwork();
    notifyListeners();
  }

  void _startNetwork() {
    final id = identity!;
    final r = Relay(id, Cipher(id));
    final l = LinkManager(id, store, r);
    final c = CallManager(id, store, r);
    relay = r;
    links = l;
    calls = c;
    for (final contact in store.contacts) {
      r.watch(contact.id);
    }
    _relaySub = r.messages.listen(_onRelay);
    _presenceSub = r.presenceChanges.listen((cid) => l.onPresence(cid));
    l.onIncoming = (cid) {
      if (l.activeChat != cid) {
        final c = store.contact(cid);
        if (c != null) toast.value = 'رسالة جديدة من ${c.displayName}';
      }
      NativeBridge.vibrate();
    };
    l.onLinked = (cid) {
      final c = store.contact(cid);
      if (c != null && !c.confirmed) {
        c.confirmed = true;
        store.updateContact(c);
      }
    };
    r.start();
    Timer(const Duration(seconds: 5), _resendHellos);
    _heartbeat = Timer.periodic(const Duration(seconds: 30), (_) {
      r.kick();
      l.retryAll();
      _resendHellos();
    });
  }

  void _onRelay(RelayMessage m) {
    switch (m.type) {
      case 'hello':
        _onHello(m);
        break;
      case 'hello_ack':
        final c = store.contact(m.senderId);
        if (c == null) break;
        final name = (m.data['name'] as String?)?.trim();
        if (name != null && name.isNotEmpty) c.name = name;
        c.confirmed = true;
        store.updateContact(c);
        links?.onPresence(c.id);
        break;
      case 'link_offer':
      case 'link_answer':
        links?.onRelay(m);
        break;
      default:
        if (m.type.startsWith('call_')) calls?.onRelay(m);
    }
  }

  void _onHello(RelayMessage m) {
    final name = ((m.data['name'] as String?) ?? '').trim();
    final existing = store.contact(m.senderId);
    if (existing != null) {
      if (name.isNotEmpty) existing.name = name;
      existing.confirmed = true;
      store.updateContact(existing);
      relay?.send(existing.publicKey, {'t': 'hello_ack', 'name': identity!.name});
      return;
    }
    if (store.ignored.contains(m.senderId)) return;
    final already = store.requests.any((r) => r.id == m.senderId);
    store.addRequest(ContactRequest(id: m.senderId, publicKey: m.senderKey, name: name));
    if (!already) {
      toast.value = 'طلب إضافة جديد من ${name.isEmpty ? 'جهاز جديد' : name}';
      NativeBridge.vibrate();
    }
  }

  /// إعادة إرسال التعريف لمن لم يؤكد استلامه بعد (قد يكون كان غير متصل)
  void _resendHellos() {
    final r = relay;
    final id = identity;
    if (r == null || id == null || r.connectedCount == 0) return;
    final now = DateTime.now();
    for (final c in store.contacts) {
      if (c.confirmed) continue;
      final last = _helloSent[c.id];
      if (last != null && now.difference(last).inSeconds < 60) continue;
      _helloSent[c.id] = now;
      r.send(c.publicKey, {'t': 'hello', 'name': id.name});
    }
  }

  // ------------------------------------------------------------------ جهات الاتصال
  /// إضافة جهة اتصال من رمز QR ثابت، وإرسال تعريف بنا إليها
  Contact addContact(ContactCard card) {
    final existing = store.contact(card.id);
    if (existing != null) return existing;
    final c = Contact(id: card.id, publicKey: card.publicKey, name: card.name);
    store.unignore(c.id);
    // إن كان قد أرسل لنا طلباً من قبل فنحن متأكدون أنه يعرفنا
    c.confirmed = store.requests.any((r) => r.id == c.id);
    store.upsertContact(c);
    relay?.watch(c.id);
    _helloSent[c.id] = DateTime.now();
    relay?.send(c.publicKey, {
      't': c.confirmed ? 'hello_ack' : 'hello',
      'name': identity!.name,
    });
    return c;
  }

  Contact acceptRequest(ContactRequest r) {
    final c = Contact(id: r.id, publicKey: r.publicKey, name: r.name, confirmed: true);
    store.unignore(c.id);
    store.upsertContact(c);
    relay?.watch(c.id);
    relay?.send(c.publicKey, {'t': 'hello_ack', 'name': identity!.name});
    return c;
  }

  void declineRequest(ContactRequest r) {
    store.ignore(r.id);
    store.removeRequest(r.id);
  }

  Future<void> deleteContact(Contact c) async {
    links?.closeLink(c.id);
    relay?.unwatch(c.id);
    await store.deleteContact(c.id);
  }

  bool isOnline(String contactId) => links?.isReachable(contactId) ?? false;

  // ------------------------------------------------------------------ الملف الشخصي
  Future<void> rename(String name) async {
    final id = identity;
    if (id == null || name.trim().isEmpty) return;
    id.name = name.trim();
    await store.saveIdentity(id.toJson());
    for (final c in store.contacts) {
      links?.link(c.id)?.sendCtl({'t': 'profile', 'name': id.name});
    }
    notifyListeners();
  }

  Future<void> resetEverything() async {
    _heartbeat?.cancel();
    await _relaySub?.cancel();
    await _presenceSub?.cancel();
    links?.closeAll();
    await relay?.stop();
    relay = null;
    links = null;
    calls = null;
    identity = null;
    locked = false;
    await store.wipeAll();
    notifyListeners();
  }

  // ------------------------------------------------------------------ القفل
  void setLockEnabled(bool v) {
    store.settings.lockEnabled = v;
    store.saveSettings();
    notifyListeners();
  }

  /// لتجنّب القفل أثناء اختيار صورة أو المشاركة
  void suppressLock([Duration d = const Duration(minutes: 3)]) {
    _suppressLockUntil = DateTime.now().add(d);
  }

  Future<bool> unlock() async {
    if (_authInProgress) return false;
    _authInProgress = true;
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'افتح "اتصال مباشر"',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
      );
      if (ok) {
        locked = false;
        _graceUntil = DateTime.now().add(const Duration(seconds: 4));
        notifyListeners();
      }
      return ok;
    } catch (e) {
      debugPrint('auth error: $e');
      return false;
    } finally {
      _authInProgress = false;
    }
  }

  /// يُستخدم عند تفعيل القفل للتأكد أن البصمة تعمل
  Future<bool> verifyBiometric() async {
    try {
      final ok = await _auth.authenticate(
        localizedReason: 'تأكيد تفعيل قفل التطبيق',
        options: const AuthenticationOptions(stickyAuth: true, biometricOnly: false),
      );
      _graceUntil = DateTime.now().add(const Duration(seconds: 4));
      return ok;
    } catch (_) {
      return false;
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.hidden:
        _pausedAt ??= DateTime.now();
        store.flush();
        break;
      case AppLifecycleState.resumed:
        relay?.kick();
        links?.retryAll();
        final paused = _pausedAt;
        _pausedAt = null;
        final now = DateTime.now();
        final suppressed = (_suppressLockUntil != null && now.isBefore(_suppressLockUntil!)) ||
            (_graceUntil != null && now.isBefore(_graceUntil!));
        _suppressLockUntil = null;
        if (ready &&
            !_authInProgress &&
            !suppressed &&
            paused != null &&
            store.settings.lockEnabled &&
            biometricSupported &&
            DateTime.now().difference(paused).inSeconds >= store.settings.lockAfterSeconds) {
          locked = true;
          notifyListeners();
        }
        break;
      default:
        break;
    }
  }
}
