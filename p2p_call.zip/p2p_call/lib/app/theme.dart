import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const String kFont = 'Plex';

/// ألوان إضافية خاصة بالتطبيق (تختلف بين الوضع الفاتح والداكن)
@immutable
class Palette extends ThemeExtension<Palette> {
  const Palette({
    required this.bg,
    required this.card,
    required this.subtle,
    required this.line,
    required this.text,
    required this.muted,
    required this.brand,
    required this.brandSoft,
    required this.onBrand,
    required this.mine,
    required this.onMine,
    required this.theirs,
    required this.onTheirs,
    required this.online,
    required this.danger,
    required this.success,
    required this.warning,
    required this.chatBg,
  });

  final Color bg, card, subtle, line, text, muted;
  final Color brand, brandSoft, onBrand;
  final Color mine, onMine, theirs, onTheirs;
  final Color online, danger, success, warning, chatBg;

  static const light = Palette(
    bg: Color(0xFFF6F7FB),
    card: Color(0xFFFFFFFF),
    subtle: Color(0xFFEEF0F7),
    line: Color(0xFFE4E7F0),
    text: Color(0xFF111426),
    muted: Color(0xFF6A7088),
    brand: Color(0xFF4C46E0),
    brandSoft: Color(0xFFEAE9FD),
    onBrand: Color(0xFFFFFFFF),
    mine: Color(0xFF4C46E0),
    onMine: Color(0xFFFFFFFF),
    theirs: Color(0xFFFFFFFF),
    onTheirs: Color(0xFF111426),
    online: Color(0xFF12B76A),
    danger: Color(0xFFE5484D),
    success: Color(0xFF12B76A),
    warning: Color(0xFFE89B0C),
    chatBg: Color(0xFFF1F2F8),
  );

  static const dark = Palette(
    bg: Color(0xFF0B0C14),
    card: Color(0xFF151724),
    subtle: Color(0xFF1C1F30),
    line: Color(0xFF262A3E),
    text: Color(0xFFECEEF7),
    muted: Color(0xFF8C92AB),
    brand: Color(0xFF8079FF),
    brandSoft: Color(0xFF232246),
    onBrand: Color(0xFFFFFFFF),
    mine: Color(0xFF5B54EC),
    onMine: Color(0xFFFFFFFF),
    theirs: Color(0xFF1C1F30),
    onTheirs: Color(0xFFECEEF7),
    online: Color(0xFF2BD48A),
    danger: Color(0xFFFF6369),
    success: Color(0xFF2BD48A),
    warning: Color(0xFFFFB53D),
    chatBg: Color(0xFF0E0F19),
  );

  @override
  Palette copyWith() => this;

  @override
  Palette lerp(ThemeExtension<Palette>? other, double t) {
    if (other is! Palette) return this;
    Color l(Color a, Color b) => Color.lerp(a, b, t)!;
    return Palette(
      bg: l(bg, other.bg),
      card: l(card, other.card),
      subtle: l(subtle, other.subtle),
      line: l(line, other.line),
      text: l(text, other.text),
      muted: l(muted, other.muted),
      brand: l(brand, other.brand),
      brandSoft: l(brandSoft, other.brandSoft),
      onBrand: l(onBrand, other.onBrand),
      mine: l(mine, other.mine),
      onMine: l(onMine, other.onMine),
      theirs: l(theirs, other.theirs),
      onTheirs: l(onTheirs, other.onTheirs),
      online: l(online, other.online),
      danger: l(danger, other.danger),
      success: l(success, other.success),
      warning: l(warning, other.warning),
      chatBg: l(chatBg, other.chatBg),
    );
  }
}

extension PaletteX on BuildContext {
  Palette get pal => Theme.of(this).extension<Palette>()!;
  TextTheme get txt => Theme.of(this).textTheme;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
}

/// تدرج العلامة التجارية (يُستخدم في الأيقونة وشاشة البداية)
const LinearGradient brandGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: [Color(0xFF6C63FF), Color(0xFF3B34C8)],
);

ThemeData buildTheme(Brightness b) {
  final p = b == Brightness.dark ? Palette.dark : Palette.light;
  final scheme = ColorScheme.fromSeed(seedColor: p.brand, brightness: b).copyWith(
    primary: p.brand,
    onPrimary: p.onBrand,
    surface: p.card,
    onSurface: p.text,
    error: p.danger,
    outline: p.line,
    outlineVariant: p.line,
  );

  TextStyle s(double size, FontWeight w, {double h = 1.45, Color? c}) =>
      TextStyle(fontFamily: kFont, fontSize: size, fontWeight: w, height: h, color: c ?? p.text);

  final text = TextTheme(
    displaySmall: s(30, FontWeight.w700, h: 1.25),
    headlineMedium: s(26, FontWeight.w700, h: 1.3),
    headlineSmall: s(22, FontWeight.w700, h: 1.3),
    titleLarge: s(19, FontWeight.w700, h: 1.35),
    titleMedium: s(16, FontWeight.w600),
    titleSmall: s(14, FontWeight.w600),
    bodyLarge: s(16, FontWeight.w400, h: 1.55),
    bodyMedium: s(14.5, FontWeight.w400, h: 1.55),
    bodySmall: s(12.5, FontWeight.w400, c: p.muted),
    labelLarge: s(15, FontWeight.w600, h: 1.2),
    labelMedium: s(12.5, FontWeight.w500, h: 1.2),
    labelSmall: s(11, FontWeight.w500, h: 1.2, c: p.muted),
  );

  final overlay = b == Brightness.dark
      ? SystemUiOverlayStyle.light.copyWith(statusBarColor: Colors.transparent)
      : SystemUiOverlayStyle.dark.copyWith(statusBarColor: Colors.transparent);

  return ThemeData(
    useMaterial3: true,
    brightness: b,
    fontFamily: kFont,
    colorScheme: scheme,
    scaffoldBackgroundColor: p.bg,
    canvasColor: p.bg,
    textTheme: text,
    extensions: [p],
    splashFactory: InkSparkle.splashFactory,
    appBarTheme: AppBarTheme(
      backgroundColor: p.bg,
      surfaceTintColor: Colors.transparent,
      foregroundColor: p.text,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      systemOverlayStyle: overlay,
      titleTextStyle: s(20, FontWeight.w700, h: 1.3),
    ),
    dividerTheme: DividerThemeData(color: p.line, thickness: 1, space: 1),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: p.card,
      surfaceTintColor: Colors.transparent,
      indicatorColor: p.brandSoft,
      height: 68,
      elevation: 0,
      labelTextStyle: WidgetStateProperty.resolveWith((st) => s(
            12,
            st.contains(WidgetState.selected) ? FontWeight.w700 : FontWeight.w500,
            h: 1.2,
            c: st.contains(WidgetState.selected) ? p.brand : p.muted,
          )),
      iconTheme: WidgetStateProperty.resolveWith((st) => IconThemeData(
            color: st.contains(WidgetState.selected) ? p.brand : p.muted,
            size: 24,
          )),
    ),
    floatingActionButtonTheme: FloatingActionButtonThemeData(
      backgroundColor: p.brand,
      foregroundColor: p.onBrand,
      elevation: 2,
      highlightElevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: p.brand,
        foregroundColor: p.onBrand,
        minimumSize: const Size.fromHeight(54),
        textStyle: s(16, FontWeight.w600, h: 1.2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: p.text,
        minimumSize: const Size.fromHeight(50),
        side: BorderSide(color: p.line),
        textStyle: s(15, FontWeight.w600, h: 1.2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: p.brand,
        textStyle: s(15, FontWeight.w600, h: 1.2),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: p.subtle,
      hintStyle: s(15, FontWeight.w400, c: p.muted),
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide(color: p.brand, width: 1.5),
      ),
    ),
    listTileTheme: ListTileThemeData(
      iconColor: p.muted,
      titleTextStyle: s(15.5, FontWeight.w600, h: 1.3),
      subtitleTextStyle: s(13, FontWeight.w400, h: 1.35, c: p.muted),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: WidgetStateProperty.resolveWith(
          (st) => st.contains(WidgetState.selected) ? Colors.white : null),
      trackColor: WidgetStateProperty.resolveWith(
          (st) => st.contains(WidgetState.selected) ? p.brand : null),
    ),
    snackBarTheme: SnackBarThemeData(
      behavior: SnackBarBehavior.floating,
      backgroundColor: b == Brightness.dark ? const Color(0xFF2A2D42) : const Color(0xFF1B1E30),
      contentTextStyle: s(14, FontWeight.w500, c: Colors.white),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: p.card,
      surfaceTintColor: Colors.transparent,
      showDragHandle: true,
      dragHandleColor: p.line,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
      ),
    ),
    dialogTheme: DialogTheme(
      backgroundColor: p.card,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      titleTextStyle: s(19, FontWeight.w700),
      contentTextStyle: s(14.5, FontWeight.w400, c: p.muted),
    ),
    popupMenuTheme: PopupMenuThemeData(
      color: p.card,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      textStyle: s(14.5, FontWeight.w500),
    ),
    progressIndicatorTheme: ProgressIndicatorThemeData(color: p.brand),
  );
}
