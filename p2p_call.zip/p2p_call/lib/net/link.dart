import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import 'relay.dart';
import 'rtc.dart';

enum LinkState { connecting, open, closed }

/// قناة بيانات مباشرة (P2P) مع جهة اتصال واحدة:
///  • ctl  : الرسائل النصية والإشعارات الصغيرة
///  • file : نقل الصور ومقاطع الفيديو على شكل أجزاء
class PeerLink {
  PeerLink(this._m, this.peer, {required this.initiator, required this.sid});

  final LinkManager _m;
  final PeerInfo peer;
  String get peerId => peer.id;
  final bool initiator;
  final String sid;

  RTCPeerConnection? _pc;
  RTCDataChannel? _ctl;
  RTCDataChannel? _file;
  final IceGatherer _ice = IceGatherer();
  LinkState state = LinkState.connecting;
  bool wasOpen = false;
  Timer? _connectTimeout;
  Timer? _disconnectTimer;
  DateTime lastActivity = DateTime.now();

  Future<void> _fileChain = Future<void>.value();
  Future<void> _ctlChain = Future<void>.value();
  _IncomingFile? _rx;

  bool get isOpen => state == LinkState.open;
  bool get isClosed => state == LinkState.closed;

  static const int chunkSize = 32 * 1024;
  static const int maxBuffered = 1024 * 1024;

  Future<void> _createPc({Object? shared}) async {
    final pc = await createPeerConnection(IceConfig.configuration(shared: shared));
    _pc = pc;
    pc.onIceGatheringState = _ice.onState;
    pc.onIceCandidate = _ice.onCandidate;
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          s == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
        close();
      } else if (s ==
          RTCPeerConnectionState.RTCPeerConnectionStateDisconnected) {
        _disconnectTimer?.cancel();
        _disconnectTimer = Timer(const Duration(seconds: 12), close);
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        _disconnectTimer?.cancel();
      }
    };
    pc.onDataChannel = _bind;
    _connectTimeout = Timer(const Duration(seconds: 25), () {
      if (state == LinkState.connecting) close();
    });
  }

  /// الطرف البادئ: إنشاء القنوات وإرسال العرض عبر الوسيط
  Future<void> start() async {
    try {
      await _createPc();
      final pc = _pc!;
      _bind(await pc.createDataChannel('ctl', RTCDataChannelInit()..ordered = true));
      _bind(await pc.createDataChannel('file', RTCDataChannelInit()..ordered = true));
      final offer = await pc.createOffer({});
      final local = await _ice.setLocalAndWait(pc, offer);
      if (isClosed) return;
      final ok = await _m.relay.send(peer.publicKey, {
        't': 'link_offer',
        'sid': sid,
        'sdp': local.sdp,
        'ice': IceConfig.shareable(),
      });
      if (!ok) close();
    } catch (e) {
      debugPrint('link start failed: $e');
      close();
    }
  }

  /// الطرف المستقبل: قبول العرض وإرسال الرد
  Future<void> accept(String sdp, {Object? shared}) async {
    try {
      await _createPc(shared: shared);
      final pc = _pc!;
      await pc.setRemoteDescription(RTCSessionDescription(sdp, 'offer'));
      final answer = await pc.createAnswer({});
      final local = await _ice.setLocalAndWait(pc, answer);
      if (isClosed) return;
      final ok = await _m.relay.send(peer.publicKey, {
        't': 'link_answer',
        'sid': sid,
        'sdp': local.sdp,
      });
      if (!ok) close();
    } catch (e) {
      debugPrint('link accept failed: $e');
      close();
    }
  }

  Future<void> applyAnswer(String sdp) async {
    try {
      await _pc?.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
    } catch (e) {
      debugPrint('link answer failed: $e');
      close();
    }
  }

  void _bind(RTCDataChannel dc) {
    if (dc.label == 'ctl') {
      _ctl = dc;
      dc.onMessage = (msg) {
        lastActivity = DateTime.now();
        if (msg.isBinary) return;
        Map<String, dynamic>? data;
        try {
          final v = jsonDecode(msg.text);
          if (v is Map<String, dynamic>) data = v;
        } catch (_) {}
        if (data == null) return;
        final d = data;
        // معالجة بالترتيب (مثلاً: دعوة القروب قبل أول رسائله)
        _ctlChain = _ctlChain.then((_) => _m._onCtl(this, d)).catchError((Object e) {
          debugPrint('ctl rx error: $e');
        });
      };
    } else if (dc.label == 'file') {
      _file = dc;
      dc.bufferedAmountLowThreshold = maxBuffered ~/ 2;
      dc.onMessage = (msg) {
        lastActivity = DateTime.now();
        _fileChain = _fileChain.then((_) => _onFileMessage(msg)).catchError((Object e) {
          debugPrint('file rx error: $e');
        });
      };
    } else {
      return;
    }
    dc.onDataChannelState = (_) => _checkOpen();
    _checkOpen();
  }

  void _checkOpen() {
    if (isClosed) return;
    final ctlOpen = _ctl?.state == RTCDataChannelState.RTCDataChannelOpen;
    final fileOpen = _file?.state == RTCDataChannelState.RTCDataChannelOpen;
    if (ctlOpen && fileOpen && state == LinkState.connecting) {
      state = LinkState.open;
      wasOpen = true;
      _connectTimeout?.cancel();
      _m._onOpen(this);
    }
    final ctlClosed = _ctl?.state == RTCDataChannelState.RTCDataChannelClosed;
    final fileClosed = _file?.state == RTCDataChannelState.RTCDataChannelClosed;
    if (state == LinkState.open && (ctlClosed || fileClosed)) close();
  }

  // ----------------------------------------------------------------- الإرسال
  Future<bool> sendCtl(Map<String, dynamic> data) async {
    final dc = _ctl;
    if (!isOpen || dc == null) return false;
    try {
      await dc.send(RTCDataChannelMessage(jsonEncode(data)));
      lastActivity = DateTime.now();
      return true;
    } catch (e) {
      debugPrint('ctl send failed: $e');
      return false;
    }
  }

  Future<bool> sendFile(ChatMessage m, void Function(double p) onProgress) async {
    final dc = _file;
    final path = m.filePath;
    if (!isOpen || dc == null || path == null) return false;
    final f = File(path);
    if (!await f.exists()) return false;
    final size = await f.length();
    RandomAccessFile? raf;
    try {
      await dc.send(RTCDataChannelMessage(jsonEncode({
        't': 'file',
        'id': m.id,
        'kind': m.kind.name,
        'name': m.fileName,
        'size': size,
        'mime': m.mime,
        'ts': m.time.millisecondsSinceEpoch,
        if (m.text != null) 'cap': m.text,
        if (m.isGroup) 'g': groupIdOf(m.chatId),
      })));
      raf = await f.open();
      var sent = 0;
      var lastReport = -1.0;
      while (sent < size) {
        if (!isOpen) return false;
        var waited = 0;
        while ((dc.bufferedAmount ?? 0) > maxBuffered) {
          await Future<void>.delayed(const Duration(milliseconds: 15));
          if (!isOpen) return false;
          if (++waited > 2000) return false; // ~30 ثانية بلا تقدم
        }
        final chunk = await raf.read(min(chunkSize, size - sent));
        if (chunk.isEmpty) break;
        await dc.send(RTCDataChannelMessage.fromBinary(chunk));
        sent += chunk.length;
        lastActivity = DateTime.now();
        final p = sent / size;
        if (p - lastReport >= 0.01 || sent >= size) {
          lastReport = p;
          onProgress(p);
        }
      }
      await dc.send(RTCDataChannelMessage(jsonEncode({'t': 'file_end', 'id': m.id})));
      return true;
    } catch (e) {
      debugPrint('file send failed: $e');
      return false;
    } finally {
      await raf?.close();
    }
  }

  // ----------------------------------------------------------------- الاستقبال
  Future<void> _onFileMessage(RTCDataChannelMessage msg) async {
    if (msg.isBinary) {
      _rx?.add(msg.binary);
      return;
    }
    Map<String, dynamic> data;
    try {
      data = jsonDecode(msg.text) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final t = data['t'];
    if (t == 'file') {
      await _rx?.abort();
      _rx = await _m._beginIncoming(this, data);
    } else if (t == 'file_end') {
      final rx = _rx;
      _rx = null;
      if (rx != null && rx.id == data['id']) await rx.finish();
    }
  }

  void close() {
    if (isClosed) return;
    state = LinkState.closed;
    _connectTimeout?.cancel();
    _disconnectTimer?.cancel();
    final rx = _rx;
    _rx = null;
    rx?.abort();
    try {
      _ctl?.close();
    } catch (_) {}
    try {
      _file?.close();
    } catch (_) {}
    try {
      _pc?.close();
    } catch (_) {}
    _pc = null;
    _m._onClosed(this);
  }
}

/// ملف قيد الاستلام
class _IncomingFile {
  _IncomingFile(this._m, this.link, this.message, this.size, {this.discard = false})
      : id = message.id {
    if (!discard) _sink = File(message.filePath!).openWrite();
  }

  final LinkManager _m;
  final PeerLink link;
  final ChatMessage message;
  final String id;
  final int size;
  final bool discard;
  IOSink? _sink;
  int received = 0;
  double _lastReport = 0;

  void add(Uint8List chunk) {
    received += chunk.length;
    if (discard) return;
    _sink?.add(chunk);
    if (size > 0) {
      final p = received / size;
      if (p - _lastReport >= 0.02) {
        _lastReport = p;
        message.progress = p.clamp(0.0, 1.0);
        _m.store.messageChanged(message, persist: false);
      }
    }
  }

  Future<void> finish() async {
    if (!discard) {
      await _sink?.flush();
      await _sink?.close();
      message.status = MessageStatus.received;
      message.progress = 1;
      message.fileSize = received;
      _m.store.messageChanged(message);
    }
    await link.sendCtl({
      't': 'ack',
      'id': id,
      if (message.isGroup) 'g': groupIdOf(message.chatId),
    });
  }

  Future<void> abort() async {
    if (discard) return;
    try {
      await _sink?.close();
    } catch (_) {}
    message.status = MessageStatus.failed;
    _m.store.messageChanged(message);
  }
}

/// يدير القنوات المباشرة مع كل الأطراف (جهات الاتصال وأعضاء القروبات)
/// وطابور الرسائل الصادرة ورسائل التحكم المضمونة.
class LinkManager extends ChangeNotifier {
  LinkManager(this.identity, this.store, this.relay);

  final Identity identity;
  final Store store;
  final Relay relay;

  final Map<String, PeerLink> _links = {};
  final Map<String, DateTime> _lastAttempt = {};
  final Map<String, int> _failures = {};
  final Map<String, DateTime> _nextAllowed = {};
  final Map<String, (DateTime, String)> _typing = {};
  final Set<String> _pumpingText = {};
  final Set<String> _pumpingFiles = {};
  final Set<String> _rerunText = {};
  final Set<String> _rerunFiles = {};
  Timer? _typingTimer;

  /// المحادثة المفتوحة حالياً على الشاشة
  String? activeChat;

  /// رسالة جديدة واردة (للإشعارات)
  void Function(ChatMessage message)? onIncoming;

  /// فُتحت قناة مباشرة (دليل أن الطرف الآخر يعرفنا)
  void Function(String peerId)? onLinked;

  /// رسائل التحكم الخاصة بالقروبات
  Future<void> Function(String peerId, Map<String, dynamic> data)? onGroupControl;

  PeerLink? link(String peerId) => _links[peerId];

  bool isLinked(String peerId) => _links[peerId]?.isOpen ?? false;

  bool isConnecting(String peerId) => _links[peerId]?.state == LinkState.connecting;

  /// متصل: إما عبر الوسيط أو عبر قناة مباشرة مفتوحة
  bool isReachable(String peerId) => relay.isOnline(peerId) || isLinked(peerId);

  /// من يكتب الآن في هذه المحادثة (الاسم) أو null
  String? typingIn(String chatId) {
    final t = _typing[chatId];
    if (t == null || t.$1.isBefore(DateTime.now())) return null;
    return t.$2;
  }

  bool isTyping(String chatId) => typingIn(chatId) != null;

  /// يمكننا فتح قناة: جهة اتصال قبلت طلبنا، أو عضو في قروب مشترك
  bool canLink(String peerId) =>
      (store.contact(peerId)?.confirmed ?? false) ||
      store.sharesGroup(peerId) ||
      store.hasOutboxFor(peerId);

  bool _accepts(String peerId) => store.hasContact(peerId) || store.sharesGroup(peerId);

  // ----------------------------------------------------------------- إنشاء القنوات
  /// يفتح قناة مباشرة إن كان الطرف الآخر متصلاً ولا توجد قناة.
  /// [force] لإجراءات المستخدم (إرسال رسالة / فتح المحادثة) فيتجاوز فترة الانتظار.
  void ensureLink(String peerId, {bool force = false}) {
    if (peerId == identity.id || !canLink(peerId)) return;
    final peer = store.peer(peerId);
    if (peer == null) return;
    final existing = _links[peerId];
    if (existing != null && !existing.isClosed) return;
    if (!relay.isOnline(peerId) || relay.connectedCount == 0) return;
    final now = DateTime.now();
    final last = _lastAttempt[peerId];
    if (last != null && now.difference(last).inSeconds < (force ? 3 : 8)) return;
    final next = _nextAllowed[peerId];
    if (!force && next != null && now.isBefore(next)) return;
    _lastAttempt[peerId] = now;
    final l = PeerLink(this, peer, initiator: true, sid: newId(8));
    _links[peerId] = l;
    notifyListeners();
    l.start();
  }

  /// معالجة رسائل الوسيط الخاصة بالقنوات
  void onRelay(RelayMessage m) {
    if (!_accepts(m.senderId)) return;
    final peer = store.peer(m.senderId) ?? PeerInfo(m.senderId, m.senderKey, '');
    final sid = m.data['sid'] as String?;
    final sdp = m.data['sdp'] as String?;
    if (sid == null || sdp == null) return;

    if (m.type == 'link_offer') {
      final existing = _links[peer.id];
      if (existing != null && !existing.isClosed) {
        // تصادم: الطرفان بدآ معاً — المعرّف الأصغر يحتفظ بعرضه
        if (existing.state == LinkState.connecting &&
            existing.initiator &&
            identity.id.compareTo(peer.id) < 0) {
          return;
        }
        existing.close();
      }
      final l = PeerLink(this, peer, initiator: false, sid: sid);
      _links[peer.id] = l;
      notifyListeners();
      l.accept(sdp, shared: m.data['ice']);
    } else if (m.type == 'link_answer') {
      final l = _links[peer.id];
      if (l != null && l.initiator && l.sid == sid && !l.isClosed) {
        l.applyAnswer(sdp);
      }
    }
  }

  void onPresence(String peerId) {
    if (relay.isOnline(peerId)) {
      // ظروف شبكة جديدة: نلغي فترة الانتظار
      _failures.remove(peerId);
      _nextAllowed.remove(peerId);
      _maybeConnectFor(peerId);
    }
    notifyListeners();
  }

  Future<void> _maybeConnectFor(String peerId) async {
    final active = activeChat;
    final inActive = active != null &&
        (active == peerId ||
            (isGroupChat(active) && (store.group(groupIdOf(active))?.has(peerId) ?? false)));
    if (inActive || await store.hasOutgoing(peerId)) {
      ensureLink(peerId);
    }
  }

  /// محاولة دورية لكل من لديه رسائل معلقة
  Future<void> retryAll() async {
    for (final id in store.allPeerIds) {
      if (relay.isOnline(id) && !isLinked(id)) {
        await _maybeConnectFor(id);
      }
    }
  }

  /// عند فتح محادثة: تجهيز القنوات مع أطرافها المتصلين
  void warmUp(String chatId) {
    if (isGroupChat(chatId)) {
      final g = store.group(groupIdOf(chatId));
      if (g == null || g.left) return;
      for (final m in g.members) {
        if (m.id != identity.id) ensureLink(m.id);
      }
    } else {
      ensureLink(chatId, force: true);
    }
  }

  void _onOpen(PeerLink l) {
    if (_links[l.peerId] != l) {
      l.close();
      return;
    }
    onLinked?.call(l.peerId);
    l.sendCtl({'t': 'profile', 'name': identity.name});
    notifyListeners();
    pump(l.peerId);
  }

  void _onClosed(PeerLink l) {
    if (_links[l.peerId] == l) {
      final id = l.peerId;
      _links.remove(id);
      notifyListeners();
      // تراجع تدريجي عند الفشل المتكرر (شبكات تمنع الاتصال المباشر)
      var delay = const Duration(seconds: 3);
      if (l.wasOpen) {
        _failures.remove(id);
        _nextAllowed.remove(id);
      } else {
        final n = (_failures[id] ?? 0) + 1;
        _failures[id] = n;
        delay = Duration(seconds: (15 * n).clamp(15, 180));
        _nextAllowed[id] = DateTime.now().add(delay);
      }
      Timer(delay, () => _maybeConnectFor(id));
    }
  }

  // ----------------------------------------------------------------- الإرسال
  /// أعضاء القروب الذين يجب أن تصلهم رسالة جديدة
  List<String> _recipients(String chatId) {
    if (!isGroupChat(chatId)) return [chatId];
    final g = store.group(groupIdOf(chatId));
    if (g == null || g.left) return const [];
    return g.members.map((m) => m.id).where((id) => id != identity.id).toList();
  }

  Future<void> sendText(String chatId, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    final group = isGroupChat(chatId);
    final to = _recipients(chatId);
    final m = ChatMessage(
      id: newId(),
      chatId: chatId,
      mine: true,
      kind: MessageKind.text,
      status: group && to.isEmpty ? MessageStatus.delivered : MessageStatus.pending,
      text: t,
      senderId: identity.id,
      pendingTo: group ? to : null,
    );
    await store.addMessage(m);
    _afterQueued(to);
  }

  /// ينسخ الملف إلى مجلد التطبيق ثم يضعه في الطابور
  Future<void> sendFile(String chatId, String sourcePath, MessageKind kind, {String? mime}) async {
    final src = File(sourcePath);
    if (!await src.exists()) return;
    final id = newId();
    final ext = _ext(sourcePath, kind);
    final dir = Directory('${store.mediaDir}/$chatId');
    await dir.create(recursive: true);
    final dest = '${dir.path}/$id$ext';
    await src.copy(dest);
    final group = isGroupChat(chatId);
    final to = _recipients(chatId);
    final m = ChatMessage(
      id: id,
      chatId: chatId,
      mine: true,
      kind: kind,
      status: group && to.isEmpty ? MessageStatus.delivered : MessageStatus.pending,
      filePath: dest,
      fileName: '$id$ext',
      fileSize: await File(dest).length(),
      mime: mime,
      senderId: identity.id,
      pendingTo: group ? to : null,
    );
    await store.addMessage(m);
    _afterQueued(to);
  }

  void _afterQueued(List<String> peers) {
    for (final p in peers) {
      if (isLinked(p)) {
        pump(p);
      } else {
        ensureLink(p, force: true);
      }
    }
  }

  Future<void> resend(ChatMessage m) async {
    m.status = MessageStatus.pending;
    store.messageChanged(m);
    _afterQueued(m.isGroup ? (m.pendingTo ?? const []) : [m.chatId]);
  }

  /// رسالة تحكم مضمونة التسليم (تُعاد حتى يؤكد الطرف الآخر استلامها)
  void sendControl(String peerId, Map<String, dynamic> payload) {
    if (peerId == identity.id) return;
    store.enqueue(OutboxItem(
      id: newId(),
      peerId: peerId,
      peerKey: store.peer(peerId)?.publicKey,
      payload: payload,
    ));
    relay.watch(peerId);
    _afterQueued([peerId]);
  }

  void sendTyping(String chatId) {
    final group = isGroupChat(chatId);
    for (final p in _recipients(chatId)) {
      _links[p]?.sendCtl({'t': 'typing', if (group) 'g': groupIdOf(chatId)});
    }
  }

  void pump(String peerId) {
    _pumpText(peerId);
    _pumpFiles(peerId);
  }

  Future<void> _pumpText(String peerId) async {
    if (_pumpingText.contains(peerId)) {
      _rerunText.add(peerId);
      return;
    }
    _pumpingText.add(peerId);
    try {
      do {
        _rerunText.remove(peerId);
        // رسائل التحكم أولاً (قد تكون دعوة قروب لازمة قبل رسائله)
        for (final o in store.outboxFor(peerId)) {
          final l = _links[peerId];
          if (l == null || !l.isOpen) return;
          if (!await l.sendCtl({...o.payload, 'oid': o.id})) return;
        }
        final list = (await store.outgoingFor(peerId)).where((m) => m.kind == MessageKind.text).toList();
        for (final m in list) {
          final l = _links[peerId];
          if (l == null || !l.isOpen) return;
          final ok = await l.sendCtl({
            't': 'msg',
            'id': m.id,
            'text': m.text,
            'ts': m.time.millisecondsSinceEpoch,
            if (m.isGroup) 'g': groupIdOf(m.chatId),
          });
          if (!ok) return;
          if (!m.isGroup && m.status != MessageStatus.delivered) {
            m.status = MessageStatus.sent;
            store.messageChanged(m);
          }
        }
      } while (_rerunText.contains(peerId));
    } finally {
      _pumpingText.remove(peerId);
    }
  }

  Future<void> _pumpFiles(String peerId) async {
    if (_pumpingFiles.contains(peerId)) {
      _rerunFiles.add(peerId);
      return;
    }
    _pumpingFiles.add(peerId);
    try {
      do {
        _rerunFiles.remove(peerId);
        final list = (await store.outgoingFor(peerId)).where((m) => m.isFile).toList();
        for (final m in list) {
          final l = _links[peerId];
          if (l == null || !l.isOpen) return;
          if (!m.isGroup) {
            m.status = MessageStatus.sending;
            m.progress = 0;
            store.messageChanged(m, persist: false);
          }
          final ok = await l.sendFile(m, (p) {
            if (!m.isGroup) {
              m.progress = p;
              store.messageChanged(m, persist: false);
            }
          });
          if (!m.isGroup) {
            if (m.status != MessageStatus.delivered) {
              m.status = ok ? MessageStatus.sent : MessageStatus.pending;
            }
            store.messageChanged(m);
          }
          if (!ok) return;
        }
      } while (_rerunFiles.contains(peerId));
    } finally {
      _pumpingFiles.remove(peerId);
    }
  }

  // ----------------------------------------------------------------- الاستقبال
  /// يتحقق أن المرسل عضو في القروب ومسموح له بالإرسال
  Group? _groupFor(String peerId, Object? gid, {bool send = true}) {
    if (gid is! String) return null;
    final g = store.group(gid);
    if (g == null || g.left || !g.has(peerId) || !g.has(identity.id)) return null;
    if (send && g.adminsOnly && !g.isAdmin(peerId)) return null;
    return g;
  }

  Future<void> _onCtl(PeerLink l, Map<String, dynamic> d) async {
    final pid = l.peerId;
    final oid = d['oid'];
    switch (d['t']) {
      case 'msg':
        await _onText(l, d);
        break;
      case 'ack':
        await _onAck(pid, d);
        break;
      case 'profile':
        _onProfile(pid, d['name']);
        break;
      case 'typing':
        final g = _groupFor(pid, d['g']);
        final chatId = g != null ? g.chatId : pid;
        if (g == null && !store.hasContact(pid)) return;
        _typing[chatId] = (DateTime.now().add(const Duration(seconds: 4)), store.nameOf(pid));
        notifyListeners();
        _typingTimer?.cancel();
        _typingTimer = Timer(const Duration(seconds: 4), notifyListeners);
        break;
      case 'del':
        // حذف رسالة للجميع في محادثة فردية (فقط رسائل المرسل نفسه)
        final mid = d['mid'];
        if (mid is String && store.hasContact(pid)) {
          final m = await store.findMessage(pid, mid);
          if (m != null && !m.mine) await store.markDeleted(m);
        }
        break;
      default:
        final t = d['t'];
        if (t is String && t.startsWith('g_')) {
          await onGroupControl?.call(pid, d);
        }
    }
    if (oid is String) l.sendCtl({'t': 'ack', 'o': oid});
  }

  Future<void> _onText(PeerLink l, Map<String, dynamic> d) async {
    final pid = l.peerId;
    final id = d['id'] as String?;
    final text = d['text'] as String?;
    if (id == null || text == null) return;
    String chatId;
    String? senderName;
    if (d['g'] != null) {
      final g = _groupFor(pid, d['g']);
      if (g == null) return;
      chatId = g.chatId;
      senderName = store.nameOf(pid, fallback: g.member(pid)?.name ?? 'عضو');
    } else {
      if (!store.hasContact(pid)) return;
      chatId = pid;
    }
    _typing.remove(chatId);
    final exists = await store.findMessage(chatId, id);
    if (exists == null) {
      final m = ChatMessage(
        id: id,
        chatId: chatId,
        mine: false,
        kind: MessageKind.text,
        status: MessageStatus.received,
        text: text,
        senderId: pid,
        senderName: senderName,
        time: _time(d['ts']),
      );
      await store.addMessage(m, countUnread: activeChat != chatId);
      onIncoming?.call(m);
    }
    l.sendCtl({'t': 'ack', 'id': id, if (d['g'] != null) 'g': d['g']});
  }

  Future<void> _onAck(String pid, Map<String, dynamic> d) async {
    final oid = d['o'];
    if (oid is String) {
      store.dequeue(oid);
      return;
    }
    final id = d['id'] as String?;
    if (id == null) return;
    final gid = d['g'];
    if (gid is String) {
      final g = store.group(gid);
      if (g == null) return;
      final m = await store.findMessage(g.chatId, id);
      if (m == null || !m.mine) return;
      m.pendingTo?.remove(pid);
      final remaining = m.pendingTo?.length ?? 0;
      m.status = remaining == 0 ? MessageStatus.delivered : MessageStatus.sent;
      store.messageChanged(m);
      return;
    }
    final m = await store.findMessage(pid, id);
    if (m != null && m.mine) {
      m.status = MessageStatus.delivered;
      m.progress = 1;
      store.messageChanged(m);
    }
  }

  void _onProfile(String pid, Object? raw) {
    final name = raw is String ? raw.trim() : '';
    if (name.isEmpty) return;
    final c = store.contact(pid);
    if (c != null && c.name != name) {
      c.name = name;
      store.updateContact(c);
    }
    for (final g in store.sharedGroups(pid)) {
      final m = g.member(pid);
      if (m != null && m.name != name) {
        m.name = name;
        store.groupChanged(g);
      }
    }
  }

  Future<_IncomingFile?> _beginIncoming(PeerLink l, Map<String, dynamic> d) async {
    final pid = l.peerId;
    final id = d['id'] as String?;
    if (id == null) return null;
    String chatId;
    String? senderName;
    if (d['g'] != null) {
      final g = _groupFor(pid, d['g']);
      if (g == null) return null;
      chatId = g.chatId;
      senderName = store.nameOf(pid, fallback: g.member(pid)?.name ?? 'عضو');
    } else {
      if (!store.hasContact(pid)) return null;
      chatId = pid;
    }
    final kind = d['kind'] == 'video' ? MessageKind.video : MessageKind.image;
    final size = (d['size'] as int?) ?? 0;
    final existing = await store.findMessage(chatId, id);
    if (existing != null && (existing.status == MessageStatus.received || existing.deleted)) {
      return _IncomingFile(this, l, existing, size, discard: true);
    }
    final dir = Directory('${store.mediaDir}/$chatId');
    await dir.create(recursive: true);
    final name = (d['name'] as String?) ?? '$id${kind == MessageKind.video ? '.mp4' : '.jpg'}';
    final safe = name.replaceAll(RegExp(r'[^A-Za-z0-9_.\-]'), '_');
    final path = '${dir.path}/$safe';
    if (existing != null) {
      existing.status = MessageStatus.receiving;
      existing.progress = 0;
      existing.filePath = path;
      store.messageChanged(existing, persist: false);
      return _IncomingFile(this, l, existing, size);
    }
    final m = ChatMessage(
      id: id,
      chatId: chatId,
      mine: false,
      kind: kind,
      status: MessageStatus.receiving,
      time: _time(d['ts']),
      filePath: path,
      fileName: safe,
      fileSize: size,
      mime: d['mime'] as String?,
      text: d['cap'] as String?,
      senderId: pid,
      senderName: senderName,
    );
    await store.addMessage(m, countUnread: activeChat != chatId);
    onIncoming?.call(m);
    return _IncomingFile(this, l, m, size);
  }

  DateTime _time(Object? ts) {
    if (ts is int) {
      final t = DateTime.fromMillisecondsSinceEpoch(ts);
      // لا نقبل وقتاً في المستقبل البعيد
      if (t.isBefore(DateTime.now().add(const Duration(minutes: 5)))) return t;
    }
    return DateTime.now();
  }

  String _ext(String path, MessageKind kind) {
    final dot = path.lastIndexOf('.');
    if (dot > 0 && path.length - dot <= 6) return path.substring(dot).toLowerCase();
    return kind == MessageKind.video ? '.mp4' : '.jpg';
  }

  void broadcastProfile() {
    for (final l in _links.values) {
      l.sendCtl({'t': 'profile', 'name': identity.name});
    }
  }

  void closeAll() {
    for (final l in _links.values.toList()) {
      l.close();
    }
    _links.clear();
  }

  void closeLink(String peerId) => _links[peerId]?.close();
}
