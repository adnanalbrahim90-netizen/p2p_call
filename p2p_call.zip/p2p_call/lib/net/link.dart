import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import 'relay.dart';
import 'rtc.dart';

enum LinkState { connecting, open, closed }

/// قناة بيانات مباشرة (P2P) مع جهة اتصال واحدة:
///  • ctl  : الرسائل النصية والإشعارات الصغيرة
///  • file : نقل الصور ومقاطع الفيديو على شكل أجزاء
class PeerLink {
  PeerLink(this._m, this.contact, {required this.initiator, required this.sid});

  final LinkManager _m;
  final Contact contact;
  final bool initiator;
  final String sid;

  RTCPeerConnection? _pc;
  RTCDataChannel? _ctl;
  RTCDataChannel? _file;
  final IceGatherer _ice = IceGatherer();
  LinkState state = LinkState.connecting;
  bool wasOpen = false;
  Timer? _connectTimeout;
  Timer? _disconnectTimer;
  DateTime lastActivity = DateTime.now();

  Future<void> _fileChain = Future<void>.value();
  _IncomingFile? _rx;

  bool get isOpen => state == LinkState.open;
  bool get isClosed => state == LinkState.closed;

  static const int chunkSize = 32 * 1024;
  static const int maxBuffered = 1024 * 1024;

  Future<void> _createPc() async {
    final pc = await createPeerConnection(rtcConfiguration);
    _pc = pc;
    pc.onIceGatheringState = _ice.onState;
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          s == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
        close();
      } else if (s ==
          RTCPeerConnectionState.RTCPeerConnectionStateDisconnected) {
        _disconnectTimer?.cancel();
        _disconnectTimer = Timer(const Duration(seconds: 12), close);
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        _disconnectTimer?.cancel();
      }
    };
    pc.onDataChannel = _bind;
    _connectTimeout = Timer(const Duration(seconds: 25), () {
      if (state == LinkState.connecting) close();
    });
  }

  /// الطرف البادئ: إنشاء القنوات وإرسال العرض عبر الوسيط
  Future<void> start() async {
    try {
      await _createPc();
      final pc = _pc!;
      _bind(await pc.createDataChannel('ctl', RTCDataChannelInit()..ordered = true));
      _bind(await pc.createDataChannel('file', RTCDataChannelInit()..ordered = true));
      final offer = await pc.createOffer({});
      final local = await _ice.setLocalAndWait(pc, offer);
      if (isClosed) return;
      final ok = await _m.relay.send(contact.publicKey, {
        't': 'link_offer',
        'sid': sid,
        'sdp': local.sdp,
      });
      if (!ok) close();
    } catch (e) {
      debugPrint('link start failed: $e');
      close();
    }
  }

  /// الطرف المستقبل: قبول العرض وإرسال الرد
  Future<void> accept(String sdp) async {
    try {
      await _createPc();
      final pc = _pc!;
      await pc.setRemoteDescription(RTCSessionDescription(sdp, 'offer'));
      final answer = await pc.createAnswer({});
      final local = await _ice.setLocalAndWait(pc, answer);
      if (isClosed) return;
      final ok = await _m.relay.send(contact.publicKey, {
        't': 'link_answer',
        'sid': sid,
        'sdp': local.sdp,
      });
      if (!ok) close();
    } catch (e) {
      debugPrint('link accept failed: $e');
      close();
    }
  }

  Future<void> applyAnswer(String sdp) async {
    try {
      await _pc?.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
    } catch (e) {
      debugPrint('link answer failed: $e');
      close();
    }
  }

  void _bind(RTCDataChannel dc) {
    if (dc.label == 'ctl') {
      _ctl = dc;
      dc.onMessage = (msg) {
        lastActivity = DateTime.now();
        if (msg.isBinary) return;
        try {
          final data = jsonDecode(msg.text);
          if (data is Map<String, dynamic>) _m._onCtl(this, data);
        } catch (_) {}
      };
    } else if (dc.label == 'file') {
      _file = dc;
      dc.bufferedAmountLowThreshold = maxBuffered ~/ 2;
      dc.onMessage = (msg) {
        lastActivity = DateTime.now();
        _fileChain = _fileChain.then((_) => _onFileMessage(msg)).catchError((Object e) {
          debugPrint('file rx error: $e');
        });
      };
    } else {
      return;
    }
    dc.onDataChannelState = (_) => _checkOpen();
    _checkOpen();
  }

  void _checkOpen() {
    if (isClosed) return;
    final ctlOpen = _ctl?.state == RTCDataChannelState.RTCDataChannelOpen;
    final fileOpen = _file?.state == RTCDataChannelState.RTCDataChannelOpen;
    if (ctlOpen && fileOpen && state == LinkState.connecting) {
      state = LinkState.open;
      wasOpen = true;
      _connectTimeout?.cancel();
      _m._onOpen(this);
    }
    final ctlClosed = _ctl?.state == RTCDataChannelState.RTCDataChannelClosed;
    final fileClosed = _file?.state == RTCDataChannelState.RTCDataChannelClosed;
    if (state == LinkState.open && (ctlClosed || fileClosed)) close();
  }

  // ----------------------------------------------------------------- الإرسال
  Future<bool> sendCtl(Map<String, dynamic> data) async {
    final dc = _ctl;
    if (!isOpen || dc == null) return false;
    try {
      await dc.send(RTCDataChannelMessage(jsonEncode(data)));
      lastActivity = DateTime.now();
      return true;
    } catch (e) {
      debugPrint('ctl send failed: $e');
      return false;
    }
  }

  Future<bool> sendFile(ChatMessage m, void Function(double p) onProgress) async {
    final dc = _file;
    final path = m.filePath;
    if (!isOpen || dc == null || path == null) return false;
    final f = File(path);
    if (!await f.exists()) return false;
    final size = await f.length();
    RandomAccessFile? raf;
    try {
      await dc.send(RTCDataChannelMessage(jsonEncode({
        't': 'file',
        'id': m.id,
        'kind': m.kind.name,
        'name': m.fileName,
        'size': size,
        'mime': m.mime,
        'ts': m.time.millisecondsSinceEpoch,
        if (m.text != null) 'cap': m.text,
      })));
      raf = await f.open();
      var sent = 0;
      var lastReport = -1.0;
      while (sent < size) {
        if (!isOpen) return false;
        var waited = 0;
        while ((dc.bufferedAmount ?? 0) > maxBuffered) {
          await Future<void>.delayed(const Duration(milliseconds: 15));
          if (!isOpen) return false;
          if (++waited > 2000) return false; // ~30 ثانية بلا تقدم
        }
        final chunk = await raf.read(min(chunkSize, size - sent));
        if (chunk.isEmpty) break;
        await dc.send(RTCDataChannelMessage.fromBinary(chunk));
        sent += chunk.length;
        lastActivity = DateTime.now();
        final p = sent / size;
        if (p - lastReport >= 0.01 || sent >= size) {
          lastReport = p;
          onProgress(p);
        }
      }
      await dc.send(RTCDataChannelMessage(jsonEncode({'t': 'file_end', 'id': m.id})));
      return true;
    } catch (e) {
      debugPrint('file send failed: $e');
      return false;
    } finally {
      await raf?.close();
    }
  }

  // ----------------------------------------------------------------- الاستقبال
  Future<void> _onFileMessage(RTCDataChannelMessage msg) async {
    if (msg.isBinary) {
      _rx?.add(msg.binary);
      return;
    }
    Map<String, dynamic> data;
    try {
      data = jsonDecode(msg.text) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final t = data['t'];
    if (t == 'file') {
      await _rx?.abort();
      _rx = await _m._beginIncoming(this, data);
    } else if (t == 'file_end') {
      final rx = _rx;
      _rx = null;
      if (rx != null && rx.id == data['id']) await rx.finish();
    }
  }

  void close() {
    if (isClosed) return;
    state = LinkState.closed;
    _connectTimeout?.cancel();
    _disconnectTimer?.cancel();
    final rx = _rx;
    _rx = null;
    rx?.abort();
    try {
      _ctl?.close();
    } catch (_) {}
    try {
      _file?.close();
    } catch (_) {}
    try {
      _pc?.close();
    } catch (_) {}
    _pc = null;
    _m._onClosed(this);
  }
}

/// ملف قيد الاستلام
class _IncomingFile {
  _IncomingFile(this._m, this.link, this.message, this.size, {this.discard = false})
      : id = message.id {
    if (!discard) _sink = File(message.filePath!).openWrite();
  }

  final LinkManager _m;
  final PeerLink link;
  final ChatMessage message;
  final String id;
  final int size;
  final bool discard;
  IOSink? _sink;
  int received = 0;
  double _lastReport = 0;

  void add(Uint8List chunk) {
    received += chunk.length;
    if (discard) return;
    _sink?.add(chunk);
    if (size > 0) {
      final p = received / size;
      if (p - _lastReport >= 0.02) {
        _lastReport = p;
        message.progress = p.clamp(0.0, 1.0);
        _m.store.messageChanged(message, persist: false);
      }
    }
  }

  Future<void> finish() async {
    if (!discard) {
      await _sink?.flush();
      await _sink?.close();
      message.status = MessageStatus.received;
      message.progress = 1;
      message.fileSize = received;
      _m.store.messageChanged(message);
    }
    await link.sendCtl({'t': 'ack', 'id': id});
  }

  Future<void> abort() async {
    if (discard) return;
    try {
      await _sink?.close();
    } catch (_) {}
    message.status = MessageStatus.failed;
    _m.store.messageChanged(message);
  }
}

/// يدير القنوات المباشرة لكل جهات الاتصال وطابور الرسائل الصادرة
class LinkManager extends ChangeNotifier {
  LinkManager(this.identity, this.store, this.relay);

  final Identity identity;
  final Store store;
  final Relay relay;

  final Map<String, PeerLink> _links = {};
  final Map<String, DateTime> _lastAttempt = {};
  final Map<String, int> _failures = {};
  final Map<String, DateTime> _nextAllowed = {};
  final Map<String, DateTime> _typingUntil = {};
  final Set<String> _pumpingText = {};
  final Set<String> _pumpingFiles = {};
  final Set<String> _rerunText = {};
  final Set<String> _rerunFiles = {};
  Timer? _typingTimer;

  /// المحادثة المفتوحة حالياً (لعدم احتساب رسائلها كغير مقروءة)
  String? activeChat;

  PeerLink? link(String contactId) => _links[contactId];

  bool isLinked(String contactId) => _links[contactId]?.isOpen ?? false;

  bool isConnecting(String contactId) =>
      _links[contactId]?.state == LinkState.connecting;

  /// متصل: إما عبر الوسيط أو عبر قناة مباشرة مفتوحة
  bool isReachable(String contactId) =>
      relay.isOnline(contactId) || isLinked(contactId);

  bool isTyping(String contactId) {
    final until = _typingUntil[contactId];
    return until != null && until.isAfter(DateTime.now());
  }

  // ----------------------------------------------------------------- إنشاء القنوات
  /// يفتح قناة مباشرة إن كان الطرف الآخر متصلاً ولا توجد قناة.
  /// [force] لإجراءات المستخدم (إرسال رسالة / فتح المحادثة) فيتجاوز فترة الانتظار.
  void ensureLink(String contactId, {bool force = false}) {
    final c = store.contact(contactId);
    // لا نفتح قناة قبل أن يقبل الطرف الآخر طلب الإضافة
    if (c == null || !c.confirmed) return;
    final existing = _links[contactId];
    if (existing != null && !existing.isClosed) return;
    if (!relay.isOnline(contactId) || relay.connectedCount == 0) return;
    final now = DateTime.now();
    final last = _lastAttempt[contactId];
    if (last != null && now.difference(last).inSeconds < (force ? 3 : 8)) return;
    final next = _nextAllowed[contactId];
    if (!force && next != null && now.isBefore(next)) return;
    _lastAttempt[contactId] = now;
    final l = PeerLink(this, c, initiator: true, sid: newId(8));
    _links[contactId] = l;
    notifyListeners();
    l.start();
  }

  /// معالجة رسائل الوسيط الخاصة بالقنوات
  void onRelay(RelayMessage m) {
    final c = store.contact(m.senderId);
    if (c == null) return;
    final sid = m.data['sid'] as String?;
    final sdp = m.data['sdp'] as String?;
    if (sid == null || sdp == null) return;

    if (m.type == 'link_offer') {
      final existing = _links[c.id];
      if (existing != null && !existing.isClosed) {
        // تصادم: الطرفان بدآ معاً — المعرّف الأصغر يحتفظ بعرضه
        if (existing.state == LinkState.connecting &&
            existing.initiator &&
            identity.id.compareTo(c.id) < 0) {
          return;
        }
        existing.close();
      }
      final l = PeerLink(this, c, initiator: false, sid: sid);
      _links[c.id] = l;
      notifyListeners();
      l.accept(sdp);
    } else if (m.type == 'link_answer') {
      final l = _links[c.id];
      if (l != null && l.initiator && l.sid == sid && !l.isClosed) {
        l.applyAnswer(sdp);
      }
    }
  }

  void onPresence(String contactId) {
    if (relay.isOnline(contactId)) {
      // ظروف شبكة جديدة: نلغي فترة الانتظار
      _failures.remove(contactId);
      _nextAllowed.remove(contactId);
      _maybeConnectFor(contactId);
    }
    notifyListeners();
  }

  Future<void> _maybeConnectFor(String contactId) async {
    if (activeChat == contactId || await store.hasOutgoing(contactId)) {
      ensureLink(contactId);
    }
  }

  /// محاولة دورية لكل من لديه رسائل معلقة
  Future<void> retryAll() async {
    for (final c in store.contacts) {
      if (relay.isOnline(c.id) && !isLinked(c.id)) {
        await _maybeConnectFor(c.id);
      }
    }
  }

  /// يُستدعى عند فتح قناة مباشرة (دليل أن الطرف الآخر يعرفنا)
  void Function(String contactId)? onLinked;

  void _onOpen(PeerLink l) {
    if (_links[l.contact.id] != l) {
      l.close();
      return;
    }
    onLinked?.call(l.contact.id);
    l.sendCtl({'t': 'profile', 'name': identity.name});
    notifyListeners();
    pump(l.contact.id);
  }

  void _onClosed(PeerLink l) {
    if (_links[l.contact.id] == l) {
      final id = l.contact.id;
      _links.remove(id);
      notifyListeners();
      // تراجع تدريجي عند الفشل المتكرر (شبكات تمنع الاتصال المباشر)
      var delay = const Duration(seconds: 3);
      if (l.wasOpen) {
        _failures.remove(id);
        _nextAllowed.remove(id);
      } else {
        final n = (_failures[id] ?? 0) + 1;
        _failures[id] = n;
        delay = Duration(seconds: (15 * n).clamp(15, 180));
        _nextAllowed[id] = DateTime.now().add(delay);
      }
      Timer(delay, () => _maybeConnectFor(id));
    }
  }

  // ----------------------------------------------------------------- الإرسال
  Future<void> sendText(String contactId, String text) async {
    final t = text.trim();
    if (t.isEmpty) return;
    final m = ChatMessage(
      id: newId(),
      contactId: contactId,
      mine: true,
      kind: MessageKind.text,
      status: MessageStatus.pending,
      text: t,
    );
    await store.addMessage(m);
    _afterQueued(contactId);
  }

  /// ينسخ الملف إلى مجلد التطبيق ثم يضعه في الطابور
  Future<void> sendFile(String contactId, String sourcePath, MessageKind kind,
      {String? mime}) async {
    final src = File(sourcePath);
    if (!await src.exists()) return;
    final id = newId();
    final ext = _ext(sourcePath, kind);
    final dir = Directory('${store.mediaDir}/$contactId');
    await dir.create(recursive: true);
    final dest = '${dir.path}/$id$ext';
    await src.copy(dest);
    final m = ChatMessage(
      id: id,
      contactId: contactId,
      mine: true,
      kind: kind,
      status: MessageStatus.pending,
      filePath: dest,
      fileName: '$id$ext',
      fileSize: await File(dest).length(),
      mime: mime,
    );
    await store.addMessage(m);
    _afterQueued(contactId);
  }

  void _afterQueued(String contactId) {
    if (isLinked(contactId)) {
      pump(contactId);
    } else {
      ensureLink(contactId, force: true);
    }
  }

  Future<void> resend(ChatMessage m) async {
    m.status = MessageStatus.pending;
    store.messageChanged(m);
    _afterQueued(m.contactId);
  }

  void sendTyping(String contactId) {
    _links[contactId]?.sendCtl({'t': 'typing'});
  }

  void pump(String contactId) {
    _pumpText(contactId);
    _pumpFiles(contactId);
  }

  Future<void> _pumpText(String contactId) async {
    if (_pumpingText.contains(contactId)) {
      _rerunText.add(contactId);
      return;
    }
    _pumpingText.add(contactId);
    try {
      do {
        _rerunText.remove(contactId);
        final list = (await store.outgoingToSend(contactId))
            .where((m) => m.kind == MessageKind.text)
            .toList();
        for (final m in list) {
          final l = _links[contactId];
          if (l == null || !l.isOpen) return;
          final ok = await l.sendCtl({
            't': 'msg',
            'id': m.id,
            'text': m.text,
            'ts': m.time.millisecondsSinceEpoch,
          });
          if (!ok) return;
          if (m.status != MessageStatus.delivered) {
            m.status = MessageStatus.sent;
            store.messageChanged(m);
          }
        }
      } while (_rerunText.contains(contactId));
    } finally {
      _pumpingText.remove(contactId);
    }
  }

  Future<void> _pumpFiles(String contactId) async {
    if (_pumpingFiles.contains(contactId)) {
      _rerunFiles.add(contactId);
      return;
    }
    _pumpingFiles.add(contactId);
    try {
      do {
        _rerunFiles.remove(contactId);
        final list = (await store.outgoingToSend(contactId))
            .where((m) => m.isFile)
            .toList();
        for (final m in list) {
          final l = _links[contactId];
          if (l == null || !l.isOpen) return;
          m.status = MessageStatus.sending;
          m.progress = 0;
          store.messageChanged(m, persist: false);
          final ok = await l.sendFile(m, (p) {
            m.progress = p;
            store.messageChanged(m, persist: false);
          });
          if (m.status != MessageStatus.delivered) {
            m.status = ok ? MessageStatus.sent : MessageStatus.pending;
          }
          store.messageChanged(m);
          if (!ok) return;
        }
      } while (_rerunFiles.contains(contactId));
    } finally {
      _pumpingFiles.remove(contactId);
    }
  }

  // ----------------------------------------------------------------- الاستقبال
  Future<void> _onCtl(PeerLink l, Map<String, dynamic> d) async {
    final cid = l.contact.id;
    switch (d['t']) {
      case 'msg':
        final id = d['id'] as String?;
        final text = d['text'] as String?;
        if (id == null || text == null) return;
        _typingUntil.remove(cid);
        final exists = await store.findMessage(cid, id);
        if (exists == null) {
          await store.addMessage(
            ChatMessage(
              id: id,
              contactId: cid,
              mine: false,
              kind: MessageKind.text,
              status: MessageStatus.received,
              text: text,
              time: _time(d['ts']),
            ),
            countUnread: activeChat != cid,
          );
          onIncoming?.call(cid);
        }
        l.sendCtl({'t': 'ack', 'id': id});
        break;
      case 'ack':
        final id = d['id'] as String?;
        if (id == null) return;
        final m = await store.findMessage(cid, id);
        if (m != null && m.mine) {
          m.status = MessageStatus.delivered;
          m.progress = 1;
          store.messageChanged(m);
        }
        break;
      case 'profile':
        final name = (d['name'] as String?)?.trim();
        if (name != null && name.isNotEmpty && name != l.contact.name) {
          l.contact.name = name;
          store.updateContact(l.contact);
        }
        break;
      case 'typing':
        _typingUntil[cid] = DateTime.now().add(const Duration(seconds: 4));
        notifyListeners();
        _typingTimer?.cancel();
        _typingTimer = Timer(const Duration(seconds: 4), notifyListeners);
        break;
    }
  }

  /// يُستدعى عند وصول رسالة جديدة (للاهتزاز/التنبيه داخل التطبيق)
  void Function(String contactId)? onIncoming;

  Future<_IncomingFile?> _beginIncoming(PeerLink l, Map<String, dynamic> d) async {
    final cid = l.contact.id;
    final id = d['id'] as String?;
    if (id == null) return null;
    final kind = d['kind'] == 'video' ? MessageKind.video : MessageKind.image;
    final size = (d['size'] as int?) ?? 0;
    final existing = await store.findMessage(cid, id);
    if (existing != null && existing.status == MessageStatus.received) {
      return _IncomingFile(this, l, existing, size, discard: true);
    }
    final dir = Directory('${store.mediaDir}/$cid');
    await dir.create(recursive: true);
    final name = (d['name'] as String?) ?? '$id${kind == MessageKind.video ? '.mp4' : '.jpg'}';
    final safe = name.replaceAll(RegExp(r'[^A-Za-z0-9_.\-]'), '_');
    final path = '${dir.path}/$safe';
    if (existing != null) {
      existing.status = MessageStatus.receiving;
      existing.progress = 0;
      existing.filePath = path;
      store.messageChanged(existing, persist: false);
      return _IncomingFile(this, l, existing, size);
    }
    final m = ChatMessage(
      id: id,
      contactId: cid,
      mine: false,
      kind: kind,
      status: MessageStatus.receiving,
      time: _time(d['ts']),
      filePath: path,
      fileName: safe,
      fileSize: size,
      mime: d['mime'] as String?,
      text: d['cap'] as String?,
    );
    await store.addMessage(m, countUnread: activeChat != cid);
    onIncoming?.call(cid);
    return _IncomingFile(this, l, m, size);
  }

  DateTime _time(Object? ts) {
    if (ts is int) {
      final t = DateTime.fromMillisecondsSinceEpoch(ts);
      // لا نقبل وقتاً في المستقبل البعيد
      if (t.isBefore(DateTime.now().add(const Duration(minutes: 5)))) return t;
    }
    return DateTime.now();
  }

  String _ext(String path, MessageKind kind) {
    final dot = path.lastIndexOf('.');
    if (dot > 0 && path.length - dot <= 6) return path.substring(dot).toLowerCase();
    return kind == MessageKind.video ? '.mp4' : '.jpg';
  }

  void closeAll() {
    for (final l in _links.values.toList()) {
      l.close();
    }
    _links.clear();
  }

  void closeLink(String contactId) => _links[contactId]?.close();
}
