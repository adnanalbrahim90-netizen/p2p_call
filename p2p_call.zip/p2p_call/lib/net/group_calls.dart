import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import 'calls.dart';
import 'native.dart';
import 'relay.dart';
import 'rtc.dart';

/// مشارك في مكالمة جماعية (اتصال مباشر مستقل لكل مشارك)
class GroupCallPeer {
  GroupCallPeer(this.id, this.name);

  final String id;
  final String name;
  RTCPeerConnection? pc;
  final RTCVideoRenderer renderer = RTCVideoRenderer();
  final IceGatherer ice = IceGatherer();
  MediaStream? fallback;
  bool rendererReady = false;
  bool connected = false;
  bool hasVideo = false;
  bool camOn = true;
  bool offerer = false;
  bool restarting = false;
  Timer? timeout;
  Timer? recover;

  Future<void> dispose() async {
    timeout?.cancel();
    recover?.cancel();
    try {
      await pc?.close();
    } catch (_) {}
    pc = null;
    try {
      renderer.srcObject = null;
      if (rendererReady) await renderer.dispose();
    } catch (_) {}
  }
}

enum GroupCallPhase {
  /// وارد: يرن بانتظار الانضمام
  ringing,

  /// أنا داخل المكالمة
  joined,

  /// انتهت بالنسبة لي
  ended,
}

class GroupCallSession extends ChangeNotifier {
  GroupCallSession({
    required this.group,
    required this.gcid,
    required this.video,
    required this.startedByMe,
    required this.inviterId,
  });

  final Group group;
  final String gcid;
  final bool video;
  final bool startedByMe;
  final String inviterId;

  GroupCallPhase phase = GroupCallPhase.ringing;
  String? endReason;
  DateTime? joinedAt;
  DateTime? firstPeerAt;
  bool everHadPeers = false;

  final Map<String, GroupCallPeer> peers = {};
  final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  bool localReady = false;
  MediaStream? localStream;

  bool micOn = true;
  late bool camOn = video;
  late bool speakerOn = true;
  bool frontCamera = true;
  bool _disposed = false;

  Duration get elapsed =>
      firstPeerAt == null ? Duration.zero : DateTime.now().difference(firstPeerAt!);

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    for (final p in peers.values) {
      p.dispose();
    }
    peers.clear();
    for (final t in localStream?.getTracks() ?? const <MediaStreamTrack>[]) {
      try {
        t.stop();
      } catch (_) {}
    }
    try {
      localStream?.dispose();
    } catch (_) {}
    try {
      localRenderer.srcObject = null;
      if (localReady) localRenderer.dispose();
    } catch (_) {}
    super.dispose();
  }
}

/// المكالمات الجماعية (صوت/فيديو) بشبكة مباشرة بين كل المشاركين.
///
/// البروتوكول عبر الوسيط (مشفّر طرفاً لطرف):
///  gc_invite → يرن عند الأعضاء
///  gc_join   → المنضم يعلن دخوله لكل الأعضاء
///  gc_here   → الموجودون يردّون عليه
///  gc_offer / gc_answer → اتصال مباشر لكل زوج (صاحب المعرّف الأصغر يبدأ)
///  gc_leave / gc_cancel / gc_cam
class GroupCallManager extends ChangeNotifier {
  GroupCallManager(this.identity, this.store, this.relay);

  final Identity identity;
  final Store store;
  final Relay relay;

  static const int maxParticipants = 6;

  GroupCallSession? current;
  Timer? _ringTimeout;
  Timer? _lonelyTimer;

  /// هل توجد مكالمة فردية جارية
  bool Function()? otherBusy;

  /// عرض شاشة المكالمة الجماعية
  void Function(GroupCallSession s)? onShow;

  /// مكالمات جماعية نشطة رأيناها مؤخراً (للانضمام المتأخر): معرّف القروب → الدعوة
  final Map<String, (String gcid, bool video, DateTime at)> active = {};

  String get me => identity.id;

  bool get busy => current != null && current!.phase != GroupCallPhase.ended;

  String? activeCallIn(String groupId) {
    final a = active[groupId];
    if (a == null) return null;
    if (DateTime.now().difference(a.$3).inMinutes > 60) {
      active.remove(groupId);
      return null;
    }
    return a.$1;
  }

  // ------------------------------------------------------------------ البدء والانضمام
  Future<String?> start(Group g, {required bool video}) async {
    if (busy || (otherBusy?.call() ?? false)) return 'لديك مكالمة جارية بالفعل';
    if (g.left) return 'لم تعد عضواً في هذا القروب';
    if (relay.connectedCount == 0) return 'لا يوجد اتصال بالإنترنت';
    final s = GroupCallSession(group: g, gcid: newId(8), video: video, startedByMe: true, inviterId: me)
      ..phase = GroupCallPhase.joined
      ..joinedAt = DateTime.now();
    current = s;
    active[g.id] = (s.gcid, video, DateTime.now());
    notifyListeners();
    onShow?.call(s);
    try {
      await _openMedia(s);
    } catch (e) {
      _end(s, 'تعذّر تشغيل الكاميرا أو الميكروفون', CallResult.failed);
      return null;
    }
    _toMembers(g, {'t': 'gc_invite', 'cid': s.gcid, 'g': g.id, 'video': video});
    NativeBridge.keepScreenOn(true);
    NativeBridge.setInCall(true, video: video);
    _ringTimeout = Timer(const Duration(seconds: 50), () {
      if (s.phase == GroupCallPhase.joined && s.peers.isEmpty) {
        _toMembers(g, {'t': 'gc_cancel', 'cid': s.gcid, 'g': g.id});
        _end(s, 'لم ينضم أحد', CallResult.missed);
      }
    });
    return null;
  }

  /// الانضمام لمكالمة جارية (من الرنين أو من شريط "انضم" في القروب)
  Future<String?> join({GroupCallSession? ringing, Group? group, String? gcid, bool? video}) async {
    GroupCallSession s;
    if (ringing != null) {
      s = ringing;
    } else {
      if (busy || (otherBusy?.call() ?? false)) return 'لديك مكالمة جارية بالفعل';
      if (group == null || gcid == null) return null;
      s = GroupCallSession(group: group, gcid: gcid, video: video ?? false, startedByMe: false, inviterId: '');
      current = s;
      notifyListeners();
      onShow?.call(s);
    }
    NativeBridge.stopRinging();
    NativeBridge.cancelCallNotification();
    _ringTimeout?.cancel();
    s.phase = GroupCallPhase.joined;
    s.joinedAt = DateTime.now();
    s.notifyListeners();
    try {
      await _openMedia(s);
    } catch (e) {
      _end(s, 'تعذّر تشغيل الكاميرا أو الميكروفون', CallResult.failed);
      return null;
    }
    NativeBridge.keepScreenOn(true);
    NativeBridge.setInCall(true, video: s.video);
    _toMembers(s.group, {'t': 'gc_join', 'cid': s.gcid, 'g': s.group.id, 'video': s.video});
    // إن لم يرد أحد خلال 15 ثانية فالمكالمة انتهت
    _lonelyTimer?.cancel();
    _lonelyTimer = Timer(const Duration(seconds: 15), () {
      if (s.phase == GroupCallPhase.joined && s.peers.isEmpty) {
        active.remove(s.group.id);
        _end(s, 'انتهت المكالمة الجماعية', CallResult.missed);
      }
    });
    return null;
  }

  void decline() {
    final s = current;
    if (s == null || s.phase != GroupCallPhase.ringing) return;
    _end(s, 'تم الرفض', CallResult.declined);
  }

  void leave() {
    final s = current;
    if (s == null || s.phase == GroupCallPhase.ended) return;
    if (s.phase == GroupCallPhase.ringing) {
      decline();
      return;
    }
    for (final id in s.peers.keys) {
      relay.sendTo(store.peer(id)?.publicKey, {'t': 'gc_leave', 'cid': s.gcid, 'g': s.group.id});
    }
    if (s.peers.isEmpty && s.startedByMe) {
      _toMembers(s.group, {'t': 'gc_cancel', 'cid': s.gcid, 'g': s.group.id});
      active.remove(s.group.id);
    }
    _end(s, 'غادرت المكالمة', CallResult.answered);
  }

  // ------------------------------------------------------------------ أدوات التحكم
  void toggleMic() {
    final s = current;
    if (s == null) return;
    s.micOn = !s.micOn;
    for (final t in s.localStream?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = s.micOn;
    }
    s.notifyListeners();
  }

  void toggleCamera() {
    final s = current;
    if (s == null || !s.video) return;
    s.camOn = !s.camOn;
    for (final t in s.localStream?.getVideoTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = s.camOn;
    }
    for (final id in s.peers.keys) {
      relay.sendTo(store.peer(id)?.publicKey, {'t': 'gc_cam', 'cid': s.gcid, 'g': s.group.id, 'on': s.camOn});
    }
    s.notifyListeners();
  }

  Future<void> switchCamera() async {
    final s = current;
    final tracks = s?.localStream?.getVideoTracks() ?? const <MediaStreamTrack>[];
    if (s == null || tracks.isEmpty) return;
    try {
      await Helper.switchCamera(tracks.first);
      s.frontCamera = !s.frontCamera;
      s.notifyListeners();
    } catch (_) {}
  }

  Future<void> toggleSpeaker() async {
    final s = current;
    if (s == null) return;
    s.speakerOn = !s.speakerOn;
    try {
      await Helper.setSpeakerphoneOn(s.speakerOn);
    } catch (_) {}
    s.notifyListeners();
  }

  // ------------------------------------------------------------------ رسائل الوسيط
  Future<void> onRelay(RelayMessage m) async {
    final gid = m.data['g'];
    final cid = m.data['cid'];
    if (gid is! String || cid is! String) return;
    final g = store.group(gid);
    if (g == null || g.left || !g.has(m.senderId) || !g.has(me)) return;
    final from = m.senderId;
    final s = current;
    final inThis = s != null && s.gcid == cid && s.phase != GroupCallPhase.ended;

    switch (m.type) {
      case 'gc_invite':
        active[g.id] = (cid, m.data['video'] == true, DateTime.now());
        store.notifyListeners();
        if (inThis) return;
        if (busy || (otherBusy?.call() ?? false)) return;
        final ring = GroupCallSession(
          group: g,
          gcid: cid,
          video: m.data['video'] == true,
          startedByMe: false,
          inviterId: from,
        );
        current = ring;
        notifyListeners();
        NativeBridge.startRinging();
        NativeBridge.keepScreenOn(true);
        onShow?.call(ring);
        _ringTimeout?.cancel();
        _ringTimeout = Timer(const Duration(seconds: 45), () {
          if (ring.phase == GroupCallPhase.ringing) _end(ring, 'مكالمة جماعية فائتة', CallResult.missed);
        });
        break;

      case 'gc_cancel':
        active.remove(g.id);
        store.notifyListeners();
        if (inThis && s.phase == GroupCallPhase.ringing) _end(s, 'انتهت المكالمة', CallResult.missed);
        break;

      case 'gc_join':
        active[g.id] = (cid, m.data['video'] == true, DateTime.now());
        if (!inThis || s.phase != GroupCallPhase.joined) return;
        if (s.peers.containsKey(from)) return;
        if (s.peers.length + 1 >= maxParticipants) {
          relay.sendTo(store.peer(from)?.publicKey, {'t': 'gc_full', 'cid': cid, 'g': gid});
          return;
        }
        if (me.compareTo(from) < 0) {
          await _offerTo(s, from);
        } else {
          relay.sendTo(store.peer(from)?.publicKey, {'t': 'gc_here', 'cid': cid, 'g': gid});
        }
        break;

      case 'gc_here':
        if (!inThis || s.phase != GroupCallPhase.joined) return;
        if (s.peers.containsKey(from)) return;
        if (me.compareTo(from) < 0) {
          await _offerTo(s, from);
        } else {
          // نطلب منه أن يبدأ هو (صاحب المعرّف الأصغر)
          relay.sendTo(store.peer(from)?.publicKey, {'t': 'gc_join', 'cid': cid, 'g': gid, 'video': s.video});
        }
        break;

      case 'gc_full':
        if (inThis && s.peers.isEmpty) _end(s, 'المكالمة ممتلئة (الحد ${maxParticipants} مشاركين)', CallResult.failed);
        break;

      case 'gc_offer':
        final sdp = m.data['sdp'] as String?;
        if (!inThis || s.phase != GroupCallPhase.joined || sdp == null) return;
        await _answer(s, from, sdp, shared: m.data['ice']);
        break;

      case 'gc_restart':
        final rp = inThis ? s.peers[from] : null;
        if (rp != null && rp.offerer) await _restartPeer(s!, rp);
        break;

      case 'gc_reoffer':
        final sdp = m.data['sdp'] as String?;
        final rp = inThis ? s.peers[from] : null;
        final rpc = rp?.pc;
        if (rp == null || rpc == null || rp.offerer || sdp == null) return;
        try {
          await rpc.setRemoteDescription(RTCSessionDescription(sdp, 'offer'));
          final answer = await rpc.createAnswer({});
          final local = await rp.ice.setLocalAndWait(rpc, answer);
          relay.sendTo(store.peer(from)?.publicKey, {'t': 'gc_reanswer', 'cid': cid, 'g': gid, 'sdp': local.sdp});
        } catch (_) {}
        break;

      case 'gc_reanswer':
        final sdp = m.data['sdp'] as String?;
        final rp = inThis ? s.peers[from] : null;
        if (rp == null || !rp.offerer || sdp == null) return;
        try {
          await rp.pc?.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
        } catch (_) {}
        break;

      case 'gc_answer':
        final sdp = m.data['sdp'] as String?;
        final p = inThis ? s.peers[from] : null;
        if (p == null || !p.offerer || sdp == null) return;
        try {
          await p.pc?.setRemoteDescription(RTCSessionDescription(sdp, 'answer'));
        } catch (_) {
          _dropPeer(s!, from);
        }
        break;

      case 'gc_leave':
        if (inThis) _dropPeer(s, from);
        break;

      case 'gc_cam':
        final p = inThis ? s.peers[from] : null;
        if (p == null) return;
        p.camOn = m.data['on'] == true;
        s!.notifyListeners();
        break;
    }
  }

  // ------------------------------------------------------------------ الاتصالات المباشرة
  Future<GroupCallPeer?> _newPeer(GroupCallSession s, String id, {required bool offerer, Object? shared}) async {
    final info = store.peer(id);
    if (info == null) return null;
    final p = GroupCallPeer(id, store.nameOf(id, fallback: info.name))..offerer = offerer;
    s.peers[id] = p;
    s.notifyListeners();
    try {
      await p.renderer.initialize();
      p.rendererReady = true;
      final pc = await createPeerConnection(IceConfig.configuration(shared: shared));
      p.pc = pc;
      pc.onIceGatheringState = p.ice.onState;
      pc.onIceCandidate = p.ice.onCandidate;
      pc.onConnectionState = (state) {
        if (state == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
          p.timeout?.cancel();
          p.recover?.cancel();
          p.recover = null;
          if (!p.connected && s.video) capVideoBitrate(pc, s.peers.length > 2 ? 300000 : 450000, maxFramerate: 20);
          p.connected = true;
          if (s.firstPeerAt == null) {
            s.firstPeerAt = DateTime.now();
            Helper.setSpeakerphoneOn(s.speakerOn).catchError((Object _) {});
          }
          s.everHadPeers = true;
          _ringTimeout?.cancel();
          _lonelyTimer?.cancel();
          s.notifyListeners();
        } else if (state == RTCPeerConnectionState.RTCPeerConnectionStateDisconnected ||
            state == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
          if (p.connected) {
            _recoverPeer(s, p);
          } else if (state == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
            _dropPeer(s, id);
          }
        } else if (state == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
          _dropPeer(s, id);
        }
      };
      pc.onTrack = (event) async {
        if (event.track.kind != 'video') return;
        if (event.streams.isNotEmpty) {
          p.renderer.srcObject = event.streams.first;
        } else {
          p.fallback ??= await createLocalMediaStream('gc-$id');
          await p.fallback!.addTrack(event.track);
          p.renderer.srcObject = p.fallback;
        }
        p.hasVideo = true;
        s.notifyListeners();
      };
      final stream = s.localStream;
      if (stream != null) {
        for (final t in stream.getTracks()) {
          await pc.addTrack(t, stream);
        }
      }
      p.timeout = Timer(const Duration(seconds: 30), () {
        if (!p.connected) _dropPeer(s, id);
      });
      return p;
    } catch (e) {
      debugPrint('group peer failed: $e');
      _dropPeer(s, id);
      return null;
    }
  }

  Future<void> _offerTo(GroupCallSession s, String id) async {
    final p = await _newPeer(s, id, offerer: true);
    final pc = p?.pc;
    if (p == null || pc == null) return;
    final offer = await pc.createOffer({});
    final local = await p.ice.setLocalAndWait(pc, offer);
    if (s.phase == GroupCallPhase.ended || !s.peers.containsKey(id)) return;
    relay.sendTo(store.peer(id)?.publicKey, {
      't': 'gc_offer',
      'cid': s.gcid,
      'g': s.group.id,
      'sdp': local.sdp,
      'ice': IceConfig.shareable(),
    });
  }

  /// انقطاع مؤقت مع مشارك: صاحب العرض يعيد التفاوض، والآخر يطلب ذلك. نُسقطه بعد 25 ثانية.
  void _recoverPeer(GroupCallSession s, GroupCallPeer p) {
    if (p.recover != null) return;
    final started = DateTime.now();
    void attempt() {
      if (s.phase != GroupCallPhase.joined || !s.peers.containsKey(p.id) || p.recover == null) {
        p.recover?.cancel();
        p.recover = null;
        return;
      }
      if (DateTime.now().difference(started).inSeconds > 25) {
        p.recover?.cancel();
        p.recover = null;
        _dropPeer(s, p.id);
        return;
      }
      if (p.offerer) {
        _restartPeer(s, p);
      } else {
        relay.sendTo(store.peer(p.id)?.publicKey, {'t': 'gc_restart', 'cid': s.gcid, 'g': s.group.id});
      }
    }

    p.recover = Timer.periodic(const Duration(seconds: 6), (_) => attempt());
    Timer(const Duration(seconds: 2), attempt);
  }

  Future<void> _restartPeer(GroupCallSession s, GroupCallPeer p) async {
    final pc = p.pc;
    if (pc == null || p.restarting) return;
    p.restarting = true;
    try {
      await pc.restartIce();
      final offer = await pc.createOffer({});
      final local = await p.ice.setLocalAndWait(pc, offer);
      if (s.phase == GroupCallPhase.ended) return;
      relay.sendTo(store.peer(p.id)?.publicKey, {
        't': 'gc_reoffer',
        'cid': s.gcid,
        'g': s.group.id,
        'sdp': local.sdp,
        'ice': IceConfig.shareable(),
      });
    } catch (_) {
    } finally {
      p.restarting = false;
    }
  }

  Future<void> _answer(GroupCallSession s, String id, String sdp, {Object? shared}) async {
    final existing = s.peers[id];
    if (existing != null) {
      // عرض جديد من نفس الشخص (أعاد الانضمام): نبدأ من جديد
      s.peers.remove(id);
      await existing.dispose();
    }
    final p = await _newPeer(s, id, offerer: false, shared: shared);
    final pc = p?.pc;
    if (p == null || pc == null) return;
    try {
      await pc.setRemoteDescription(RTCSessionDescription(sdp, 'offer'));
      final answer = await pc.createAnswer({});
      final local = await p.ice.setLocalAndWait(pc, answer);
      if (s.phase == GroupCallPhase.ended || !s.peers.containsKey(id)) return;
      relay.sendTo(store.peer(id)?.publicKey, {'t': 'gc_answer', 'cid': s.gcid, 'g': s.group.id, 'sdp': local.sdp});
    } catch (_) {
      _dropPeer(s, id);
    }
  }

  void _dropPeer(GroupCallSession s, String id) {
    final p = s.peers.remove(id);
    if (p == null) return;
    p.dispose();
    s.notifyListeners();
    // عندما يغادر الجميع تنتهي المكالمة
    if (s.phase == GroupCallPhase.joined && s.peers.isEmpty && s.everHadPeers) {
      _lonelyTimer?.cancel();
      _lonelyTimer = Timer(const Duration(seconds: 8), () {
        if (s.phase == GroupCallPhase.joined && s.peers.isEmpty) {
          active.remove(s.group.id);
          _end(s, 'غادر الجميع المكالمة', CallResult.answered);
        }
      });
    }
  }

  Future<void> _openMedia(GroupCallSession s) async {
    if (!s.localReady) {
      await s.localRenderer.initialize();
      s.localReady = true;
    }
    if (s.localStream != null) return;
    final stream = await navigator.mediaDevices.getUserMedia({
      'audio': {'echoCancellation': true, 'noiseSuppression': true, 'autoGainControl': true},
      'video': s.video
          ? {'facingMode': 'user', 'width': 480, 'height': 360, 'frameRate': 20}
          : false,
    });
    if (s.phase == GroupCallPhase.ended) {
      for (final t in stream.getTracks()) {
        t.stop();
      }
      return;
    }
    s.localStream = stream;
    s.localRenderer.srcObject = stream;
    s.notifyListeners();
  }

  void _toMembers(Group g, Map<String, dynamic> data) {
    for (final m in g.members) {
      if (m.id != me) relay.send(m.publicKey, data);
    }
  }

  void _end(GroupCallSession s, String reason, CallResult result) {
    if (s.phase == GroupCallPhase.ended) return;
    final wasRinging = s.phase == GroupCallPhase.ringing;
    final duration = s.elapsed;
    final hadPeers = s.everHadPeers;
    s.phase = GroupCallPhase.ended;
    s.endReason = reason;
    _ringTimeout?.cancel();
    _lonelyTimer?.cancel();
    NativeBridge.stopRinging();
    NativeBridge.cancelCallNotification();
    NativeBridge.keepScreenOn(false);
    NativeBridge.setInCall(false);
    for (final p in s.peers.values) {
      p.dispose();
    }
    s.peers.clear();

    final log = CallLog(
      chatId: s.group.chatId,
      video: s.video,
      incoming: !s.startedByMe,
      result: hadPeers ? CallResult.answered : (wasRinging ? result : result),
      duration: duration,
    );
    store.addCall(log);
    final type = s.video ? 'مكالمة فيديو جماعية' : 'مكالمة صوتية جماعية';
    final text = hadPeers
        ? '$type • ${formatDuration(duration)}'
        : (wasRinging && result == CallResult.missed ? '$type فائتة' : '$type — $reason');
    store.addMessage(
      ChatMessage(
        id: newId(),
        chatId: s.group.chatId,
        mine: s.startedByMe,
        kind: MessageKind.call,
        status: MessageStatus.received,
        text: text,
      ),
      countUnread: wasRinging && result == CallResult.missed,
    );

    s.notifyListeners();
    Timer(const Duration(seconds: 3), () {
      if (current == s) current = null;
      s.dispose();
      notifyListeners();
    });
    notifyListeners();
  }
}
