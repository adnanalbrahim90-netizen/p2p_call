import 'package:flutter/services.dart';

/// قناة صغيرة لوظائف أندرويد الأصلية (بدون مكتبات إضافية):
/// إبقاء الشاشة مضاءة، نغمة الرنين، والاهتزاز.
class NativeBridge {
  static const MethodChannel _ch = MethodChannel('ittisal/native');

  static Future<void> _call(String method, [Object? args]) async {
    try {
      await _ch.invokeMethod<void>(method, args);
    } catch (_) {}
  }

  static Future<void> keepScreenOn(bool on) => _call('keepScreenOn', on);

  static Future<void> startRinging() => _call('startRinging');

  static Future<void> stopRinging() => _call('stopRinging');

  static Future<void> vibrate() => _call('vibrate');
}
