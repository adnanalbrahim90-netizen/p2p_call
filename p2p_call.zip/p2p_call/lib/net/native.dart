import 'package:flutter/services.dart';

/// إجراء قادم من أندرويد (ضغطة على إشعار، رد/رفض مكالمة)
class NativeAction {
  NativeAction(this.type, this.data);
  final String type;
  final Map<String, dynamic> data;
}

/// قناة لوظائف أندرويد الأصلية (بدون مكتبات إضافية):
/// خدمة الخلفية، الإشعارات، الرنين، الاهتزاز، إبقاء الشاشة مضاءة.
class NativeBridge {
  static const MethodChannel _ch = MethodChannel('ittisal/native');

  static void Function(NativeAction action)? _onAction;

  /// يستقبل الإجراءات من أندرويد. يُستدعى مرة عند التشغيل.
  static void listen(void Function(NativeAction action) onAction) {
    _onAction = onAction;
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'action') await _drain();
      return null;
    });
    _drain();
  }

  /// يسحب الإجراءات المعلقة (مثلاً: فُتح التطبيق بالضغط على إشعار)
  static Future<void> _drain() async {
    try {
      final list = await _ch.invokeMethod<List<dynamic>>('takeActions');
      for (final raw in list ?? const <dynamic>[]) {
        if (raw is Map) {
          final m = Map<String, dynamic>.from(raw);
          _onAction?.call(NativeAction((m['type'] as String?) ?? '', m));
        }
      }
    } catch (_) {}
  }

  static Future<T?> _call<T>(String method, [Object? args]) async {
    try {
      return await _ch.invokeMethod<T>(method, args);
    } catch (_) {
      return null;
    }
  }

  // ------------------------------------------------------------------ الشاشة والرنين
  static Future<void> keepScreenOn(bool on) => _call('keepScreenOn', on);
  static Future<void> startRinging() => _call('startRinging');
  static Future<void> stopRinging() => _call('stopRinging');
  static Future<void> vibrate() => _call('vibrate');

  // ------------------------------------------------------------------ خدمة الخلفية
  /// تشغيل/إيقاف الخدمة التي تبقي التطبيق متصلاً والتطبيق مغلق
  static Future<void> setBackground(bool enabled) => _call('setBackground', enabled);

  /// أثناء المكالمة: يسمح باستمرار الميكروفون والكاميرا عند الخروج من التطبيق
  static Future<void> setInCall(bool inCall, {bool video = false}) =>
      _call('setInCall', {'on': inCall, 'video': video});

  // ------------------------------------------------------------------ الإشعارات
  static Future<void> notifyMessage({
    required String chatId,
    required String title,
    required String body,
    String? sender,
  }) =>
      _call('notifyMessage', {'chatId': chatId, 'title': title, 'body': body, 'sender': sender});

  static Future<void> cancelChatNotification(String chatId) => _call('cancelChat', chatId);

  static Future<void> notifyIncomingCall({
    required String title,
    required String body,
    required bool video,
  }) =>
      _call('notifyCall', {'title': title, 'body': body, 'video': video});

  static Future<void> cancelCallNotification() => _call('cancelCall');

  static Future<void> notifyInfo(String title, String body) =>
      _call('notifyInfo', {'title': title, 'body': body});

  // ------------------------------------------------------------------ حالة الأذونات
  /// هل يُسمح بعرض المكالمة الواردة على الشاشة كاملة (أندرويد 14+)
  static Future<bool> canFullScreen() async => (await _call<bool>('canFullScreen')) ?? true;

  static Future<void> openFullScreenSettings() => _call('openFullScreenSettings');

  static Future<bool> ignoringBatteryOptimizations() async =>
      (await _call<bool>('isIgnoringBattery')) ?? false;

  static Future<void> requestIgnoreBattery() => _call('requestIgnoreBattery');

  static Future<void> openAppSettings() => _call('openAppSettings');

  /// الشركة المصنّعة (لإرشادات خاصة مثل هواوي وشاومي)
  static Future<String> manufacturer() async => (await _call<String>('manufacturer')) ?? '';
}
