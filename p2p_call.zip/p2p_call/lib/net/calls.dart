import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import 'native.dart';
import 'relay.dart';
import 'rtc.dart';

enum CallPhase {
  /// مكالمة صادرة بانتظار رد الطرف الآخر
  calling,

  /// مكالمة واردة تنتظر القبول
  ringing,

  /// تم القبول وجارٍ إنشاء المسار المباشر
  connecting,

  /// المكالمة جارية
  active,

  /// انتهت
  ended,
}

class CallSession extends ChangeNotifier {
  CallSession({
    required this.contact,
    required this.video,
    required this.outgoing,
    required this.cid,
    this.remoteOffer,
  });

  final Contact contact;
  final bool video;
  final bool outgoing;
  final String cid;
  final String? remoteOffer;

  CallPhase phase = CallPhase.calling;
  String? endReason;
  DateTime? connectedAt;

  final RTCVideoRenderer localRenderer = RTCVideoRenderer();
  final RTCVideoRenderer remoteRenderer = RTCVideoRenderer();
  RTCPeerConnection? pc;
  MediaStream? localStream;
  MediaStream? remoteFallback;
  final IceGatherer ice = IceGatherer();
  bool _renderersReady = false;
  bool _disposed = false;

  bool micOn = true;
  late bool camOn = video;
  late bool speakerOn = video;
  bool frontCamera = true;
  bool remoteCamOn = true;
  bool hasRemoteVideo = false;
  bool reconnecting = false;

  Duration get elapsed =>
      connectedAt == null ? Duration.zero : DateTime.now().difference(connectedAt!);

  Future<void> initRenderers() async {
    if (_renderersReady) return;
    await localRenderer.initialize();
    await remoteRenderer.initialize();
    _renderersReady = true;
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    if (_disposed) return;
    _disposed = true;
    for (final t in localStream?.getTracks() ?? const <MediaStreamTrack>[]) {
      try {
        t.stop();
      } catch (_) {}
    }
    try {
      localStream?.dispose();
    } catch (_) {}
    try {
      pc?.close();
    } catch (_) {}
    try {
      localRenderer.srcObject = null;
      remoteRenderer.srcObject = null;
      if (_renderersReady) {
        localRenderer.dispose();
        remoteRenderer.dispose();
      }
    } catch (_) {}
    super.dispose();
  }
}

/// يدير المكالمات الصوتية والمرئية: الرنين، القبول، الرفض، الإنهاء
class CallManager extends ChangeNotifier {
  CallManager(this.identity, this.store, this.relay);

  final Identity identity;
  final Store store;
  final Relay relay;

  CallSession? current;
  Timer? _ringTimeout;
  Timer? _disconnectTimer;

  /// تطلب من الواجهة عرض شاشة المكالمة
  void Function(CallSession session)? onShowCall;

  bool get busy => current != null && current!.phase != CallPhase.ended;

  // ------------------------------------------------------------------ صادرة
  Future<String?> startCall(Contact contact, {required bool video}) async {
    if (busy) return 'لديك مكالمة جارية بالفعل';
    if (relay.connectedCount == 0) return 'لا يوجد اتصال بالإنترنت';
    if (!contact.confirmed) {
      return 'بانتظار أن يقبل ${contact.displayName} طلب الإضافة';
    }
    if (!relay.isOnline(contact.id)) {
      return '${contact.displayName} غير متصل الآن';
    }
    final s = CallSession(contact: contact, video: video, outgoing: true, cid: newId(8));
    current = s;
    s.phase = CallPhase.calling;
    notifyListeners();
    onShowCall?.call(s);

    try {
      await s.initRenderers();
      await _openMedia(s);
      await _createPc(s);
      final offer = await s.pc!.createOffer({});
      final local = await s.ice.setLocalAndWait(s.pc!, offer);
      if (s.phase == CallPhase.ended) return null;
      await relay.send(contact.publicKey, {
        't': 'call_offer',
        'cid': s.cid,
        'video': video,
        'sdp': local.sdp,
        'name': identity.name,
      });
      NativeBridge.keepScreenOn(true);
      _ringTimeout = Timer(const Duration(seconds: 45), () {
        if (s.phase == CallPhase.calling) {
          relay.send(contact.publicKey, {'t': 'call_cancel', 'cid': s.cid});
          _finish(s, 'لا يوجد رد', CallResult.missed);
        }
      });
    } catch (e) {
      debugPrint('start call failed: $e');
      _finish(s, 'تعذّر بدء المكالمة', CallResult.failed);
    }
    return null;
  }

  // ------------------------------------------------------------------ واردة
  void onRelay(RelayMessage m) {
    final contact = store.contact(m.senderId);
    if (contact == null) return;
    final cid = m.data['cid'] as String?;
    if (cid == null) return;
    final s = current;

    switch (m.type) {
      case 'call_offer':
        final sdp = m.data['sdp'] as String?;
        if (sdp == null) return;
        if (busy) {
          if (s!.cid != cid) {
            relay.send(contact.publicKey, {'t': 'call_reject', 'cid': cid, 'reason': 'busy'});
            _logMissed(contact, m.data['video'] == true);
          }
          return;
        }
        final incoming = CallSession(
          contact: contact,
          video: m.data['video'] == true,
          outgoing: false,
          cid: cid,
          remoteOffer: sdp,
        )..phase = CallPhase.ringing;
        current = incoming;
        notifyListeners();
        NativeBridge.startRinging();
        NativeBridge.keepScreenOn(true);
        onShowCall?.call(incoming);
        _ringTimeout = Timer(const Duration(seconds: 45), () {
          if (incoming.phase == CallPhase.ringing) {
            _finish(incoming, 'مكالمة فائتة', CallResult.missed);
          }
        });
        break;

      case 'call_answer':
        final sdp = m.data['sdp'] as String?;
        if (s == null || s.cid != cid || !s.outgoing || sdp == null) return;
        if (s.phase != CallPhase.calling) return;
        _ringTimeout?.cancel();
        s.phase = CallPhase.connecting;
        s.notifyListeners();
        _ringTimeout = Timer(const Duration(seconds: 30), () {
          if (s.phase == CallPhase.connecting) {
            relay.send(s.contact.publicKey, {'t': 'call_end', 'cid': s.cid});
            _finish(s, 'تعذّر إنشاء اتصال مباشر بين الشبكتين', CallResult.failed);
          }
        });
        s.pc?.setRemoteDescription(RTCSessionDescription(sdp, 'answer')).catchError((Object e) {
          _finish(s, 'تعذّر الاتصال', CallResult.failed);
        });
        break;

      case 'call_reject':
        if (s == null || s.cid != cid) return;
        final busyPeer = m.data['reason'] == 'busy';
        _finish(s, busyPeer ? 'الطرف الآخر في مكالمة أخرى' : 'تم رفض المكالمة',
            busyPeer ? CallResult.missed : CallResult.declined);
        break;

      case 'call_cancel':
        if (s == null || s.cid != cid) return;
        _finish(s, 'مكالمة فائتة', CallResult.missed);
        break;

      case 'call_end':
        if (s == null || s.cid != cid) return;
        _finish(s, 'انتهت المكالمة', CallResult.answered);
        break;

      case 'call_cam':
        if (s == null || s.cid != cid) return;
        s.remoteCamOn = m.data['on'] == true;
        s.notifyListeners();
        break;
    }
  }

  Future<void> accept() async {
    final s = current;
    if (s == null || s.outgoing || s.phase != CallPhase.ringing) return;
    NativeBridge.stopRinging();
    _ringTimeout?.cancel();
    s.phase = CallPhase.connecting;
    s.notifyListeners();
    try {
      await s.initRenderers();
      await _openMedia(s);
      await _createPc(s);
      await s.pc!.setRemoteDescription(RTCSessionDescription(s.remoteOffer!, 'offer'));
      final answer = await s.pc!.createAnswer({});
      final local = await s.ice.setLocalAndWait(s.pc!, answer);
      if (s.phase == CallPhase.ended) return;
      await relay.send(s.contact.publicKey, {
        't': 'call_answer',
        'cid': s.cid,
        'sdp': local.sdp,
      });
      // مهلة إنشاء المسار المباشر
      _ringTimeout = Timer(const Duration(seconds: 30), () {
        if (s.phase == CallPhase.connecting) {
          relay.send(s.contact.publicKey, {'t': 'call_end', 'cid': s.cid});
          _finish(s, 'تعذّر إنشاء اتصال مباشر بين الشبكتين', CallResult.failed);
        }
      });
    } catch (e) {
      debugPrint('accept failed: $e');
      relay.send(s.contact.publicKey, {'t': 'call_end', 'cid': s.cid});
      _finish(s, 'تعذّر تشغيل الكاميرا أو الميكروفون', CallResult.failed);
    }
  }

  void decline() {
    final s = current;
    if (s == null || s.outgoing || s.phase != CallPhase.ringing) return;
    relay.send(s.contact.publicKey, {'t': 'call_reject', 'cid': s.cid, 'reason': 'declined'});
    _finish(s, 'تم رفض المكالمة', CallResult.declined);
  }

  void hangUp() {
    final s = current;
    if (s == null || s.phase == CallPhase.ended) return;
    if (s.outgoing && s.phase == CallPhase.calling) {
      relay.send(s.contact.publicKey, {'t': 'call_cancel', 'cid': s.cid});
      _finish(s, 'تم الإلغاء', CallResult.cancelled);
      return;
    }
    if (!s.outgoing && s.phase == CallPhase.ringing) {
      decline();
      return;
    }
    relay.send(s.contact.publicKey, {'t': 'call_end', 'cid': s.cid});
    _finish(s, 'انتهت المكالمة', CallResult.answered);
  }

  // ------------------------------------------------------------------ أدوات التحكم
  void toggleMic() {
    final s = current;
    if (s == null) return;
    s.micOn = !s.micOn;
    for (final t in s.localStream?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = s.micOn;
    }
    s.notifyListeners();
  }

  void toggleCamera() {
    final s = current;
    if (s == null || !s.video) return;
    s.camOn = !s.camOn;
    for (final t in s.localStream?.getVideoTracks() ?? const <MediaStreamTrack>[]) {
      t.enabled = s.camOn;
    }
    relay.send(s.contact.publicKey, {'t': 'call_cam', 'cid': s.cid, 'on': s.camOn});
    s.notifyListeners();
  }

  Future<void> switchCamera() async {
    final s = current;
    final tracks = s?.localStream?.getVideoTracks() ?? const <MediaStreamTrack>[];
    if (s == null || tracks.isEmpty) return;
    try {
      await Helper.switchCamera(tracks.first);
      s.frontCamera = !s.frontCamera;
      s.notifyListeners();
    } catch (_) {}
  }

  Future<void> toggleSpeaker() async {
    final s = current;
    if (s == null) return;
    s.speakerOn = !s.speakerOn;
    try {
      await Helper.setSpeakerphoneOn(s.speakerOn);
    } catch (_) {}
    s.notifyListeners();
  }

  // ------------------------------------------------------------------ داخلي
  Future<void> _openMedia(CallSession s) async {
    final stream = await navigator.mediaDevices.getUserMedia({
      'audio': {
        'echoCancellation': true,
        'noiseSuppression': true,
        'autoGainControl': true,
      },
      'video': s.video
          ? {
              'facingMode': 'user',
              'width': 640,
              'height': 480,
              'frameRate': 24,
            }
          : false,
    });
    if (s.phase == CallPhase.ended) {
      for (final t in stream.getTracks()) {
        t.stop();
      }
      return;
    }
    s.localStream = stream;
    s.localRenderer.srcObject = stream;
    s.notifyListeners();
  }

  Future<void> _createPc(CallSession s) async {
    final pc = await createPeerConnection(rtcConfiguration);
    s.pc = pc;
    pc.onIceGatheringState = s.ice.onState;
    pc.onConnectionState = (state) {
      if (s.phase == CallPhase.ended) return;
      switch (state) {
        case RTCPeerConnectionState.RTCPeerConnectionStateConnected:
          _disconnectTimer?.cancel();
          _ringTimeout?.cancel();
          s.reconnecting = false;
          if (s.phase != CallPhase.active) {
            s.phase = CallPhase.active;
            s.connectedAt = DateTime.now();
            Helper.setSpeakerphoneOn(s.speakerOn).catchError((Object _) {});
          }
          s.notifyListeners();
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateDisconnected:
          s.reconnecting = true;
          s.notifyListeners();
          _disconnectTimer?.cancel();
          _disconnectTimer = Timer(const Duration(seconds: 15), () {
            if (s.reconnecting) _finish(s, 'انقطع الاتصال', CallResult.answered);
          });
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateFailed:
          _finish(
            s,
            s.connectedAt == null
                ? 'تعذّر إنشاء اتصال مباشر بين الشبكتين'
                : 'انقطع الاتصال',
            s.connectedAt == null ? CallResult.failed : CallResult.answered,
          );
          break;
        default:
          break;
      }
    };
    pc.onTrack = (event) async {
      if (event.track.kind != 'video') return;
      if (event.streams.isNotEmpty) {
        s.remoteRenderer.srcObject = event.streams.first;
      } else {
        s.remoteFallback ??= await createLocalMediaStream('remote');
        await s.remoteFallback!.addTrack(event.track);
        s.remoteRenderer.srcObject = s.remoteFallback;
      }
      s.hasRemoteVideo = true;
      s.notifyListeners();
    };
    final stream = s.localStream;
    if (stream != null) {
      for (final t in stream.getTracks()) {
        await pc.addTrack(t, stream);
      }
    }
  }

  void _logMissed(Contact c, bool video) {
    final log = CallLog(contactId: c.id, video: video, incoming: true, result: CallResult.missed);
    store.addCall(log);
    _addCallMessage(c, log);
  }

  void _finish(CallSession s, String reason, CallResult result) {
    if (s.phase == CallPhase.ended) return;
    final wasConnected = s.connectedAt != null;
    final duration = s.elapsed;
    s.phase = CallPhase.ended;
    s.endReason = reason;
    _ringTimeout?.cancel();
    _disconnectTimer?.cancel();
    NativeBridge.stopRinging();
    NativeBridge.keepScreenOn(false);

    final log = CallLog(
      contactId: s.contact.id,
      video: s.video,
      incoming: !s.outgoing,
      result: wasConnected ? CallResult.answered : result,
      duration: duration,
    );
    store.addCall(log);
    _addCallMessage(s.contact, log);

    s.notifyListeners();
    // نترك الشاشة تعرض سبب الإنهاء لحظة ثم نحرر الموارد
    Timer(const Duration(seconds: 3), () {
      if (current == s) current = null;
      s.dispose();
      notifyListeners();
    });
    notifyListeners();
  }

  void _addCallMessage(Contact c, CallLog log) {
    final type = log.video ? 'مكالمة فيديو' : 'مكالمة صوتية';
    String text;
    switch (log.result) {
      case CallResult.answered:
        text = '$type • ${formatDuration(log.duration)}';
        break;
      case CallResult.missed:
        text = log.incoming ? '$type فائتة' : '$type — لا يوجد رد';
        break;
      case CallResult.declined:
        text = log.incoming ? '$type مرفوضة' : '$type — تم الرفض';
        break;
      case CallResult.cancelled:
        text = '$type ملغاة';
        break;
      case CallResult.failed:
        text = '$type — تعذّر الاتصال';
        break;
    }
    store.addMessage(
      ChatMessage(
        id: newId(),
        contactId: c.id,
        mine: !log.incoming,
        kind: MessageKind.call,
        status: MessageStatus.received,
        text: text,
      ),
      countUnread: log.incoming && log.result == CallResult.missed,
    );
  }
}

String formatDuration(Duration d) {
  final h = d.inHours;
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:$m:$s' : '$m:$s';
}
