import 'dart:async';

import 'package:flutter_webrtc/flutter_webrtc.dart';

/// إعدادات WebRTC المشتركة: STUN مجاني من جوجل فقط (بدون TURN)
const Map<String, dynamic> rtcConfiguration = {
  'iceServers': [
    {
      'urls': [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
      ],
    },
  ],
  'sdpSemantics': 'unified-plan',
};

/// يضبط الوصف المحلي ثم ينتظر اكتمال جمع مسارات ICE (بدون Trickle ICE)
/// ويعيد الوصف النهائي متضمناً جميع المسارات.
class IceGatherer {
  Completer<void>? _done;

  /// يجب استدعاؤها من داخل onIceGatheringState الخاص بالاتصال
  void onState(RTCIceGatheringState state) {
    if (state == RTCIceGatheringState.RTCIceGatheringStateComplete) {
      final c = _done;
      if (c != null && !c.isCompleted) c.complete();
    }
  }

  Future<RTCSessionDescription> setLocalAndWait(
    RTCPeerConnection pc,
    RTCSessionDescription desc, {
    Duration timeout = const Duration(seconds: 6),
  }) async {
    _done = Completer<void>();
    await pc.setLocalDescription(desc);
    await _done!.future.timeout(timeout, onTimeout: () {});
    final local = await pc.getLocalDescription();
    return local ?? desc;
  }
}
