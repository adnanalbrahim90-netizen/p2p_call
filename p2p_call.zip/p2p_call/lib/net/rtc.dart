import 'dart:async';
import 'dart:convert';

import 'package:crypto/crypto.dart' as hash;
import 'package:flutter_webrtc/flutter_webrtc.dart';

/// خادم ترحيل TURN يضيفه المستخدم (مثل ExpressTURN أو Metered أو خادمه الخاص)
class TurnServer {
  TurnServer({required this.urls, required this.username, required this.credential});

  final List<String> urls;
  final String username;
  final String credential;

  bool get isValid =>
      urls.isNotEmpty && urls.every(_validUrl) && username.isNotEmpty && credential.isNotEmpty;

  static bool _validUrl(String u) =>
      RegExp(r'^(turns?|stun):[A-Za-z0-9.\-\[\]:]+(\?transport=(udp|tcp))?$').hasMatch(u.trim());

  Map<String, dynamic> toIce() => {'urls': urls, 'username': username, 'credential': credential};

  Map<String, dynamic> toJson() => {'u': urls, 'n': username, 'c': credential};

  static TurnServer? fromJson(Object? raw) {
    if (raw is! Map) return null;
    final urls = (raw['u'] as List?)?.whereType<String>().map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final t = TurnServer(
      urls: urls ?? const [],
      username: (raw['n'] as String?) ?? '',
      credential: (raw['c'] as String?) ?? '',
    );
    return t.isValid ? t : null;
  }

  /// يقبل الإدخال الحر: عنوان واحد أو أكثر في كل سطر (يُضاف turn: تلقائياً إن نُسي)
  static List<String> parseUrls(String text) {
    final out = <String>[];
    for (var line in text.split(RegExp(r'[\n,; ]+'))) {
      line = line.trim();
      if (line.isEmpty) continue;
      if (!line.startsWith('turn:') && !line.startsWith('turns:') && !line.startsWith('stun:')) {
        line = 'turn:$line';
      }
      out.add(line);
      // نضيف نسخة TCP تلقائياً: تعبر الشبكات التي تحجب UDP
      if (line.startsWith('turn:') && !line.contains('?transport=')) {
        out.add('$line?transport=tcp');
      }
    }
    return out.toSet().toList();
  }
}

/// إعدادات مسارات الشبكة (ICE): STUN + خوادم ترحيل TURN
///
/// • STUN مجاني من جوجل وكلاودفلير لاكتشاف العنوان العام.
/// • ترحيل مدمج مجاني (Open Relay) بمفاتيح مؤقتة تُولَّد على الجهاز (منافذ 80/443 و TLS).
/// • ترحيل خاص اختياري يضيفه المستخدم — ويُشارك تلقائياً مع الطرف الآخر داخل الرسائل المشفّرة
///   فيستفيد منه أصدقاؤه أيضاً.
///
/// الاتصال المباشر يبقى مفضلاً دائماً؛ الترحيل يُستخدم فقط إذا تعذّر المباشر،
/// والمحتوى يبقى مشفّراً طرفاً لطرف (DTLS-SRTP) فلا يستطيع خادم الترحيل قراءته.
class IceConfig {
  static bool useBuiltin = true;
  static TurnServer? custom;

  static const _openRelayHost = 'staticauth.openrelay.metered.ca';
  static const _openRelaySecret = 'openrelayprojectsecret';

  /// مفاتيح TURN مؤقتة (معيار TURN REST): الاسم = وقت الانتهاء، والكلمة = HMAC-SHA1
  static Map<String, dynamic> _openRelay() {
    final expiry = DateTime.now().add(const Duration(hours: 24)).millisecondsSinceEpoch ~/ 1000;
    final username = '$expiry:ittisal';
    final mac = hash.Hmac(hash.sha1, utf8.encode(_openRelaySecret)).convert(utf8.encode(username));
    return {
      'urls': [
        'turn:$_openRelayHost:80',
        'turn:$_openRelayHost:443?transport=tcp',
        'turns:$_openRelayHost:443?transport=tcp',
      ],
      'username': username,
      'credential': base64.encode(mac.bytes),
    };
  }

  static const Map<String, dynamic> _stun = {
    'urls': [
      'stun:stun.l.google.com:19302',
      'stun:stun.cloudflare.com:3478',
    ],
  };

  /// خوادم الترحيل التي نشاركها مع الطرف الآخر (الخاصة فقط)
  static List<Map<String, dynamic>> shareable() {
    final c = custom;
    return c != null && c.isValid ? [c.toJson()] : const [];
  }

  /// يقرأ خوادم ترحيل أرسلها الطرف الآخر (مع التحقق)
  static List<TurnServer> parseShared(Object? raw) {
    if (raw is! List) return const [];
    return raw.map(TurnServer.fromJson).whereType<TurnServer>().take(2).toList();
  }

  /// إعدادات الاتصال، مع خوادم الطرف الآخر إن وُجدت
  static Map<String, dynamic> configuration({Object? shared}) {
    final servers = <Map<String, dynamic>>[_stun];
    final c = custom;
    if (c != null && c.isValid) servers.add(c.toIce());
    for (final t in parseShared(shared)) {
      if (c == null || t.urls.join() != c.urls.join()) servers.add(t.toIce());
    }
    if (useBuiltin) servers.add(_openRelay());
    return {
      'iceServers': servers,
      'sdpSemantics': 'unified-plan',
      'bundlePolicy': 'max-bundle',
      'rtcpMuxPolicy': 'require',
    };
  }

  /// اختبار خادم ترحيل: هل نحصل على مسار "relay" خلال ثوانٍ؟
  static Future<bool> test({TurnServer? server, bool builtin = false}) async {
    final ice = <Map<String, dynamic>>[
      if (server != null) server.toIce(),
      if (builtin) _openRelay(),
    ];
    if (ice.isEmpty) return false;
    RTCPeerConnection? pc;
    final found = Completer<bool>();
    try {
      pc = await createPeerConnection({
        'iceServers': ice,
        'iceTransportPolicy': 'relay',
        'sdpSemantics': 'unified-plan',
      });
      pc.onIceCandidate = (c) {
        if ((c.candidate ?? '').contains(' typ relay') && !found.isCompleted) found.complete(true);
      };
      pc.onIceGatheringState = (s) {
        if (s == RTCIceGatheringState.RTCIceGatheringStateComplete && !found.isCompleted) {
          found.complete(false);
        }
      };
      await pc.createDataChannel('probe', RTCDataChannelInit());
      final offer = await pc.createOffer({});
      await pc.setLocalDescription(offer);
      return await found.future.timeout(const Duration(seconds: 10), onTimeout: () => false);
    } catch (_) {
      return false;
    } finally {
      try {
        await pc?.close();
      } catch (_) {}
    }
  }
}

/// يضبط الوصف المحلي ثم ينتظر اكتمال جمع مسارات ICE (بدون Trickle ICE)
/// ويعيد الوصف النهائي متضمناً جميع المسارات.
class IceGatherer {
  Completer<void>? _done;
  bool _relaySeen = false;

  /// يجب استدعاؤها من داخل onIceGatheringState الخاص بالاتصال
  void onState(RTCIceGatheringState state) {
    if (state == RTCIceGatheringState.RTCIceGatheringStateComplete) {
      final c = _done;
      if (c != null && !c.isCompleted) c.complete();
    }
  }

  /// يُستدعى من onIceCandidate: عند ظهور مسار ترحيل لا داعي لانتظار البقية طويلاً
  void onCandidate(RTCIceCandidate c) {
    if ((c.candidate ?? '').contains(' typ relay')) _relaySeen = true;
  }

  Future<RTCSessionDescription> setLocalAndWait(
    RTCPeerConnection pc,
    RTCSessionDescription desc, {
    Duration timeout = const Duration(seconds: 7),
  }) async {
    _done = Completer<void>();
    _relaySeen = false;
    await pc.setLocalDescription(desc);
    // ننتظر الاكتمال، أو ثانية واحدة بعد ظهور أول مسار ترحيل (يكفي للاتصال)
    final start = DateTime.now();
    while (!_done!.isCompleted) {
      final waited = DateTime.now().difference(start);
      if (waited >= timeout) break;
      if (_relaySeen && waited >= const Duration(milliseconds: 2500)) break;
      await Future.any([_done!.future, Future<void>.delayed(const Duration(milliseconds: 250))]);
    }
    final local = await pc.getLocalDescription();
    return local ?? desc;
  }
}

/// حد أقصى لمعدل الفيديو لتقليل استهلاك البيانات وتحسين الثبات على الشبكات الضعيفة
Future<void> capVideoBitrate(RTCPeerConnection pc, int maxBitrate, {int maxFramerate = 24}) async {
  try {
    for (final s in await pc.getSenders()) {
      if (s.track?.kind != 'video') continue;
      final params = s.parameters;
      final enc = params.encodings;
      if (enc == null || enc.isEmpty) continue;
      for (final e in enc) {
        e.maxBitrate = maxBitrate;
        e.maxFramerate = maxFramerate;
      }
      await s.setParameters(params);
    }
  } catch (_) {}
}
