import 'package:flutter/foundation.dart';

import '../core/identity.dart';
import '../core/models.dart';
import '../core/store.dart';
import 'link.dart';
import 'relay.dart';

/// إدارة القروبات بدون خادم:
/// كل عضو يحتفظ بنسخة من القروب، والمشرفون يرسلون التعديلات برقم إصدار متزايد
/// عبر رسائل تحكم مضمونة التسليم ومشفّرة.
///
/// الصلاحيات:
///  • المالك: كل شيء + ترقية/تخفيض المشرفين.
///  • المشرف: إضافة وإزالة الأعضاء العاديين، حذف أي رسالة للجميع، تعديل الاسم والإعدادات.
///  • العضو: إرسال الرسائل (ما لم يكن القروب للمشرفين فقط) وحذف رسائله للجميع.
class GroupService extends ChangeNotifier {
  GroupService(this.identity, this.store, this.links, this.relay);

  final Identity identity;
  final Store store;
  final LinkManager links;
  final Relay relay;

  /// تنبيه للواجهة (أُضفت إلى قروب ...)
  void Function(String message)? onNotice;

  String get me => identity.id;

  GroupMember _self(GroupRole role) =>
      GroupMember(id: me, publicKey: identity.publicKey, name: identity.name, role: role);

  GroupMember _fromContact(Contact c) =>
      GroupMember(id: c.id, publicKey: c.publicKey, name: c.name.isEmpty ? c.displayName : c.name);

  // ------------------------------------------------------------------ إجراءات محلية
  Future<Group> create(String name, List<Contact> contacts) async {
    final g = Group(
      id: newId(16).replaceAll(RegExp(r'[^A-Za-z0-9]'), 'x'),
      name: name.trim(),
      editor: me,
      members: [_self(GroupRole.owner), ...contacts.map(_fromContact)],
    );
    store.putGroup(g);
    _watchMembers(g);
    await _system(g, 'أنشأت القروب «${g.name}»');
    for (final m in g.members) {
      if (m.id != me) links.sendControl(m.id, {'t': 'g_invite', 'grp': g.toWire()});
    }
    return g;
  }

  bool canManage(Group g) => !g.left && g.isAdmin(me);

  /// هل أستطيع إزالة هذا العضو
  bool canRemove(Group g, GroupMember target) {
    if (g.left || target.id == me) return false;
    final my = g.member(me)?.role;
    if (my == GroupRole.owner) return target.role != GroupRole.owner;
    if (my == GroupRole.admin) return target.role == GroupRole.member;
    return false;
  }

  Future<void> addMembers(Group g, List<Contact> contacts) async {
    if (!canManage(g)) return;
    final added = contacts.where((c) => !g.has(c.id)).map(_fromContact).toList();
    if (added.isEmpty) return;
    final before = g.members.map((m) => m.id).toSet();
    g.members.addAll(added);
    _bump(g);
    _watchMembers(g);
    await _system(g, 'أضفت ${added.map((m) => m.name).join('، ')}');
    for (final m in added) {
      links.sendControl(m.id, {'t': 'g_invite', 'grp': g.toWire()});
    }
    for (final id in before) {
      if (id != me) links.sendControl(id, {'t': 'g_update', 'grp': g.toWire()});
    }
  }

  Future<void> removeMember(Group g, GroupMember target) async {
    if (!canRemove(g, target)) return;
    final everyone = g.members.map((m) => m.id).toList();
    g.members.removeWhere((m) => m.id == target.id);
    _bump(g);
    await _system(g, 'أزلت ${target.name}');
    for (final id in everyone) {
      if (id != me) links.sendControl(id, {'t': 'g_update', 'grp': g.toWire()});
    }
  }

  /// ترقية أو تخفيض مشرف (للمالك فقط)
  Future<void> setRole(Group g, GroupMember target, GroupRole role) async {
    if (g.left || !g.isOwner(me) || target.id == me || role == GroupRole.owner) return;
    target.role = role;
    _bump(g);
    await _system(g, role == GroupRole.admin ? 'جعلت ${target.name} مشرفاً' : 'أزلت ${target.name} من الإشراف');
    _broadcastUpdate(g);
  }

  Future<void> rename(Group g, String name) async {
    if (!canManage(g) || name.trim().isEmpty || name.trim() == g.name) return;
    g.name = name.trim();
    _bump(g);
    await _system(g, 'غيّرت اسم القروب إلى «${g.name}»');
    _broadcastUpdate(g);
  }

  Future<void> setAdminsOnly(Group g, bool value) async {
    if (!canManage(g) || g.adminsOnly == value) return;
    g.adminsOnly = value;
    _bump(g);
    await _system(g, value ? 'أصبح الإرسال للمشرفين فقط' : 'أصبح بإمكان الجميع الإرسال');
    _broadcastUpdate(g);
  }

  /// مغادرة القروب. المالك يسلّم الملكية لأقدم مشرف أو عضو أولاً.
  Future<void> leave(Group g) async {
    if (g.left) return;
    final others = g.members.where((m) => m.id != me).toList();
    if (g.isOwner(me) && others.isNotEmpty) {
      final heir = others.firstWhere((m) => m.role == GroupRole.admin, orElse: () => others.first);
      heir.role = GroupRole.owner;
      g.members.removeWhere((m) => m.id == me);
      _bump(g);
      for (final m in others) {
        links.sendControl(m.id, {'t': 'g_update', 'grp': g.toWire()});
      }
    } else {
      for (final m in others) {
        links.sendControl(m.id, {'t': 'g_leave', 'gid': g.id});
      }
      g.members.removeWhere((m) => m.id == me);
    }
    g.left = true;
    store.groupChanged(g);
    await _system(g, 'غادرت القروب');
  }

  /// هل أستطيع حذف هذه الرسالة للجميع
  bool canDeleteForAll(ChatMessage m) {
    if (m.deleted || m.isNotice) return false;
    if (!m.isGroup) return m.mine;
    final g = store.group(groupIdOf(m.chatId));
    if (g == null || g.left) return false;
    return m.mine || g.isAdmin(me);
  }

  Future<void> deleteForAll(ChatMessage m) async {
    if (!canDeleteForAll(m)) return;
    if (m.isGroup) {
      final g = store.group(groupIdOf(m.chatId))!;
      for (final mem in g.members) {
        if (mem.id != me) links.sendControl(mem.id, {'t': 'g_del', 'gid': g.id, 'mid': m.id});
      }
    } else {
      links.sendControl(m.chatId, {'t': 'del', 'mid': m.id});
    }
    await store.markDeleted(m);
  }

  // ------------------------------------------------------------------ رسائل واردة
  Future<void> onControl(String from, Map<String, dynamic> d) async {
    try {
      switch (d['t']) {
        case 'g_invite':
        case 'g_update':
          await _onRoster(from, d);
          break;
        case 'g_del':
          await _onDelete(from, d);
          break;
        case 'g_leave':
          await _onLeave(from, d);
          break;
      }
    } catch (e) {
      debugPrint('group control error: $e');
    }
  }

  Future<void> _onRoster(String from, Map<String, dynamic> d) async {
    final raw = d['grp'];
    if (raw is! Map) return;
    final incoming = Group.fromWire(Map<String, dynamic>.from(raw));
    final local = store.group(incoming.id);

    if (local == null) {
      // قروب جديد: نقبله فقط من مشرف فيه نعرفه، وإذا كنا ضمن أعضائه
      if (!incoming.isAdmin(from) || !incoming.has(me)) return;
      if (!store.hasContact(from)) return;
      incoming.editor = incoming.editor.isEmpty ? from : incoming.editor;
      store.putGroup(incoming);
      _watchMembers(incoming);
      final by = store.nameOf(from);
      await _system(incoming, '$by أضافك إلى القروب');
      onNotice?.call('$by أضافك إلى قروب «${incoming.name}»');
      _connectMembers(incoming);
      return;
    }

    // تعديل: من مشرف حسب النسخة المحلية، وبإصدار أحدث
    final authorized = local.isAdmin(from) || (local.left && incoming.isAdmin(from) && incoming.has(me));
    if (!authorized) return;
    if (!local.isOlderThan(incoming.version, incoming.editor.isEmpty ? from : incoming.editor)) return;

    final by = store.nameOf(from);
    final oldIds = local.members.map((m) => m.id).toSet();
    final newIds = incoming.members.map((m) => m.id).toSet();
    final notes = <String>[];
    if (incoming.name != local.name) notes.add('$by غيّر اسم القروب إلى «${incoming.name}»');
    for (final m in incoming.members) {
      if (!oldIds.contains(m.id) && m.id != me) notes.add('$by أضاف ${m.name}');
    }
    for (final m in local.members) {
      if (!newIds.contains(m.id) && m.id != me && m.id != from) notes.add('$by أزال ${m.name}');
    }
    for (final m in incoming.members) {
      final old = local.member(m.id);
      if (old != null && old.role != m.role && m.id != from) {
        if (m.role == GroupRole.owner) {
          notes.add('${m.id == me ? 'أصبحت' : 'أصبح ${m.name}'} مالك القروب');
        } else if (m.role == GroupRole.admin) {
          notes.add(m.id == me ? '$by جعلك مشرفاً' : '$by جعل ${m.name} مشرفاً');
        } else {
          notes.add(m.id == me ? '$by أزالك من الإشراف' : '$by أزال ${m.name} من الإشراف');
        }
      }
    }
    if (incoming.adminsOnly != local.adminsOnly) {
      notes.add(incoming.adminsOnly ? 'أصبح الإرسال للمشرفين فقط' : 'أصبح بإمكان الجميع الإرسال');
    }

    final wasMember = !local.left && oldIds.contains(me);
    local
      ..name = incoming.name
      ..members = incoming.members
      ..version = incoming.version
      ..editor = incoming.editor.isEmpty ? from : incoming.editor
      ..adminsOnly = incoming.adminsOnly;

    if (!incoming.has(me)) {
      local.left = true;
      notes.add('$by أزالك من القروب');
    } else if (!wasMember) {
      local.left = false;
      notes.add('$by أعاد إضافتك إلى القروب');
    }
    store.groupChanged(local);
    _watchMembers(local);
    for (final n in notes) {
      await _system(local, n);
    }
  }

  Future<void> _onDelete(String from, Map<String, dynamic> d) async {
    final gid = d['gid'];
    final mid = d['mid'];
    if (gid is! String || mid is! String) return;
    final g = store.group(gid);
    if (g == null || !g.has(from)) return;
    final m = await store.findMessage(g.chatId, mid);
    if (m == null || m.deleted) return;
    if (m.senderId == from || g.isAdmin(from)) {
      await store.markDeleted(m);
    }
  }

  Future<void> _onLeave(String from, Map<String, dynamic> d) async {
    final gid = d['gid'];
    if (gid is! String) return;
    final g = store.group(gid);
    if (g == null) return;
    final m = g.member(from);
    if (m == null) return;
    g.members.removeWhere((x) => x.id == from);
    store.groupChanged(g);
    await _system(g, 'غادر ${store.nameOf(from, fallback: m.name)}');
  }

  // ------------------------------------------------------------------ أدوات
  void _bump(Group g) {
    g.version++;
    g.editor = me;
    store.groupChanged(g);
  }

  void _broadcastUpdate(Group g) {
    for (final m in g.members) {
      if (m.id != me) links.sendControl(m.id, {'t': 'g_update', 'grp': g.toWire()});
    }
  }

  void _watchMembers(Group g) {
    for (final m in g.members) {
      if (m.id != me) relay.watch(m.id);
    }
  }

  void _connectMembers(Group g) {
    for (final m in g.members) {
      if (m.id != me) links.ensureLink(m.id);
    }
  }

  Future<void> _system(Group g, String text) => store.addMessage(ChatMessage(
        id: newId(),
        chatId: g.chatId,
        mine: false,
        kind: MessageKind.system,
        status: MessageStatus.received,
        text: text,
      ));
}
