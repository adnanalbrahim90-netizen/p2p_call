import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

import '../core/identity.dart';

/// رسالة تعارف واردة بعد فك تشفيرها والتحقق من مرسلها
class RelayMessage {
  RelayMessage(this.senderKey, this.senderId, this.data);
  final Uint8List senderKey;
  final String senderId;
  final Map<String, dynamic> data;
  String get type => (data['t'] as String?) ?? '';
}

class _Broker {
  _Broker(this.host, this.port);
  final String host;
  final int port;
  MqttServerClient? client;
  StreamSubscription<List<MqttReceivedMessage<MqttMessage>>>? sub;
  bool connected = false;
  bool connecting = false;
  int failures = 0;
  Timer? retry;
}

enum RelayStatus { offline, connecting, online }

/// "نقطة التقاء" عبر وسطاء MQTT عامة ومجانية.
///
/// لا يمر عبرها إلا رسائل تعارف قصيرة مشفرة طرفاً-لطرف (العرض/الرد)
/// وإشارة "متصل/غير متصل". المكالمات والرسائل والصور تنتقل مباشرة P2P.
class Relay extends ChangeNotifier {
  Relay(this.identity, this.cipher);

  final Identity identity;
  final Cipher cipher;

  static const String _ns = 'ittisal/v1';

  final List<_Broker> _brokers = [
    _Broker('broker.emqx.io', 8883),
    _Broker('broker.hivemq.com', 8883),
    _Broker('test.mosquitto.org', 8886),
  ];

  final _messages = StreamController<RelayMessage>.broadcast();
  final _presence = StreamController<String>.broadcast();

  Stream<RelayMessage> get messages => _messages.stream;

  /// يبث معرّف جهة الاتصال عند تغيّر حالة اتصالها
  Stream<String> get presenceChanges => _presence.stream;

  final Set<String> _watched = {};
  final Map<String, Set<int>> _online = {};
  final List<String> _seen = [];
  final Set<String> _seenSet = {};
  bool _started = false;
  late final String _session = newId(4);

  String get _inbox => '$_ns/in/${identity.id}';
  String _presenceTopic(String id) => '$_ns/on/$id';

  int get connectedCount => _brokers.where((b) => b.connected).length;
  int get brokerCount => _brokers.length;

  RelayStatus get status {
    if (connectedCount > 0) return RelayStatus.online;
    if (_brokers.any((b) => b.connecting || b.retry != null || b.client != null)) {
      return RelayStatus.connecting;
    }
    return RelayStatus.offline;
  }

  bool isOnline(String contactId) => (_online[contactId]?.isNotEmpty) ?? false;

  // ------------------------------------------------------------------ التشغيل
  void start() {
    if (_started) return;
    _started = true;
    for (var i = 0; i < _brokers.length; i++) {
      _connect(i);
    }
  }

  /// إعادة المحاولة فوراً (مثلاً عند العودة للتطبيق)
  void kick() {
    if (!_started) return;
    for (var i = 0; i < _brokers.length; i++) {
      final b = _brokers[i];
      // client != null يعني أن إعادة الاتصال التلقائية جارية بالفعل
      if (!b.connected && !b.connecting && b.client == null) {
        b.retry?.cancel();
        b.retry = null;
        b.failures = 0;
        _connect(i);
      }
    }
  }

  Future<void> _connect(int index) async {
    final b = _brokers[index];
    if (b.connecting || b.connected) return;
    b.connecting = true;
    b.retry = null;
    notifyListeners();

    final clientId = 'itt-${identity.id.substring(0, 12)}-$_session-$index';
    final client = MqttServerClient.withPort(b.host, clientId, b.port);
    client.secure = true;
    client.logging(on: false);
    client.setProtocolV311();
    client.keepAlivePeriod = 30;
    client.connectTimeoutPeriod = 8000;
    client.autoReconnect = true;
    client.resubscribeOnAutoReconnect = true;
    client.connectionMessage = MqttConnectMessage()
        .withClientIdentifier(clientId)
        .withWillTopic(_presenceTopic(identity.id))
        .withWillMessage('0')
        .withWillRetain()
        .withWillQos(MqttQos.atLeastOnce)
        .startClean();

    client.onDisconnected = () {
      b.connected = false;
      _dropPresenceFrom(index);
      // انقطاع نهائي (وليس أثناء محاولة الاتصال الأولى): نعيد المحاولة لاحقاً
      if (_started && !b.connecting && b.client == client) {
        b.sub?.cancel();
        b.sub = null;
        b.client = null;
        b.retry ??= Timer(const Duration(seconds: 5), () => _connect(index));
      }
      notifyListeners();
    };
    client.onAutoReconnect = () {
      b.connected = false;
      _dropPresenceFrom(index);
      notifyListeners();
    };
    client.onAutoReconnected = () {
      b.connected = true;
      try {
        client.subscribe(_inbox, MqttQos.atLeastOnce);
        for (final id in _watched) {
          client.subscribe(_presenceTopic(id), MqttQos.atLeastOnce);
        }
      } catch (_) {}
      _publishPresence(b, true);
      notifyListeners();
    };

    b.client = client;
    try {
      await client.connect();
    } catch (e) {
      debugPrint('relay ${b.host} connect failed: $e');
    }

    if (client.connectionStatus?.state == MqttConnectionState.connected) {
      b.connected = true;
      b.connecting = false;
      b.failures = 0;
      b.sub = client.updates?.listen((events) {
        for (final e in events) {
          _onRaw(index, e);
        }
      });
      client.subscribe(_inbox, MqttQos.atLeastOnce);
      for (final id in _watched) {
        client.subscribe(_presenceTopic(id), MqttQos.atLeastOnce);
      }
      _publishPresence(b, true);
      notifyListeners();
    } else {
      b.connecting = false;
      b.connected = false;
      try {
        client.disconnect();
      } catch (_) {}
      b.client = null;
      b.failures++;
      final wait = Duration(seconds: (5 * b.failures).clamp(5, 60));
      b.retry = Timer(wait, () => _connect(index));
      notifyListeners();
    }
  }

  void _publishPresence(_Broker b, bool online) {
    _publish(b, _presenceTopic(identity.id), online ? '1' : '0', retain: true);
  }

  void _publish(_Broker b, String topic, String payload, {bool retain = false}) {
    final client = b.client;
    if (client == null || !b.connected) return;
    try {
      final builder = MqttClientPayloadBuilder()..addUTF8String(payload);
      client.publishMessage(topic, MqttQos.atLeastOnce, builder.payload!,
          retain: retain);
    } catch (e) {
      debugPrint('relay publish failed: $e');
    }
  }

  /// إيقاف لطيف مع إعلان "غير متصل"
  Future<void> stop() async {
    _started = false;
    for (final b in _brokers) {
      b.retry?.cancel();
      b.retry = null;
      if (b.connected) _publishPresence(b, false);
    }
    await Future<void>.delayed(const Duration(milliseconds: 300));
    for (final b in _brokers) {
      await b.sub?.cancel();
      b.sub = null;
      try {
        b.client?.autoReconnect = false;
        b.client?.disconnect();
      } catch (_) {}
      b.client = null;
      b.connected = false;
      b.connecting = false;
    }
    _online.clear();
    notifyListeners();
  }

  // ------------------------------------------------------------------ الحضور
  void watch(String contactId) {
    if (!_watched.add(contactId)) return;
    for (final b in _brokers) {
      if (b.connected) {
        b.client?.subscribe(_presenceTopic(contactId), MqttQos.atLeastOnce);
      }
    }
  }

  void unwatch(String contactId) {
    if (!_watched.remove(contactId)) return;
    for (final b in _brokers) {
      if (b.connected) {
        try {
          b.client?.unsubscribe(_presenceTopic(contactId));
        } catch (_) {}
      }
    }
    _online.remove(contactId);
    notifyListeners();
  }

  void _dropPresenceFrom(int index) {
    final changed = <String>[];
    _online.forEach((id, set) {
      if (set.remove(index) && set.isEmpty) changed.add(id);
    });
    for (final id in changed) {
      _presence.add(id);
    }
  }

  // ------------------------------------------------------------------ الإرسال
  /// مثل [send] لكن يتجاهل الطرف غير المعروف
  Future<bool> sendTo(Uint8List? peerKey, Map<String, dynamic> data) =>
      peerKey == null ? Future.value(false) : send(peerKey, data);

  /// يرسل رسالة مشفرة إلى جهة اتصال عبر جميع الوسطاء المتصلين
  Future<bool> send(Uint8List peerKey, Map<String, dynamic> data) async {
    if (connectedCount == 0) return false;
    final payload = Map<String, dynamic>.from(data)
      ..['ts'] = DateTime.now().millisecondsSinceEpoch;
    final sealed = await cipher.seal(peerKey, payload);
    final envelope = jsonEncode({
      'v': 1,
      'i': newId(9),
      'f': base64Url.encode(identity.publicKey),
      'b': sealed,
    });
    final topic = '$_ns/in/${idForPublicKey(peerKey)}';
    var sent = false;
    for (final b in _brokers) {
      if (b.connected) {
        _publish(b, topic, envelope);
        sent = true;
      }
    }
    return sent;
  }

  // ------------------------------------------------------------------ الاستقبال
  void _onRaw(int index, MqttReceivedMessage<MqttMessage> event) {
    final msg = event.payload;
    if (msg is! MqttPublishMessage) return;
    final bytes = Uint8List.fromList(msg.payload.message.toList());
    final topic = event.topic;

    if (topic.startsWith('$_ns/on/')) {
      final id = topic.substring('$_ns/on/'.length);
      if (!_watched.contains(id)) return;
      final online = utf8.decode(bytes, allowMalformed: true).trim() == '1';
      final set = _online.putIfAbsent(id, () => <int>{});
      final before = set.isNotEmpty;
      if (online) {
        set.add(index);
      } else {
        set.remove(index);
      }
      if (before != set.isNotEmpty) {
        _presence.add(id);
        notifyListeners();
      }
      return;
    }

    if (topic == _inbox) _onEnvelope(bytes);
  }

  Future<void> _onEnvelope(Uint8List bytes) async {
    Map<String, dynamic> env;
    try {
      env = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    final mid = env['i'];
    if (mid is! String || _seenSet.contains(mid)) return;
    _seenSet.add(mid);
    _seen.add(mid);
    if (_seen.length > 500) _seenSet.remove(_seen.removeAt(0));

    Uint8List sender;
    try {
      sender = Uint8List.fromList(base64Url.decode(env['f'] as String));
    } catch (_) {
      return;
    }
    if (sender.length != 32) return;
    final data = await cipher.open(sender, (env['b'] as String?) ?? '');
    if (data == null) return;

    // رفض الرسائل القديمة جداً (حماية من إعادة الإرسال)
    final ts = data['ts'];
    if (ts is int) {
      final age = DateTime.now().millisecondsSinceEpoch - ts;
      // نافذة واسعة تتحمل فرق التوقيت بين الهاتفين
      if (age > const Duration(minutes: 60).inMilliseconds) return;
    }
    _messages.add(RelayMessage(sender, idForPublicKey(sender), data));
  }
}
